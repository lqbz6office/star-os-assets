#!/system/bin/sh
# ============================================================================
#  Star OS · 性能调度  (perf_mode.sh)
#  ---------------------------------------------------------------
#  Pro+ / 终身版专属的高级功能。CPU 调度器、频率上限、IO 调度等参数
#  按四档预设切换,结果持久化在 /data/adb/star_os/perf.conf,重启后由
#  service.sh 重新应用(否则内核恢复默认,档位就"看起来没生效")。
#
#  四档:
#     powersave   省电    —— 降频 + 省电调度器,续航优先
#     balanced    均衡    —— 恢复内核默认(出厂手感)
#     performance 性能    —— 满频 + 性能调度器,响应优先
#     turbo       极速    —— 满频 + 抬升底频,短时间爆发(耗电快)
#
#  设计约束(与本模块其他脚本一致):
#    · 目标环境是 Android 8.1 的 toybox/ash,**没有 local 关键字**
#      → 所有函数内变量用独占前缀 pf_ / pfa_ / pfs_,绝不与外层撞名;
#    · **所有 sysfs 节点都是"尽力而为"**:机型没这个节点就跳过,
#      绝不让脚本非零退出(否则 service.sh 的调用链会断);
#    · 每次 apply 都把**实际写成功了的项**记进日志,方便排查"为什么没效果"。
#
#  用法:
#    perf_mode.sh status           # 打印当前档位(一行,供应用解析)
#    perf_mode.sh list             # 列出四档(每行: id|名称|说明)
#    perf_mode.sh apply <mode>     # 应用并持久化
#    perf_mode.sh restore          # 解除限制(等同 apply balanced)
# ============================================================================

PFDIR=${0%/*}
[ -d "$PFDIR" ] || PFDIR=/data/adb/modules/zz_star_os
STAR_DIR=/data/adb/star_os
CONF=$STAR_DIR/perf.conf
LOG=$STAR_DIR/logs/perf.log

mkdir -p "$STAR_DIR/logs" 2>/dev/null

# ---------------------------------------------------------------------------
# 档位定义
# ---------------------------------------------------------------------------
pf_name() {
  case "$1" in
    powersave)   echo '省电' ;;
    balanced)    echo '均衡' ;;
    performance) echo '性能' ;;
    turbo)       echo '极速' ;;
    *)           echo '' ;;
  esac
}

pf_desc() {
  case "$1" in
    powersave)   echo '限制最高频率,续航优先' ;;
    balanced)    echo '内核默认,日常最稳' ;;
    performance) echo '满频 + 性能调度,响应优先' ;;
    turbo)       echo '满频 + 抬底频,短时爆发' ;;
    *)           echo '' ;;
  esac
}

# 当前档位(读 conf;读不到算均衡)
pf_current() {
  pfs_m=''
  if [ -f "$CONF" ]; then
    pfs_m=$(sed -n 's/^mode=//p' "$CONF" 2>/dev/null | head -n 1)
  fi
  case "$pfs_m" in
    powersave|balanced|performance|turbo) echo "$pfs_m" ;;
    *) echo 'balanced' ;;
  esac
}

pf_log() {
  echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$LOG" 2>/dev/null
}

# ---------------------------------------------------------------------------
# 原子写:每写一项都记日志(成败都记),返回 0 恒为真
# ---------------------------------------------------------------------------
pf_write() {
  # $1=节点路径  $2=值
  if [ -e "$1" ] && [ -w "$1" ]; then
    if echo "$2" > "$1" 2>/dev/null; then
      pf_log "  ok   $1 <- $2"
      return 0
    fi
    pf_log "  fail $1 <- $2"
    return 1
  fi
  pf_log "  skip $1 (节点不存在或不可写)"
  return 1
}

# 遍历所有 cpuN 的 cpufreq 子节点执行同一动作
pf_each_cpu() {
  # $1=子节点名  $2=值
  pfa_n=0
  for pfa_c in /sys/devices/system/cpu/cpu[0-9]*/cpufreq; do
    [ -d "$pfa_c" ] || continue
    pf_write "$pfa_c/$1" "$2" && pfa_n=$((pfa_n + 1))
  done
  return 0
}

# 从候选列表里挑一个内核真的支持的 governor
pf_pick_gov() {
  # $@=候选(按优先级)
  pfg_have=''
  pfg_f=/sys/devices/system/cpu/cpu0/cpufreq/scaling_available_governors
  [ -f "$pfg_f" ] && pfg_have=$(cat "$pfg_f" 2>/dev/null)
  if [ -z "$pfg_have" ]; then
    # 拿不到可用列表(老内核常见):直接赌第一个候选
    echo "$1"
    return 0
  fi
  for pfg_w in "$@"; do
    case " $pfg_have " in
      *" $pfg_w "*) echo "$pfg_w"; return 0 ;;
    esac
  done
  echo ''
}

pf_each_sched() {
  # $1=调度器名;遍历块设备写 scheduler(需要回读确认)
  pfb_n=0
  for pfb_q in /sys/block/*/queue/scheduler; do
    [ -w "$pfb_q" ] || continue
    pf_write "$pfb_q" "$1" >/dev/null 2>&1
    pfb_n=$((pfb_n + 1))
  done
  echo "$pfb_n"
}

# ---------------------------------------------------------------------------
# 应用某个档
# ---------------------------------------------------------------------------
pf_apply() {
  pfy_mode=$1
  case "$pfy_mode" in
    powersave|balanced|performance|turbo) ;;
    *) echo "未知档位: $pfy_mode" >&2; return 2 ;;
  esac

  pfy_min=$(cat /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_min_freq 2>/dev/null)
  pfy_max=$(cat /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq 2>/dev/null)
  [ -n "$pfy_min" ] || pfy_min=0
  [ -n "$pfy_max" ] || pfy_max=0

  pf_log "== apply $pfy_mode (min=$pfy_min max=$pfy_max) =="

  # ---- 先解除上一档留下的频率限制(否则性能档会被省电档的 max 卡住) ----
  if [ "$pfy_max" -gt 0 ]; then
    pf_each_cpu scaling_max_freq "$pfy_max"
  fi
  if [ "$pfy_min" -gt 0 ]; then
    pf_each_cpu scaling_min_freq "$pfy_min"
  fi

  case "$pfy_mode" in
    powersave)
      pfy_gov=$(pf_pick_gov powersave conservative ondemand)
      # 限频到 ~60%(取 100MHz 对齐的低档位)
      if [ "$pfy_max" -gt 0 ]; then
        pfy_cap=$((pfy_max * 6 / 10))
        pfy_cap=$((pfy_cap / 100000 * 100000))
        [ "$pfy_cap" -lt "$pfy_min" ] && pfy_cap=$pfy_min
        pf_each_cpu scaling_max_freq "$pfy_cap"
      fi
      pf_each_sched noop >/dev/null
      pf_write /proc/sys/vm/swappiness 100
      pf_write /proc/sys/vm/dirty_ratio 30
      pf_write /proc/sys/vm/dirty_background_ratio 10
      ;;
    balanced)
      pfy_gov=$(pf_pick_gov schedutil interactive ondemand)
      pf_each_sched cfq >/dev/null
      pf_write /proc/sys/vm/swappiness 60
      pf_write /proc/sys/vm/dirty_ratio 20
      pf_write /proc/sys/vm/dirty_background_ratio 5
      ;;
    performance)
      pfy_gov=$(pf_pick_gov performance interactive)
      pf_each_sched deadline >/dev/null
      pf_write /proc/sys/vm/swappiness 40
      pf_write /proc/sys/vm/dirty_ratio 20
      pf_write /proc/sys/vm/dirty_background_ratio 5
      ;;
    turbo)
      pfy_gov=$(pf_pick_gov performance interactive)
      # 抬底频到 ~50%,防止调度器一有空就降频
      if [ "$pfy_min" -gt 0 ] && [ "$pfy_max" -gt 0 ]; then
        pfy_fl=$((pfy_min + (pfy_max - pfy_min) / 2))
        pfy_fl=$((pfy_fl / 100000 * 100000))
        pf_each_cpu scaling_min_freq "$pfy_fl"
      fi
      pf_each_sched noop >/dev/null
      pf_write /proc/sys/vm/swappiness 20
      pf_write /proc/sys/vm/dirty_ratio 15
      pf_write /proc/sys/vm/dirty_background_ratio 3
      ;;
  esac

  if [ -n "$pfy_gov" ]; then
    pf_each_cpu scaling_governor "$pfy_gov"
    # devfreq(GPU / 总线)也跟上,能选到同名就用同名
    for pfy_d in /sys/class/devfreq/*/governor; do
      [ -w "$pfy_d" ] || continue
      pf_write "$pfy_d" "$pfy_gov"
    done
    pf_log "  governor=$pfy_gov"
  else
    pf_log "  governor= (内核不支持候选中的任何一个,跳过)"
  fi

  # ---- 持久化 ----
  {
    echo '# Star OS 性能档位(应用写入,勿手改)'
    echo "mode=$pfy_mode"
    echo "updated=$(date +%s)"
  } > "$CONF" 2>/dev/null
  chmod 644 "$CONF" 2>/dev/null

  pf_log "== done $pfy_mode =="
  return 0
}

# ---------------------------------------------------------------------------
# 命令行
# ---------------------------------------------------------------------------
case "$1" in
  status)
    pfc_m=$(pf_current)
    echo "mode=$pfc_m name=$(pf_name "$pfc_m")"
    ;;
  list)
    for pfl_m in powersave balanced performance turbo; do
      echo "$pfl_m|$(pf_name "$pfl_m")|$(pf_desc "$pfl_m")"
    done
    ;;
  apply)
    pf_apply "$2"
    ;;
  restore)
    pf_apply balanced
    ;;
  *)
    echo "用法: perf_mode.sh {status|list|apply <mode>|restore}"
    exit 2
    ;;
esac
