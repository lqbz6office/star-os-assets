#!/system/bin/sh
# ============================================================================
#  Star OS · 星诊 (diagnose.sh)   —— Pro+ / 终身版专属
#  ===========================================================
#  统一工具协议见 tools/power.sh 开头。
#
#  干的事:手表"最近有点卡/有点烫/耗电快"的时候,一次把话说明白 ——
#        内存还剩多少、谁在吃 CPU、有没有偷偷崩过。
#        只读诊断,**不替你动手清东西**(要清有星盾/星控/深度净化)。
#
#  和别的工具的分工:
#    turbo 是"调性能档";星诊是"先告诉我为什么卡"。
#    诊断和建议放一起,用户才知道下一步该点哪个。
# ============================================================================

PWDIR=${0%/*}
[ -d "$PWDIR" ] || PWDIR=/data/adb/modules/zz_star_os
STAR=${STAR_DIR:-/data/adb/star_os}
DG=$STAR/diagnose
LOG=$STAR/logs/diagnose.log

mkdir -p "$DG" "$STAR/logs" 2>/dev/null

dg_log() { echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$LOG" 2>/dev/null; }

dg_tier() {
  dgg_v=0
  if [ -f "$STAR/pro.conf" ]; then
    dgg_v=$(sed -n 's/^tier=//p' "$STAR/pro.conf" 2>/dev/null | head -n 1)
  fi
  case "$dgg_v" in
    ''|*[!0-9]*) echo 0 ;;
    *) echo "$dgg_v" ;;
  esac
}

dg_gate() {
  [ "$(dg_tier)" -ge 2 ] && return 0
  echo "星诊是 Pro+ / 终身版功能,当前等级不够" >&2
  return 5
}

# "1,234,567K" -> "1205MB"
dg_kb2mb() {
  dgk_v=$(echo "$1" | tr -d ',K k')
  case "$dgk_v" in ''|*[!0-9]*) echo "?" ;; *) echo "$((dgk_v / 1024))MB" ;; esac
}

# ---------------------------------------------------------------- 内存
dg_mem() {
  dgm_raw=$(dumpsys meminfo 2>/dev/null)
  if [ -z "$dgm_raw" ]; then
    echo "内存:读不到"
    return 0
  fi
  dgm_t=$(echo "$dgm_raw" | grep -m1 "Total RAM" | tr -s ' ' | cut -d' ' -f3)
  dgm_f=$(echo "$dgm_raw" | grep -m1 "Free RAM" | tr -s ' ' | cut -d' ' -f3)
  if [ -n "$dgm_t" ]; then
    echo "内存:总 $(dg_kb2mb "$dgm_t"),空闲 $(dg_kb2mb "$dgm_f")"
  else
    echo "内存:读不到"
  fi
}

# ---------------------------------------------------------------- CPU
dg_cpu() {
  dgc_load=$(dumpsys cpuinfo 2>/dev/null | grep -m1 "Load:")
  [ -n "$dgc_load" ] && echo "$dgc_load"
  echo "CPU 占用前几名:"
  # 从第 3 行起是各进程占用行,取前 5 行 —— 这两行之前是表头
  dgc_body=$(dumpsys cpuinfo 2>/dev/null | sed -n '3,7p')
  if [ -n "$dgc_body" ]; then
    echo "$dgc_body" | while read -r dgc_l; do
      [ -z "$dgc_l" ] && continue
      echo "  $dgc_l"
    done
  else
    echo "  (读不到)"
  fi
}

# ---------------------------------------------------------------- 崩溃 / ANR
dg_crash() {
  dgd_dir=/data/system/dropbox
  if [ ! -d "$dgd_dir" ]; then
    echo "崩溃记录:读不到"
    return 0
  fi
  dgd_a=$(ls "$dgd_dir" 2>/dev/null | grep -c "anr")
  dgd_c=$(ls "$dgd_dir" 2>/dev/null | grep -c "crash")
  case "$dgd_a" in ''|*[!0-9]*) dgd_a=0 ;; esac
  case "$dgd_c" in ''|*[!0-9]*) dgd_c=0 ;; esac
  echo "崩溃记录:崩溃 $dgd_c 条,无响应 $dgd_a 条"
  if [ "$dgd_c" -gt 0 ] || [ "$dgd_a" -gt 0 ]; then
    echo "最近几条:"
    ls -t "$dgd_dir" 2>/dev/null | grep -E "anr|crash" | head -n 3 | while read -r dgd_f; do
      echo "  $dgd_f"
    done
  fi
}

# ---------------------------------------------------------------- 结论
# 给一句人话,用户才知道下一步点哪儿
dg_advice() {
  dgv_f=$(dumpsys meminfo 2>/dev/null | grep -m1 "Free RAM" | tr -s ' ' | cut -d' ' -f3 | tr -d ',K k')
  case "$dgv_f" in
    ''|*[!0-9]*) echo "建议:数据读不全,可能是系统限制,不影响使用。"; return 0 ;;
  esac
  dgv_mb=$((dgv_f / 1024))
  dgd_a=$(ls /data/system/dropbox 2>/dev/null | grep -c "anr")
  case "$dgd_a" in ''|*[!0-9]*) dgd_a=0 ;; esac
  if [ "$dgv_mb" -lt 200 ]; then
    echo "结论:内存偏紧(${dgv_mb}MB 空闲)。建议去「星盾」冻掉不用的应用,"
    echo "      或者「星控」禁掉几个应用的自启,效果比清后台持久。"
  elif [ "$dgd_a" -gt 3 ]; then
    echo "结论:内存还行(${dgv_mb}MB 空闲),但最近无响应次数偏多。"
    echo "      多半是某个后台应用在抢资源 —— 去「星控」把它禁自启试试。"
  else
    echo "结论:状态正常(空闲 ${dgv_mb}MB)。没发现明显问题。"
  fi
}

# ---------------------------------------------------------------- 状态
dg_status() {
  dg_mem
  echo ""
  dg_crash
  echo ""
  dg_advice
  echo ""
  echo "@item|重新体检一次|act|scan"
  echo "@item|化验 CPU 占用前几名|act|cpu"
  return 0
}

case "$1" in
  meta)
    echo "diagnose|星诊|卡顿/崩溃/内存一眼看清,附一句人话建议|2|scan:重新体检:pri,cpu:看 CPU 占用:ghost"
    ;;
  status)
    dg_gate || exit 5
    dg_status
    ;;
  act)
    dg_gate || exit 5
    case "$2" in
      scan)
        dg_log "手动体检"
        dg_status
        ;;
      cpu)
        dg_cpu
        ;;
      *)
        echo "未知动作:$2" >&2
        exit 2
        ;;
    esac
    ;;
  *)
    echo "用法:$0 {meta|status|act <动作>}" >&2
    exit 2
    ;;
esac
