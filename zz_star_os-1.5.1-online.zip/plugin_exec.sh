#!/system/bin/sh
##########################################################################
# plugin_exec.sh —— Star OS 插件执行器(以 root 运行,是插件系统的唯一入口)
#
# 谁调它:
#   1. Star OS 应用(通过 su):安装 / 卸载 / 启用停用 / 授权 / 运行 / 看日志;
#   2. service.sh(开机):跑所有插件的 boot 钩子;
#   3. 你自己用终端调试。
#
# ---------------------------------------------------------------------
#  子命令
# ---------------------------------------------------------------------
#   list                       列出已装插件(每行一个 JSON,给应用解析)
#   install <file.sosp>        从 .sosp(zip)安装 —— 需要 unzip
#   install-dir <dir>          从已解包的插件目录安装(应用走这条)
#   uninstall <id>             卸载(先跑 uninstall 钩子,再删目录)
#   enable <id> / disable <id> 启用 / 停用
#   perms <id> <csv|->         设置已授权权限(逗号分隔;- 表示全部撤销)
#   run <id> [hook]            手动跑一次(默认 manual 钩子)
#   boot                       跑所有插件的 boot 钩子
#   log <id> [行数]            看插件日志(默认最后 40 行)
#   info <id>                  打印插件元信息
#   catalog                    打印权限清单(给应用的授权页用)
#   version                    版本号
#
# ---------------------------------------------------------------------
#  目录结构(/data/adb/star_os/plugins/)
# ---------------------------------------------------------------------
#   <id>/src/       插件本体(解包内容,只读)
#   <id>/data/      插件可写目录(执行时 cwd 就是这里)
#   <id>/logs/      每次执行的日志
#   <id>/meta.conf  安装时生成的扁平元信息(应用读这个,不用解 JSON)
#   <id>/state.conf 启用状态 + 已授权权限
#   .bin/sos-*      注入给插件的包装命令(见 sos.sh)
#
# ---------------------------------------------------------------------
#  ash 注意事项(本文件的硬规矩)
# ---------------------------------------------------------------------
#   * ash 没有 local —— 所有变量用 pe_ 前缀独占,跨函数也不许重名;
#   * 写文件用 `true > file` 而不是 `: > file`(: 的重定向失败会终止脚本);
#   * 不依赖 bash 特性(没有 [[ ]]、没有数组)。
##########################################################################

MODDIR=${MODDIR:-${0%/*}}
# MODDIR 必须转成绝对路径:插件执行时会把 cwd 切到插件自己的 data 目录,
# 相对路径的 $MODDIR 立刻就失效了 —— 生成的 sos-* 包装命令会找不到
# sos.sh(表现是插件里调 sos-perms 报 127)。设备上本来就是绝对路径,
# 这条主要是给「在电脑上跑测试」和「手工相对路径调用」兜底。
case "$MODDIR" in
  /*) ;;
  *) MODDIR=$(cd "$MODDIR" 2>/dev/null && pwd) ;;
esac
[ -n "$MODDIR" ] || MODDIR=/data/adb/modules/zz_star_os
# 目录可用环境变量覆盖 —— 唯一目的:让 test_plugin.sh 能在电脑上
# 用临时目录跑通整套安装/授权/执行/卸载流程,不必真的刷进手表。
PDIR=${SOS_PLUGINS_DIR:-/data/adb/star_os/plugins}
PLOG=${SOS_PLUGINS_LOG:-/data/adb/star_os/plugins.log}
# 插件执行时可见的 PATH —— 这就是「收窄」的手段:只留 sos-* 包装命令
# (由 pe_make_bin 生成在 $PDIR/.bin),再给最基本的系统目录。
# 两个可用环境变量覆盖的钩子只服务于 test_plugin.sh(电脑上 /system/bin 不存在,
# 得把宿主机的 sh 所在目录补进去才能跑起来)。设备上保持默认即可。
SAFE_PATH=${SOS_SAFE_PATH:-/system/bin:/system/xbin}
SH_BIN=${SOS_SH:-/system/bin/sh}
[ -x "$SH_BIN" ] || SH_BIN=sh
# 生成的 sos-* 包装命令用哪个 shebang。设备上必须是 /system/bin/sh
# (Android 没有 /bin/sh);电脑上没有这个路径,测试时用 SOS_SHEBANG 覆盖。
SOS_SHEBANG=${SOS_SHEBANG:-/system/bin/sh}
# su / setpriv 的绝对路径要提前定下来。
# 为什么不能直接在降权那行写 `PATH=$P sh su ...`:那个 PATH 前缀同样作用于
# su 自己,而收窄后的 PATH 里未必有 su —— 表现就是「su: command not found」,
# 插件直接被判成执行失败(踩过)。先把绝对路径查好,执行时才不受影响。
SU_BIN=$(command -v su 2>/dev/null)
[ -n "$SU_BIN" ] || { [ -x /system/bin/su ] && SU_BIN=/system/bin/su; }
SETPRIV_BIN=$(command -v setpriv 2>/dev/null)
CMDPKG=/system/bin/cmd

mkdir -p "$PDIR" 2>/dev/null

log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" >> "$PLOG" 2>/dev/null; }

# ---------------------------------------------------------------------
# 权限白名单 —— 改这里必须同时改:
#   sosp_schema.json / 插件开发文档 / Windows 审核工具 / App 的授权页
# 格式:每行「权限名|风险档|说明」
# ---------------------------------------------------------------------
PE_CATALOG='ui|low|显示插件自己的界面
notify|low|弹出提示/通知
storage.read|mid|读取内部存储(/sdcard)中的文件
storage.write|mid|写入内部存储中的文件
network|mid|联网(下载/上传)
settings.read|mid|读取系统设置与系统属性
settings.write|mid|修改系统设置
shell|high|以 root 身份执行任意命令(完全控制)
system.prop|high|修改系统属性(resetprop)
app.install|high|安装或卸载应用'

# 低风险权限:安装时默认勾选(其余一律默认关闭)
PE_DEFAULT_PERMS="ui,notify"

# 钩子白名单
#   ⚠ 必须用逗号分隔:下面 pe_hook_valid 用的是 `*",$1,"*` 这种
#     「逗号夹住」的匹配法 —— 之前写成空格分隔,结果 `,install boot...`
#     里 install 后面跟的是空格不是逗号,合法钩子被误判成未知(已修)。
PE_HOOKS="install,boot,manual,uninstall"

# ---------------------------------------------------------------------
# 小工具
# ---------------------------------------------------------------------

# 权限是否在授权列表里:$1=已授权 csv,$2=要查的权限
pe_has_perm() {
  case ",$1," in *",$2,"*) return 0 ;; *) return 1 ;; esac
}

# 权限名合法?
pe_perm_valid() {
  echo "$PE_CATALOG" | while IFS='|' read -r _c_n _c_r _c_d; do
    [ "$_c_n" = "$1" ] && { echo yes; return 0; }
  done | grep -q yes
}

# 钩子名合法?
pe_hook_valid() {
  case ",$PE_HOOKS," in *",$1,"*) return 0 ;; *) return 1 ;; esac
}

# 字段清洗:去掉引号/反斜杠/换行/回车,并截断长度。$1=原值 $2=最大长度
pe_clean() {
  printf '%s' "$1" | tr -d '"' | tr -d '\\' | tr -d '\r' | tr '\n' ' ' | cut -c "1-$2"
}

# JSON 字符串转义(元信息里可能有引号/中文)
pe_esc() {
  printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g'
}

# 读 meta.conf / state.conf 里的一个键:$1=文件 $2=键
pe_get() {
  [ -f "$1" ] || return 1
  sed -n "s/^$2=//p" "$1" 2>/dev/null | head -1
}

# 写/改 state.conf 里的一个键:$1=id $2=键 $3=值
pe_set_state() {
  pe_ss_f="$PDIR/$1/state.conf"
  if [ -f "$pe_ss_f" ]; then
    grep -v "^$2=" "$pe_ss_f" > "$pe_ss_f.tmp" 2>/dev/null
    mv -f "$pe_ss_f.tmp" "$pe_ss_f" 2>/dev/null
  fi
  echo "$2=$3" >> "$pe_ss_f"
}

# id 合法性:反向域名,小写字母数字下划线点,必须带点
pe_id_valid() {
  case "$1" in
    *[!a-z0-9._]*|'') return 1 ;;
    *.*) return 0 ;;
    *) return 1 ;;
  esac
}

# 从一份 plugin.json 里取一个字段的值:$1=文件 $2=键
#
# 同时兼容两种写法 —— 字符串带引号,数字/布尔不带:
#     "versionCode": 1        <- 数字,取到 , 或 } 为止
#     "name": "示例插件"       <- 字符串,取一对引号里的内容
# 一开始只按「字符串」解析,结果 versionCode 取回来的是下一个字段的
# author(下一个引号对),这个坑已经踩过并修掉了。
#
# 为什么用 awk 而不是 sed:sed 要匹配引号就得写 '"'"' 这种拼接,
# 又长又脆(还让 bash 报过「引号没闭合」)。awk 里用 sprintf("%c",34)
# 直接造出双引号字符,整个程序放在单引号里,一个转义都不用写。
pe_json_str() {
  awk -v key="\"$2\"" '
    { all = all " " $0 }
    END {
      i = index(all, key)
      if (i == 0) exit
      rest = substr(all, i + length(key))
      c = index(rest, ":")
      if (c == 0) exit
      rest = substr(rest, c + 1)
      sub(/^[ \t]+/, "", rest)
      q = sprintf("%c", 34)
      if (substr(rest, 1, 1) == q) {
        rest = substr(rest, 2)
        b = index(rest, q)
        if (b == 0) exit
        printf "%s", substr(rest, 1, b - 1)
      } else {
        n = length(rest); out = ""
        for (k = 1; k <= n; k++) {
          ch = substr(rest, k, 1)
          if (ch == "," || ch == "}" || ch == " " || ch == "\t") break
          out = out ch
        }
        printf "%s", out
      }
    }' "$1" 2>/dev/null
}

# 从 plugin.json 里取数组字段(如 "permissions": ["a","b"])-> 逗号拼接
pe_json_arr() {
  awk -v key="\"$2\"" '
    { all = all " " $0 }
    END {
      i = index(all, key)
      if (i == 0) exit
      rest = substr(all, i + length(key))
      o = index(rest, "[")
      if (o == 0) exit
      rest = substr(rest, o + 1)
      c = index(rest, "]")
      if (c == 0) exit
      body = substr(rest, 1, c - 1)
      n = split(body, parts, ",")
      out = ""
      for (m = 1; m <= n; m++) {
        gsub(/[ \t\r\n]/, "", parts[m])
        gsub(sprintf("%c", 34), "", parts[m])
        gsub(/\047/, "", parts[m])
        if (parts[m] != "") out = (out == "" ? parts[m] : out "," parts[m])
      }
      printf "%s", out
    }' "$1" 2>/dev/null
}

# ---------------------------------------------------------------------
# 注入包装命令:$PDIR/.bin/sos-* -> 统一转到 sos.sh
# ---------------------------------------------------------------------
pe_make_bin() {
  mkdir -p "$PDIR/.bin" 2>/dev/null
  for pe_mb_c in fs-read fs-write fs-list http notify settings-get settings-put \
                 getprop setprop install-apk log perms id dir api; do
    pe_mb_f="$PDIR/.bin/sos-$pe_mb_c"
    printf '#!%s\nexec %s %s/sos.sh %s "$@"\n' \
      "$SOS_SHEBANG" "$SH_BIN" "$MODDIR" "$pe_mb_c" > "$pe_mb_f" 2>/dev/null
    chmod 0755 "$pe_mb_f" 2>/dev/null
  done
  chmod 0755 "$PDIR/.bin" 2>/dev/null
}

# ---------------------------------------------------------------------
# 安装:从已解包目录
#   $1 = 解包后的插件根目录(里面有 plugin.json)
#   返回 0 成功 / 非 0 失败(并把原因打到 stderr)
# ---------------------------------------------------------------------
pe_install_dir() {
  pe_id_d="$1"
  [ -d "$pe_id_d" ] || { echo "目录不存在: $pe_id_d" >&2; return 1; }
  pe_id_mf="$pe_id_d/plugin.json"
  [ -f "$pe_id_mf" ] || { echo "缺少 plugin.json" >&2; return 1; }

  # ---- 字段 ----
  pe_id_v=$(pe_json_str "$pe_id_mf" id)
  pe_id_n=$(pe_json_str "$pe_id_mf" name)
  pe_id_ver=$(pe_json_str "$pe_id_mf" version)
  pe_id_vc=$(pe_json_str "$pe_id_mf" versionCode)
  pe_id_au=$(pe_json_str "$pe_id_mf" author)
  pe_id_de=$(pe_json_str "$pe_id_mf" description)
  pe_id_en=$(pe_json_str "$pe_id_mf" entry)
  pe_id_ma=$(pe_json_str "$pe_id_mf" minApi)
  pe_id_pm=$(pe_json_arr "$pe_id_mf" permissions)
  pe_id_hk=$(pe_json_arr "$pe_id_mf" hooks)

  [ -n "$pe_id_en" ] || pe_id_en=main.sh
  [ -n "$pe_id_ma" ] || pe_id_ma=27
  [ -n "$pe_id_vc" ] || pe_id_vc=1

  # ---- 必填校验 ----
  pe_id_valid "$pe_id_v" || { echo "id 不合法(要求反向域名,如 com.you.hello): $pe_id_v" >&2; return 1; }
  [ -n "$pe_id_n" ]  || { echo "缺少 name"  >&2; return 1; }
  [ -n "$pe_id_ver" ] || { echo "缺少 version" >&2; return 1; }
  case "$pe_id_vc" in ''|*[!0-9]*) echo "versionCode 必须是整数: $pe_id_vc" >&2; return 1 ;; esac
  case "$pe_id_ma" in ''|*[!0-9]*) echo "minApi 必须是整数" >&2; return 1 ;; esac
  [ "$pe_id_ma" -le 27 ] || { echo "minApi=$pe_id_ma 高于本机 SDK 27,拒绝安装" >&2; return 1; }
  [ -f "$pe_id_d/$pe_id_en" ] || { echo "入口脚本不存在: $pe_id_en" >&2; return 1; }

  # ---- 权限必须在白名单里(声明了不存在的权限 = 直接拒) ----
  if [ -n "$pe_id_pm" ]; then
    for pe_id_p in $(printf '%s' "$pe_id_pm" | tr ',' ' '); do
      pe_perm_valid "$pe_id_p" || { echo "未知权限: $pe_id_p" >&2; return 1; }
    done
  fi

  # ---- 钩子必须在白名单里 ----
  if [ -n "$pe_id_hk" ]; then
    for pe_id_h in $(printf '%s' "$pe_id_hk" | tr ',' ' '); do
      pe_hook_valid "$pe_id_h" || { echo "未知钩子: $pe_id_h" >&2; return 1; }
    done
  fi

  # ---- 目录大小上限(防手滑塞进来一个系统镜像) ----
  pe_id_sz=$(du -sk "$pe_id_d" 2>/dev/null | awk '{print $1}')
  case "$pe_id_sz" in ''|*[!0-9]*) pe_id_sz=0 ;; esac
  [ "$pe_id_sz" -le 20480 ] || { echo "插件解包后 ${pe_id_sz}KB,超过 20MB 上限" >&2; return 1; }

  # ---- 落地 ----
  pe_id_dst="$PDIR/$pe_id_v"
  pe_id_old=""
  [ -f "$pe_id_dst/state.conf" ] && pe_id_old=$(cat "$pe_id_dst/state.conf" 2>/dev/null)

  rm -rf "$pe_id_dst" 2>/dev/null
  mkdir -p "$pe_id_dst" "$pe_id_dst/data" "$pe_id_dst/logs" 2>/dev/null
  cp -rf "$pe_id_d" "$pe_id_dst/src" 2>/dev/null
  [ -d "$pe_id_dst/src" ] || { echo "复制插件内容失败" >&2; rm -rf "$pe_id_dst"; return 1; }

  # 元信息(扁平化,应用直接读,不必解 JSON)
  {
    echo "id=$pe_id_v"
    echo "name=$(pe_clean "$pe_id_n" 40)"
    echo "version=$(pe_clean "$pe_id_ver" 20)"
    echo "versionCode=$pe_id_vc"
    echo "author=$(pe_clean "$pe_id_au" 30)"
    echo "description=$(pe_clean "$pe_id_de" 120)"
    echo "entry=$(pe_clean "$pe_id_en" 60)"
    echo "minApi=$pe_id_ma"
    echo "permissions=$pe_id_pm"
    echo "hooks=$pe_id_hk"
    echo "size=$(du -sk "$pe_id_dst/src" 2>/dev/null | awk '{print $1}')"
    echo "installed=$(date '+%s')"
  } > "$pe_id_dst/meta.conf" 2>/dev/null

  # 状态:重装保留原来的授权,新增的权限默认关
  if [ -n "$pe_id_old" ]; then
    printf '%s\n' "$pe_id_old" > "$pe_id_dst/state.conf"
  else
    pe_set_state "$pe_id_v" enabled 1
    pe_set_state "$pe_id_v" perms "$PE_DEFAULT_PERMS"
  fi

  pe_make_bin
  log "插件已安装: $pe_id_v v$pe_id_ver (vc$pe_id_vc, perms=${pe_id_pm:-无})"

  # install 钩子(失败不影响安装结果)
  pe_hook_list=$(pe_get "$pe_id_dst/meta.conf" hooks)
  case ",$pe_hook_list," in
    *",install,"*) pe_run "$pe_id_v" install >/dev/null 2>&1 ;;
  esac

  echo "OK $pe_id_v"
  return 0
}

# ---------------------------------------------------------------------
# 执行一个插件的某个钩子
#   $1 = id, $2 = 钩子(默认 manual)
#   stdout/stderr 都进插件日志;同时把最后 20 行回显给调用者
# ---------------------------------------------------------------------
pe_run() {
  pe_r_id="$1"
  pe_r_hk="$2"
  [ -n "$pe_r_hk" ] || pe_r_hk=manual

  pe_r_dir="$PDIR/$pe_r_id"
  [ -f "$pe_r_dir/meta.conf" ] || { echo "插件未安装: $pe_r_id" >&2; return 1; }
  [ -f "$pe_r_dir/state.conf" ] || { echo "插件状态丢失: $pe_r_id" >&2; return 1; }

  pe_r_en=$(pe_get "$pe_r_dir/state.conf" enabled)
  [ "$pe_r_en" = "1" ] || { echo "插件已停用: $pe_r_id" >&2; return 1; }

  pe_r_hooks=$(pe_get "$pe_r_dir/meta.conf" hooks)
  pe_hook_valid "$pe_r_hk" || { echo "未知钩子: $pe_r_hk" >&2; return 1; }
  case ",$pe_r_hooks," in
    *",$pe_r_hk,"*) ;;
    *) echo "插件未声明 $pe_r_hk 钩子(它声明的是: ${pe_r_hooks:-无})" >&2; return 1 ;;
  esac

  pe_r_entry=$(pe_get "$pe_r_dir/meta.conf" entry)
  [ -n "$pe_r_entry" ] || pe_r_entry=main.sh
  [ -f "$pe_r_dir/src/$pe_r_entry" ] || { echo "入口脚本丢失: $pe_r_entry" >&2; return 1; }

  pe_r_perms=$(pe_get "$pe_r_dir/state.conf" perms)
  pe_r_lg="$pe_r_dir/logs/$(date '+%Y%m%d-%H%M%S')-$pe_r_hk.log"

  # 入口脚本必须是 shell 脚本(只接受 #! 开头或本身就是 .sh)
  pe_r_first=$(head -c 2 "$pe_r_dir/src/$pe_r_entry" 2>/dev/null)
  case "$pe_r_entry" in
    *.sh) ;;
    *) [ "$pe_r_first" = "#!" ] || { echo "入口必须是 shell 脚本: $pe_r_entry" >&2; return 1; } ;;
  esac

  # ---- 执行身份 ----
  #   授权了 shell -> 直接 root 跑(插件本来就在 root 模块里,本就够格);
  #   没授权 shell -> 尽量降权到 uid 2000(shell),并把 PATH 收窄成
  #                   「只有 sos-* 包装命令 + 基本工具」。
  #   降权失败(ROM 不支持 su 换用户/没有 setpriv)时按 unsafe 记录并
  #   仍然执行 —— 但会在日志里明确标出来,审核也以此为准。
  pe_r_identity=root
  pe_r_drop=""

  if ! pe_has_perm "$pe_r_perms" shell; then
    if [ -n "$SU_BIN" ] && "$SU_BIN" 2000 -c 'true' >/dev/null 2>&1; then
      pe_r_identity="shell(降权)"
      pe_r_drop="su"
    elif [ -n "$SETPRIV_BIN" ]; then
      pe_r_identity="shell(setpriv)"
      pe_r_drop="setpriv"
    else
      pe_r_identity="root(无法降权)"
      log "警告: $pe_r_id 未授权 shell,但本机无法降权,只能以 root 执行"
    fi
  fi

  {
    echo "==== Star OS 插件执行 ===="
    echo "插件 : $pe_r_id"
    echo "钩子 : $pe_r_hk"
    echo "时间 : $(date '+%Y-%m-%d %H:%M:%S')"
    echo "身份 : $pe_r_identity"
    echo "权限 : ${pe_r_perms:-无}"
    echo "入口 : $pe_r_entry"
    echo "=========================="
  } > "$pe_r_lg" 2>/dev/null

  # 插件可见的环境变量
  SOS_ID="$pe_r_id"
  SOS_PERMS="$pe_r_perms"
  SOS_HOOK="$pe_r_hk"
  SOS_DIR="$pe_r_dir"
  SOS_SRC="$pe_r_dir/src"
  SOS_DATA="$pe_r_dir/data"
  SOS_MODDIR="$MODDIR"
  SOS_PLUGIN_HOME="/data/adb/star_os/plugins"
  SOS_API=1
  export SOS_ID SOS_PERMS SOS_HOOK SOS_DIR SOS_SRC SOS_DATA SOS_MODDIR SOS_PLUGIN_HOME SOS_API

  pe_r_path="$PDIR/.bin:$SAFE_PATH"

  if [ -n "$pe_r_drop" ]; then
    if [ "$pe_r_drop" = "su" ]; then
      ( cd "$pe_r_dir/data" && PATH="$pe_r_path" "$SU_BIN" 2000 -c \
          "cd '$pe_r_dir/data' && PATH='$pe_r_path' '$SH_BIN' '$pe_r_dir/src/$pe_r_entry'" ) \
          >> "$pe_r_lg" 2>&1
      pe_r_rc=$?
    else
      ( cd "$pe_r_dir/data" && PATH="$pe_r_path" "$SETPRIV_BIN" --reuid 2000 --regid 2000 \
          --clear-groups "$SH_BIN" "$pe_r_dir/src/$pe_r_entry" ) >> "$pe_r_lg" 2>&1
      pe_r_rc=$?
    fi
  else
    ( cd "$pe_r_dir/data" && PATH="$pe_r_path" "$SH_BIN" "$pe_r_dir/src/$pe_r_entry" ) \
        >> "$pe_r_lg" 2>&1
    pe_r_rc=$?
  fi

  echo "---- 退出码: $pe_r_rc ----" >> "$pe_r_lg" 2>/dev/null
  log "插件执行: $pe_r_id/$pe_r_hk -> 退出码 $pe_r_rc ($pe_r_identity)"

  echo "插件 $pe_r_id 的 $pe_r_hk 钩子执行完毕,退出码 $pe_r_rc"
  echo "日志: $pe_r_lg"
  tail -n 20 "$pe_r_lg" 2>/dev/null
  return "$pe_r_rc"
}

# ---------------------------------------------------------------------
# list:每行一个 JSON,给应用解析
# ---------------------------------------------------------------------
pe_list() {
  pe_l_found=0
  for pe_l_d in "$PDIR"/*/; do
    [ -d "$pe_l_d" ] || continue
    pe_l_m="$pe_l_d/meta.conf"
    [ -f "$pe_l_m" ] || continue
    pe_l_found=1
    pe_l_id=$(pe_get "$pe_l_m" id)
    pe_l_en=$(pe_get "$pe_l_d/state.conf" enabled)
    [ "$pe_l_en" = "1" ] || pe_l_en=0
    pe_l_pm=$(pe_get "$pe_l_d/state.conf" perms)
    printf '{"id":"%s","name":"%s","version":"%s","versionCode":%s,"author":"%s","description":"%s","permissions":"%s","granted":"%s","hooks":"%s","enabled":%s,"size":%s,"installed":%s}\n' \
      "$(pe_esc "$pe_l_id")" \
      "$(pe_esc "$(pe_get "$pe_l_m" name)")" \
      "$(pe_esc "$(pe_get "$pe_l_m" version)")" \
      "$(pe_get "$pe_l_m" versionCode)" \
      "$(pe_esc "$(pe_get "$pe_l_m" author)")" \
      "$(pe_esc "$(pe_get "$pe_l_m" description)")" \
      "$(pe_esc "$(pe_get "$pe_l_m" permissions)")" \
      "$(pe_esc "$pe_l_pm")" \
      "$(pe_esc "$(pe_get "$pe_l_m" hooks)")" \
      "$pe_l_en" \
      "$(pe_get "$pe_l_m" size)" \
      "$(pe_get "$pe_l_m" installed)"
  done
  [ "$pe_l_found" = "1" ] || echo '{"count":0}'
}

# ---------------------------------------------------------------------
# catalog:权限清单(应用授权页展示)
# ---------------------------------------------------------------------
pe_catalog() {
  echo "$PE_CATALOG" | while IFS='|' read -r pe_c_n pe_c_r pe_c_d; do
    [ -n "$pe_c_n" ] || continue
    pe_c_def=0
    pe_has_perm "$PE_DEFAULT_PERMS" "$pe_c_n" && pe_c_def=1
    printf '{"perm":"%s","risk":"%s","desc":"%s","default":%s}\n' \
      "$pe_c_n" "$pe_c_r" "$(pe_esc "$pe_c_d")" "$pe_c_def"
  done
}

# =====================================================================
# 主入口
# =====================================================================
pe_cmd="$1"
shift 2>/dev/null

case "$pe_cmd" in
  list)
    pe_list
    ;;

  catalog)
    pe_catalog
    ;;

  version)
    echo "star-os-plugin-exec 1"
    ;;

  makebin)
    pe_make_bin
    echo "OK"
    ;;

  install)
    pe_i_f="$1"
    [ -f "$pe_i_f" ] || { echo "文件不存在: $pe_i_f" >&2; exit 1; }
    pe_i_tmp="$PDIR/.tmp-$$"
    rm -rf "$pe_i_tmp" 2>/dev/null
    mkdir -p "$pe_i_tmp" 2>/dev/null
    if command -v unzip >/dev/null 2>&1; then
      unzip -q -o "$pe_i_f" -d "$pe_i_tmp" >> "$PLOG" 2>&1
    else
      busybox unzip -q -o "$pe_i_f" -d "$pe_i_tmp" >> "$PLOG" 2>&1
    fi
    if [ ! -f "$pe_i_tmp/plugin.json" ]; then
      rm -rf "$pe_i_tmp" 2>/dev/null
      echo "解包失败:包里没有 plugin.json(或本机缺 unzip)" >&2
      exit 1
    fi
    pe_install_dir "$pe_i_tmp"
    pe_i_rc=$?
    rm -rf "$pe_i_tmp" 2>/dev/null
    exit $pe_i_rc
    ;;

  install-dir)
    pe_install_dir "$1"
    exit $?
    ;;

  uninstall)
    pe_u_id="$1"
    pe_u_dir="$PDIR/$pe_u_id"
    [ -f "$pe_u_dir/meta.conf" ] || { echo "插件未安装: $pe_u_id" >&2; exit 1; }
    pe_u_hk=$(pe_get "$pe_u_dir/meta.conf" hooks)
    case ",$pe_u_hk," in
      *",uninstall,"*) pe_run "$pe_u_id" uninstall >/dev/null 2>&1 ;;
    esac
    rm -rf "$pe_u_dir" 2>/dev/null
    log "插件已卸载: $pe_u_id"
    echo "OK 已卸载 $pe_u_id"
    ;;

  enable|disable)
    # ⚠ 主入口已经 shift 过一次,所以这里第一个参数就是 $1(不是 $2)。
    #   之前写成 $2,结果 id 恒为空 -> 报「插件未安装:」,这个坑已修。
    pe_e_id="$1"
    pe_e_dir="$PDIR/$pe_e_id"
    [ -f "$pe_e_dir/meta.conf" ] || { echo "插件未安装: $pe_e_id" >&2; exit 1; }
    if [ "$pe_cmd" = "enable" ]; then
      pe_set_state "$pe_e_id" enabled 1
    else
      pe_set_state "$pe_e_id" enabled 0
    fi
    log "插件$([ "$pe_cmd" = enable ] && echo 启用 || echo 停用): $pe_e_id"
    echo "OK"
    ;;

  perms)
    pe_p_id="$1"
    pe_p_csv="$2"
    pe_p_dir="$PDIR/$pe_p_id"
    [ -f "$pe_p_dir/meta.conf" ] || { echo "插件未安装: $pe_p_id" >&2; exit 1; }
    [ "$pe_p_csv" = "-" ] && pe_p_csv=""
    # 只允许授予插件自己声明过的权限(防止应用侧手滑提权)
    pe_p_decl=$(pe_get "$pe_p_dir/meta.conf" permissions)
    if [ -n "$pe_p_csv" ]; then
      for pe_p_p in $(printf '%s' "$pe_p_csv" | tr ',' ' '); do
        pe_has_perm "$pe_p_decl" "$pe_p_p" || {
          echo "插件没有声明权限 $pe_p_p,拒绝授予" >&2; exit 1; }
      done
    fi
    pe_set_state "$pe_p_id" perms "$pe_p_csv"
    log "插件授权变更: $pe_p_id -> ${pe_p_csv:-无}"
    echo "OK"
    ;;

  run)
    pe_run "$1" "${2:-manual}"
    exit $?
    ;;

  boot)
    # 开机时跑所有插件的 boot 钩子;单个失败不影响其它插件,更不影响开机。
    # 自己负责等系统起来(最多 3 分钟)+ 再留 15 秒让系统喘口气 ——
    # 开机阶段跟系统抢资源会把整个开机拖慢,插件是附加功能,不配让系统等它。
    pe_b_n=0
    while [ "$(getprop sys.boot_completed)" != "1" ] && [ "$pe_b_n" -lt 180 ]; do
      sleep 1
      pe_b_n=$((pe_b_n + 1))
    done
    if [ "$(getprop sys.boot_completed)" != "1" ]; then
      log "插件: 等开机完成超时(3 分钟),boot 钩子本次跳过"
      echo "SKIP"
      exit 0
    fi
    sleep 15

    pe_b_any=0
    for pe_b_d in "$PDIR"/*/; do
      [ -d "$pe_b_d" ] || continue
      pe_b_m="$pe_b_d/meta.conf"
      [ -f "$pe_b_m" ] || continue
      pe_b_id=$(pe_get "$pe_b_m" id)
      pe_b_hk=$(pe_get "$pe_b_m" hooks)
      case ",$pe_b_hk," in *",boot,"*) ;; *) continue ;; esac
      pe_b_en=$(pe_get "$pe_b_d/state.conf" enabled)
      [ "$pe_b_en" = "1" ] || continue
      pe_b_any=1
      pe_run "$pe_b_id" boot >/dev/null 2>&1
      log "开机钩子: $pe_b_id 完成"
    done
    [ "$pe_b_any" = "1" ] || log "插件: 没有声明 boot 钩子的启用插件"
    echo "OK"
    ;;

  log)
    pe_g_dir="$PDIR/$1/logs"
    pe_g_n="${2:-40}"
    case "$pe_g_n" in ''|*[!0-9]*) pe_g_n=40 ;; esac
    pe_g_last=$(ls -1 "$pe_g_dir" 2>/dev/null | tail -1)
    [ -n "$pe_g_last" ] || { echo "(还没有执行记录)"; exit 0; }
    echo "== $pe_g_last =="
    tail -n "$pe_g_n" "$pe_g_dir/$pe_g_last" 2>/dev/null
    ;;

  info)
    pe_i_d="$PDIR/$1"
    [ -f "$pe_i_d/meta.conf" ] || { echo "插件未安装: $1" >&2; exit 1; }
    cat "$pe_i_d/meta.conf" 2>/dev/null
    echo "state:"
    cat "$pe_i_d/state.conf" 2>/dev/null
    ;;

  ''|help|-h|--help)
    sed -n '2,40p' "$0"
    ;;

  *)
    echo "未知命令: $pe_cmd(用 help 看用法)" >&2
    exit 1
    ;;
esac

exit 0
