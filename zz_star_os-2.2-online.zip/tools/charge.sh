#!/system/bin/sh
# ============================================================================
#  Star OS · 星充 (charge.sh)   —— 基础功能(免费,人人可用)
#  ===========================================================
#  统一工具协议见 tools/power.sh 开头。
#
#  干的事:充电时看看到底充得快不快、烫不烫、电池老没老;
#        充满自动提醒一声(可以关掉)。
#
#  为什么免费:电池健康是每个人都该知道的,不该藏起来卖。
#
#  数据来源:/sys/class/power_supply/battery 下的内核节点(和 power.sh 同源),
#  只是 power 看电量百分比,星充看电压/电流/温度/健康这些"体检项"。
# ============================================================================

PWDIR=${0%/*}
[ -d "$PWDIR" ] || PWDIR=/data/adb/modules/zz_star_os
STAR=${STAR_DIR:-/data/adb/star_os}
CG=$STAR/charge
CONF=$CG/conf
LOG=$STAR/logs/charge.log

mkdir -p "$CG" "$STAR/logs" 2>/dev/null

cg_log() { echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$LOG" 2>/dev/null; }

# 留环境变量口子,便于在电脑上跑测试
CG_SYS=${CHARGE_SYS_DIR:-/sys/class/power_supply/battery}

cg_node() {
  cgn_v=$(cat "$CG_SYS/$1" 2>/dev/null)
  case "$cgn_v" in ''|*[!0-9\-]*) echo "" ;; *) echo "$cgn_v" ;; esac
}

cg_level() {
  cgl_v=$(cg_node capacity)
  case "$cgl_v" in ''|*[!0-9]*) echo -1 ;; *) echo "$cgl_v" ;; esac
}

cg_status_word() {
  cgs_v=$(cat "$CG_SYS/status" 2>/dev/null)
  case "$cgs_v" in
    Charging|charging) echo "充电中" ;;
    Full|full) echo "已充满" ;;
    Discharging|discharging) echo "放电中" ;;
    Not\ charging|not\ charging) echo "未充电" ;;
    '') echo "未知" ;;
    *) echo "$cgs_v" ;;
  esac
}

cg_charging() {
  cgs_v=$(cat "$CG_SYS/status" 2>/dev/null)
  case "$cgs_v" in Charging|Full|charging|full) echo 1 ;; *) echo 0 ;; esac
}

# 充满提醒开关(默认开)
cg_notify_conf() {
  cgnf_v=$(sed -n 's/^notify=//p' "$CONF" 2>/dev/null | head -n 1)
  case "$cgnf_v" in 0) echo 0 ;; *) echo 1 ;; esac
}

cg_notify_set() {
  true > "$CONF"
  echo "notify=$1" >> "$CONF"
}

cg_notify() {
  # 走 shell 的通知通道;老机型没有就静默跳过,不能因为通知失败影响别的
  if command -v cmd >/dev/null 2>&1; then
    cmd notification post -S bigtext -t "星充" staros_charge "$1" >/dev/null 2>&1
  fi
  cg_log "notify: $1"
}

# 温度:内核给的是 0.1 摄氏度(如 320 => 32.0C)
cg_temp_c() {
  cgt_v=$(cg_node temp)
  case "$cgt_v" in
    ''|*[!0-9\-]*) echo "" ;;
    *) echo "$((cgt_v / 10)).$((cgt_v % 10))" ;;
  esac
}

# 充电功率估算:µV * µA = pW,pW / 1e12 = W
# ⚠ 电流符号各机器不一致(有的充电为负),所以取绝对值再标注方向
cg_power() {
  cgp_v=$(cg_node voltage_now)
  cgp_i=$(cg_node current_now)
  [ -z "$cgp_v" ] && { echo ""; return 0; }
  [ -z "$cgp_i" ] && { echo ""; return 0; }
  [ "$cgp_i" -lt 0 ] && cgp_i=$((0 - cgp_i))
  # W = V*I / 1e12,保留两位
  cgp_x=$((cgp_v * cgp_i / 10000000000))
  cgp_f=$((cgp_v * cgp_i / 100000000 % 100))
  echo "$cgp_x.$cgp_f"
}

cg_health_word() {
  cgh_v=$(cat "$CG_SYS/health" 2>/dev/null)
  case "$cgh_v" in
    Good|good) echo "良好" ;;
    Overheat|overheat) echo "过热" ;;
    Dead|dead) echo "已损坏" ;;
    Over\ voltage|over_voltage) echo "电压过高" ;;
    Unspecified\ failure|unspecified_failure) echo "异常" ;;
    Cold|cold) echo "过冷" ;;
    '') echo "读不到" ;;
    *) echo "$cgh_v" ;;
  esac
}

# ---------------------------------------------------------------- 状态
cg_status() {
  cgl=$(cg_level)
  cgw=$(cg_status_word)
  if [ "$cgl" -ge 0 ]; then
    echo "电量:${cgl}% ($cgw)"
  else
    echo "电量:读不到"
  fi
  cgv=$(cg_node voltage_now)
  if [ -n "$cgv" ]; then
    echo "电压:$((cgv / 1000)) mV"
  fi
  cgi=$(cg_node current_now)
  if [ -n "$cgi" ]; then
    cgai=$cgi
    [ "$cgai" -lt 0 ] && cgai=$((0 - cgai))
    cgdir="充电"
    [ "$cg_status_word" = "放电中" ] && cgdir="放电"
    echo "电流:${cgai} µA ($cgdir)"
  fi
  cgp=$(cg_power)
  [ -n "$cgp" ] && echo "功率:约 ${cgp} W"
  cgt=$(cg_temp_c)
  [ -n "$cgt" ] && echo "温度:${cgt} °C"
  echo "健康:$(cg_health_word)"
  if [ "$(cg_notify_conf)" = "1" ]; then
    echo "充满提醒:开"
  else
    echo "充满提醒:关"
  fi
  echo ""
  if [ "$(cg_notify_conf)" = "1" ]; then
    echo "@item|关掉充满提醒|act|toggle"
  else
    echo "@item|开启充满提醒|act|toggle"
  fi
  return 0
}

case "$1" in
  meta)
    echo "charge|星充|充电速度/温度/健康,充满自动提醒|0|toggle:充满提醒开关:pri,now:立刻体检一次:ghost"
    ;;
  status)
    cg_status
    ;;
  act)
    case "$2" in
      toggle)
        if [ "$(cg_notify_conf)" = "1" ]; then
          cg_notify_set 0
          echo "充满提醒:已关闭"
        else
          cg_notify_set 1
          echo "充满提醒:已开启"
          echo "充满电(或到 100%)时会收到一条通知。"
        fi
        ;;
      now)
        cg_status
        ;;
      *)
        echo "未知动作:$2" >&2
        exit 2
        ;;
    esac
    ;;
  tick)
    if [ "$(cg_notify_conf)" != "1" ]; then
      exit 0
    fi
    cgl=$(cg_level)
    cgs=$(cg_status_word)
    # 只在"从没满变成满"的那一刻提醒一次,别每两分钟叫一回。
    # 标记写在 .notified 的**内容**里(1=已提醒),不靠"文件在不在"，
    # 这样清除标记只要改写内容,少一次文件操作。
    if [ "$(cg_charging)" = "1" ]; then
      if [ "$cgl" -ge 100 ] || [ "$cgs" = "已充满" ]; then
        if [ "$(cat "$CG/.notified" 2>/dev/null)" != "1" ]; then
          cg_notify "已充满 100%,可以拔了"
          echo "1" > "$CG/.notified"
        fi
      else
        echo "0" > "$CG/.notified"
      fi
    else
      echo "0" > "$CG/.notified"
    fi
    ;;
  daemon)
    cg_log "星充 daemon 启动 (pid=$$)"
    while true; do
      "$0" tick >/dev/null 2>&1
      sleep 120
    done
    ;;
  *)
    echo "用法:$0 {meta|status|act <动作>|tick|daemon}" >&2
    exit 2
    ;;
esac
