#!/system/bin/sh
# ============================================================================
#  Star OS · 一键加速 (boost.sh)   —— 基础功能(免费,人人可用)
#  ===========================================================
#  统一工具协议见 tools/power.sh 开头。
#
#    · 立即加速:清后台 + 丢内核缓存
#    · 整理存储:fstrim(顺手,但慢,做成单独按钮)
#    · 内存详情:还剩多少、谁在占
#
#  只说真话:清完能省多少内存就显示多少,不做"清掉 999MB"这种假数字。
#  实际上 Androd 缓存本来就是拿来用的,清完应用重启会更耗电 ——
#  所以这里给的判断标准是"可用内存",不是"清掉了多少"。
# ============================================================================

PWDIR=${0%/*}
[ -d "$PWDIR" ] || PWDIR=/data/adb/modules/zz_star_os
STAR=${STAR_DIR:-/data/adb/star_os}
BD=$STAR/boost
LOG=$STAR/logs/boost.log

mkdir -p "$BD" "$STAR/logs" 2>/dev/null

bo_log() { echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$LOG" 2>/dev/null; }

# 内存信息文件(可覆盖,为了能在电脑上测试)
BO_MEMINFO=${BOOST_MEMINFO:-/proc/meminfo}

# 内存:优先 MemAvailable(内核 3.14+ 都有),没有就退化成 MemFree+Cached
bo_mem() {
  bom_t=$(sed -n 's/^MemTotal:[[:space:]]*\([0-9]*\).*/\1/p' "$BO_MEMINFO" 2>/dev/null | head -n 1)
  bom_a=$(sed -n 's/^MemAvailable:[[:space:]]*\([0-9]*\).*/\1/p' "$BO_MEMINFO" 2>/dev/null | head -n 1)
  if [ -z "$bom_a" ]; then
    bom_f=$(sed -n 's/^MemFree:[[:space:]]*\([0-9]*\).*/\1/p' "$BO_MEMINFO" 2>/dev/null | head -n 1)
    bom_c=$(sed -n 's/^Cached:[[:space:]]*\([0-9]*\).*/\1/p' "$BO_MEMINFO" 2>/dev/null | head -n 1)
    case "$bom_f" in ''|*[!0-9]*) bom_f=0 ;; esac
    case "$bom_c" in ''|*[!0-9]*) bom_c=0 ;; esac
    bom_a=$((bom_f + bom_c))
  fi
  case "$bom_t" in ''|*[!0-9]*) bom_t=0 ;; esac
  case "$bom_a" in ''|*[!0-9]*) bom_a=0 ;; esac
  echo "$bom_t $bom_a"
}

bo_mb() { echo "$(($1 / 1024))"; }

# 进程数(用 ps 全表,不依赖 dumpsys —— dumpsys 在低端机上很慢)
bo_procs() {
  bop_n=$(ps -A 2>/dev/null | grep -c .)
  case "$bop_n" in ''|*[!0-9]*) bop_n=0 ;; esac
  echo "$bop_n"
}

bo_last() {
  # 直接存"已经排好版的字符串" —— 不存 epoch 再回头格式化:
  # Android 的 toybox date 未必支持 `date -d @<epoch>`(踩过)。
  bol_v=$(cat "$BD/last" 2>/dev/null)
  if [ -z "$bol_v" ]; then
    echo "还没加速过"
  else
    echo "$bol_v"
  fi
}

bo_status() {
  bo_m=$(bo_mem)
  bo_t=$(echo "$bo_m" | cut -d' ' -f1)
  bo_a=$(echo "$bo_m" | cut -d' ' -f2)
  if [ "$bo_t" -gt 0 ]; then
    bo_used=$((bo_t - bo_a))
    bo_pct=$((bo_used * 100 / bo_t))
    echo "内存:$(bo_mb "$bo_used") MB / $(bo_mb "$bo_t") MB (占用 ${bo_pct}%)"
    echo "可用:$(bo_mb "$bo_a") MB"
    if [ "$bo_pct" -ge 85 ]; then
      echo "状态:偏紧,建议清一次"
    elif [ "$bo_pct" -ge 70 ]; then
      echo "状态:还行"
    else
      echo "状态:很宽裕"
    fi
  else
    echo "内存:读不到 /proc/meminfo"
  fi
  echo "进程数:$(bo_procs)"
  echo "上次加速:$(bo_last)"
  echo ""
  echo "@item|清后台 + 丢缓存,立刻腾出内存|act|boost"
  echo "@item|整理存储碎片(会慢几十秒)|act|trim"
  echo "@item|看看谁在占内存|act|detail"
  return 0
}

case "$1" in
  meta)
    echo "boost|一键加速|清后台 + 释放内存,报真实数字|0|boost:立即加速:pri,trim:整理存储:ghost,detail:内存详情:ghost"
    ;;
  status)
    bo_status
    ;;
  act)
    case "$2" in
      boost)
        bo_b=$(bo_mem | cut -d' ' -f2)
        am kill-all >/dev/null 2>&1
        sync >/dev/null 2>&1
        echo 3 > /proc/sys/vm/drop_caches 2>/dev/null
        sleep 1
        bo_a=$(bo_mem | cut -d' ' -f2)
        date '+%m-%d %H:%M' > "$BD/last"
        bo_d=$(( (bo_a - bo_b) / 1024 ))
        if [ "$bo_d" -gt 0 ]; then
          echo "已清后台并释放缓存"
          echo "可用内存 +${bo_d} MB,现在可用 $(bo_mb "$bo_a") MB"
        else
          echo "已清后台"
          echo "可用内存 $(bo_mb "$bo_a") MB(本来就不紧,没腾出多少)"
        fi
        bo_log "boost: ${bo_b}kB -> ${bo_a}kB"
        ;;
      trim)
        echo "正在整理存储(可能要几十秒)…"
        if fstrim -a >/dev/null 2>&1; then
          echo "存储整理完成"
        else
          echo "这台机器不支持 fstrim,或者需要更长时间"
        fi
        ;;
      detail)
        bo_m=$(bo_mem)
        bo_t=$(echo "$bo_m" | cut -d' ' -f1)
        bo_a=$(echo "$bo_m" | cut -d' ' -f2)
        echo "总内存:$(bo_mb "$bo_t") MB · 可用 $(bo_mb "$bo_a") MB"
        echo ""
        echo "占用最高的进程(前 8):"
        # ps 的 RSS 单位是 KB;按数值倒序取前 8。没有 awk,用 sort -n 顶上。
        ps -A -o rss,pid,args 2>/dev/null | tail -n +2 | sort -rn | head -n 8 \
          | while read -r bod_r bod_p bod_n; do
              case "$bod_r" in ''|*[!0-9]*) continue ;; esac
              echo "  $(($bod_r / 1024))MB  $bod_n"
            done
        ;;
      *)
        echo "未知动作:$2" >&2
        exit 2
        ;;
    esac
    ;;
  *)
    echo "用法:$0 {meta|status|act <动作>}" >&2
    exit 2
    ;;
esac
