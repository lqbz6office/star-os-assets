#!/system/bin/sh
# ============================================================================
#  Star OS · 星谱 (bench.sh)   —— Pro+ / 终身版专属
#  ===========================================================
#  统一工具协议见 tools/power.sh 开头。
#
#  干的事:给这块表跑个分,量三个数:
#        · 存储写入速度(MB/s)
#        · 存储读取速度(MB/s)
#        · 内存搬运速度(MB/s)
#        再折算成一个 100 分制的"星谱分",方便你前后对比、或和朋友的
#        同款表比一比("是不是该清理了""换卡了没变快")。
#
#  ⚠ 跑分只是参考:手表在跑什么、剩多少电、室温多少都会影响结果。
#     想比就同条件比 —— 满电、清完后台、隔一会儿再跑第二遍。
# ============================================================================

PWDIR=${0%/*}
[ -d "$PWDIR" ] || PWDIR=/data/adb/modules/zz_star_os/tools
MODD=${PWDIR%/*}
[ -d "$MODD" ] || MODD=/data/adb/modules/zz_star_os
STAR=${STAR_DIR:-/data/adb/star_os}
BN=$STAR/bench
LOG=$STAR/logs/bench.log
TMP=${BENCH_TMP_DIR:-/data/local/tmp/staros-bench.bin}

mkdir -p "$BN" "$STAR/logs" 2>/dev/null

bn_log() { echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$LOG" 2>/dev/null; }

bn_tier() {
  bnv=0
  if [ -f "$STAR/pro.conf" ]; then
    bnv=$(sed -n 's/^tier=//p' "$STAR/pro.conf" 2>/dev/null | head -n 1)
  fi
  case "$bnv" in
    ''|*[!0-9]*) echo 0 ;;
    *) echo "$bnv" ;;
  esac
}

bn_gate() {
  [ "$(bn_tier)" -ge 2 ] && return 0
  echo "星谱是 Pro+ / 终身版功能,当前等级不够" >&2
  return 5
}

# 百分之一秒(用 /proc/uptime 的小数部分凑精度,date 只有秒级)
bn_now() {
  sed -n 's/^\([0-9][0-9]*\)\.\([0-9][0-9]\).*/\1\2/p' /proc/uptime 2>/dev/null | head -n 1
}

bn_timed() {  # $1=要跑的命令串,回显 "用时cs"
  bnt_s=$(bn_now)
  eval "$1" >/dev/null 2>&1
  bnt_e=$(bn_now)
  echo $((bnt_e - bnt_s))
}

# 跑一段并算 MB/s;$1=MB $2=命令 $3=次数
bn_speed() {
  bns_mb=$1
  bns_rep=$2
  bns_cs=$(bn_timed "$3")
  case "$bns_cs" in ''|*[!0-9]*) echo 0; return 0 ;; esac
  [ "$bns_cs" -le 0 ] && bns_cs=1
  # MB/s = MB * 100 / cs
  echo $(( bns_mb * $bns_rep * 100 / bns_cs ))
}

bn_run() {
  echo "开始跑分(约十几秒),中途别退出…"
  echo ""

  # ---- 存储写:32MB,fsync 落盘 ----
  bn_w=$(bn_speed 32 1 "dd if=/dev/zero of=$TMP bs=1M count=32 conv=fsync 2>/dev/null")
  echo "存储写入:$bn_w MB/s"

  # ---- 存储读:同样 32MB(可能有页缓存加成,作参考) ----
  bn_r=$(bn_speed 32 1 "dd if=$TMP of=/dev/null bs=1M count=32 2>/dev/null")
  echo "存储读取:$bn_r MB/s"

  # ---- 内存搬运:64MB 零设备<->空设备 ----
  bn_m=$(bn_speed 64 1 "dd if=/dev/zero of=/dev/null bs=1M count=64 2>/dev/null")
  echo "内存搬运:$bn_m MB/s"

  # 清掉临时文件(自己造的,放心删)
  dd if=/dev/zero of="$TMP" bs=1M count=1 2>/dev/null
  rm -f "$TMP" 2>/dev/null

  # ---- 折算分数:以"写 30 / 读 80 / 内存 400 MB/s"为 100 分的基准 ----
  bn_s1=$(( bn_w * 100 / 30 ))
  bn_s2=$(( bn_r * 100 / 80 ))
  bn_s3=$(( bn_m * 100 / 400 ))
  bn_score=$(( (bn_s1 + bn_s2 + bn_s3) / 3 ))
  [ "$bn_score" -gt 999 ] && bn_score=999

  echo ""
  echo "星谱分:$bn_score / 100(越高越好,仅供参考)"

  bn_grade="一般"
  if [ "$bn_score" -ge 130 ]; then bn_grade="很强"
  elif [ "$bn_score" -ge 90 ]; then bn_grade="不错"
  elif [ "$bn_score" -ge 50 ]; then bn_grade="一般"
  else bn_grade="偏慢(考虑清后台/清存储)"; fi
  echo "评价:$bn_grade"

  echo "$(date '+%Y-%m-%d %H:%M') score=$bn_score w=$bn_w r=$bn_r m=$bn_m" >> "$BN/history.log" 2>/dev/null
  bn_log "score=$bn_score w=$bn_w r=$bn_r m=$bn_m"
}

bn_status() {
  echo "上次成绩:"
  if [ -f "$BN/history.log" ]; then
    tail -n 3 "$BN/history.log" | sed 's/^/  /'
  else
    echo "  (还没跑过)"
  fi
  echo ""
  echo "跑的时候尽量:满电、后台清空、摘下来放桌上别动。"
  echo ""
  echo "@item|开始跑分|act|run"
  return 0
}

case "$1" in
  meta)
    echo "bench|星谱|给手表跑个分:存储读写 + 内存搬运 -> 星谱分|2|run:开始跑分:pri"
    ;;
  status)
    bn_gate || exit 5
    bn_status
    ;;
  act)
    bn_gate || exit 5
    case "$2" in
      run) bn_run ;;
      *)
        echo "未知动作:$2" >&2
        exit 2
        ;;
    esac
    ;;
  *)
    echo "用法:$0 {meta|status|act <动作>}" >&2
    exit 2
    ;;
esac
