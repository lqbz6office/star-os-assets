#!/system/bin/sh
# ============================================================================
#  Star OS · 星律 (scene.sh)   —— Pro+ / 终身版专属
#  ===========================================================
#  统一工具协议见 tools/power.sh 开头。
#
#  干的事:把"一整套状态"存成一个场景,一键切过去 —— 不用再一个个去点
#        勿扰、亮度、震动、息屏。
#        · 学习:略暗 + 仅重要提醒 + 保留震动
#        · 睡眠:最暗 + 完全静音 + 关震动 + 快息屏
#        · 运动:够亮 + 免打扰全关 + 震动开 + 长息屏
#        · 影音:最亮 + 免打扰全关 + 长息屏
#
#  进场景前会把当前设置存一份快照,「退出场景」原样还原(和星眼/星静一个路子)。
# ============================================================================

PWDIR=${0%/*}
[ -d "$PWDIR" ] || PWDIR=/data/adb/modules/zz_star_os/tools
MODD=${PWDIR%/*}
[ -d "$MODD" ] || MODD=/data/adb/modules/zz_star_os
STAR=${STAR_DIR:-/data/adb/star_os}
SN=$STAR/scene
LOG=$STAR/logs/scene.log
SNAP=$SN/snap.conf
CUR=$SN/cur

mkdir -p "$SN" "$STAR/logs" 2>/dev/null

sn_log() { echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$LOG" 2>/dev/null; }

sn_tier() {
  snv=0
  if [ -f "$STAR/pro.conf" ]; then
    snv=$(sed -n 's/^tier=//p' "$STAR/pro.conf" 2>/dev/null | head -n 1)
  fi
  case "$snv" in
    ''|*[!0-9]*) echo 0 ;;
    *) echo "$snv" ;;
  esac
}

sn_gate() {
  [ "$(sn_tier)" -ge 2 ] && return 0
  echo "星律是 Pro+ / 终身版功能,当前等级不够" >&2
  return 5
}

sn_get() { settings get "$1" "$2" 2>/dev/null; }
sn_put() { settings put "$1" "$2" "$3" >/dev/null 2>&1; }

# ---------------------------------------------------------------- 快照
sn_snapshot() {
  [ -f "$SNAP" ] && return 0
  true > "$SNAP"
  echo "zen=$(sn_get global zen_mode)" >> "$SNAP"
  echo "bright=$(sn_get system screen_brightness)" >> "$SNAP"
  echo "vib=$(sn_get system haptic_feedback_enabled)" >> "$SNAP"
  echo "timeout=$(sn_get system screen_off_timeout)" >> "$SNAP"
  sn_log "snapshot: $(tr '\n' ' ' < "$SNAP")"
}

sn_snap_get() { sed -n "s/^$1=//p" "$SNAP" 2>/dev/null | head -n 1; }

sn_restore_one() {
  snr_v=$(sn_snap_get "$1")
  case "$snr_v" in
    ''|null|*[!0-9]*) return 0 ;;
  esac
  sn_put "$2" "$3" "$snr_v"
}

# ---------------------------------------------------------------- 落地一套设置
# $1=zen $2=bright $3=vib(0/1) $4=timeout(ms) $5=名字
sn_apply() {
  sn_snapshot
  sn_put global zen_mode "$1"
  sn_put system screen_brightness "$2"
  sn_put system haptic_feedback_enabled "$3"
  sn_put system screen_off_timeout "$4"
  echo "$5" > "$CUR"
  sn_log "apply $5 (zen=$1 bright=$2 vib=$3 to=$4)"
  echo "已切到「$5」场景"
  case "$5" in
    学习) echo "  略暗 + 仅重要提醒(来电/闹钟还会响) + 保留震动" ;;
    睡眠) echo "  最暗 + 完全静音 + 关震动 + 15 秒息屏" ;;
    运动) echo "  提亮 + 通知全开 + 震动开 + 60 秒息屏" ;;
    影音) echo "  最亮 + 通知全开 + 5 分钟息屏" ;;
  esac
}

sn_exit() {
  sn_restore_one zen global zen_mode
  sn_restore_one bright system screen_brightness
  sn_restore_one vib system haptic_feedback_enabled
  sn_restore_one timeout system screen_off_timeout
  snex_cur=$(cat "$CUR" 2>/dev/null)
  echo "" > "$CUR" 2>/dev/null; true > "$CUR"
  sn_log "exit from ${snex_cur:-?},已还原"
  echo "已退出场景,设置还原成进场景之前的样子"
}

sn_status() {
  snc=$(cat "$CUR" 2>/dev/null)
  if [ -n "$snc" ]; then
    echo "当前场景:$snc"
  else
    echo "当前场景:无(用的是自由设置)"
  fi
  echo "亮度:$(sn_get system screen_brightness) / 255   勿扰:$(sn_get global zen_mode)"
  echo ""
  echo "@item|学习|act|study"
  echo "@item|睡眠|act|sleep"
  echo "@item|运动|act|sport"
  echo "@item|影音|act|media"
  echo "@item|退出场景(还原)|act|off"
  return 0
}

case "$1" in
  meta)
    echo "scene|星律|学习/睡眠/运动/影音,一键换一整套设置|2|study:学习:pri,sleep:睡眠:ghost,sport:运动:ghost,media:影音:ghost,off:退出还原:ghost"
    ;;
  status)
    sn_gate || exit 5
    sn_status
    ;;
  act)
    sn_gate || exit 5
    case "$2" in
      study) sn_apply 1 60 1 30000 学习 ;;
      sleep) sn_apply 2 15 0 15000 睡眠 ;;
      sport) sn_apply 0 200 1 60000 运动 ;;
      media) sn_apply 0 220 1 300000 影音 ;;
      off)   sn_exit ;;
      *)
        echo "未知动作:$2" >&2
        exit 2
        ;;
    esac
    ;;
  *)
    echo "用法:$0 {meta|status|act <动作>}" >&2
    exit 2
    ;;
esac
