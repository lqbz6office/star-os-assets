#!/system/bin/sh
##########################################################################
# post-fs-data.sh —— Star OS 开机自检
#
# 本阶段会阻塞开机,所以这里只做极轻量的事:读几个文件大小 + 写一个计数文件。
#
# 自检机制:
#   1. 每次开机把「启动尝试计数」加 1;
#   2. 检查模块里承担风险的文件是否还完好。一旦发现损坏,立刻给模块打上
#      disable 标记 —— 本次开机已经挂载、来不及救,但下次 Magisk 会整个
#      跳过本模块,等于最多只崩一次;
#   3. 计数累计到 3 次仍未成功启动,说明问题不在某个具体文件上,同样打 disable;
#   4. service.sh 会在系统真正起来之后把计数清零。
#
# 为什么放在这个阶段:这是 Magisk 能执行模块脚本的最早时机,晚于它就没意义了。
##########################################################################

MODDIR=${MODDIR:-${0%/*}}
STATE=/data/adb/star_os
mkdir -p "$STATE" 2>/dev/null   # 必须紧跟其后:下面所有 $STATE/... 读写都依赖它存在
LOG=$STATE/guard.log
ATTEMPTS_FILE=$STATE/boot_attempts
MARK_FILE=$STATE/auto_disabled
MAX_ATTEMPTS=3

log() {
  # 日志超过 64KB 就重开,避免无限增长
  if [ -f "$LOG" ]; then
    sz=$(wc -c < "$LOG" 2>/dev/null | tr -d ' ')
    case "$sz" in ''|*[!0-9]*) sz=0 ;; esac
    [ "$sz" -gt 65536 ] && rm -f "$LOG"
  fi
  echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$LOG" 2>/dev/null
}

# ---------- 读取计数 ----------
ATTEMPTS=0
[ -f "$ATTEMPTS_FILE" ] && ATTEMPTS=$(cat "$ATTEMPTS_FILE" 2>/dev/null)
case "$ATTEMPTS" in ''|*[!0-9]*) ATTEMPTS=0 ;; esac

# ---------- 用户手动重新启用的检测 ----------
# 上次是自检禁用的,而现在模块不在禁用状态 —— 说明用户自己把 disable 删掉、
# 重新启用了模块。此时必须清零计数,否则会立刻又被判成“连续失败”。
if [ -f "$MARK_FILE" ] && [ ! -f "$MODDIR/disable" ]; then
  ATTEMPTS=0
  rm -f "$MARK_FILE"
  log "检测到用户重新启用模块,启动计数已清零"
fi

# ---------- 文件完整性自检 ----------
# 只检查“替换系统文件、出问题会导致系统异常”的那几类。文件不存在就跳过
# (说明该功能未启用),不做误判。
BROKEN=""

min_size() {
  # $1=相对模块根的路径  $2=最小字节数  $3=用于日志的名字
  f="$MODDIR/$1"
  [ -f "$f" ] || return 0
  sz=$(wc -c < "$f" 2>/dev/null | tr -d ' ')
  case "$sz" in ''|*[!0-9]*) sz=0 ;; esac
  [ "$sz" -lt "$2" ] && BROKEN="$BROKEN $3(${sz}B)"
  return 0
}

# 字体:被截断的 TTF 会让系统起不来,苹方各字重都在 10MB 量级
min_size "system/fonts/font.ttf"                1048576 "font.ttf"
min_size "system/fonts/PingFangSC-Light.ttf"    1048576 "PingFangSC-Light.ttf"
min_size "system/fonts/PingFangSC-Medium.ttf"   1048576 "PingFangSC-Medium.ttf"
min_size "system/fonts/PingFangSC-Semibold.ttf" 1048576 "PingFangSC-Semibold.ttf"

# fonts.xml:语法错会直接导致无法开机,这里做“结构存在性”校验
FX="$MODDIR/system/etc/fonts.xml"
if [ -f "$FX" ]; then
  FXSZ=$(wc -c < "$FX" 2>/dev/null | tr -d ' ')
  case "$FXSZ" in ''|*[!0-9]*) FXSZ=0 ;; esac
  if [ "$FXSZ" -lt 4096 ]; then
    BROKEN="$BROKEN fonts.xml(${FXSZ}B)"
  elif ! grep -q '</familyset>' "$FX" 2>/dev/null; then
    BROKEN="$BROKEN fonts.xml(缺结束标签)"
  fi
fi

# 开机动画:必须是能解压的 zip(头部魔数 PK)。
# W5(安卓 11)会把同一份写到 product/media —— 那里优先级更高,一并验。
BA="$MODDIR/system/media/bootanimation.zip"
if [ -f "$BA" ]; then
  HEAD=$(head -c 2 "$BA" 2>/dev/null)
  [ "$HEAD" != "PK" ] && BROKEN="$BROKEN bootanimation.zip(非zip)"
fi
BAP="$MODDIR/product/media/bootanimation.zip"
if [ -f "$BAP" ]; then
  HEAD=$(head -c 2 "$BAP" 2>/dev/null)
  [ "$HEAD" != "PK" ] && BROKEN="$BROKEN product/bootanimation.zip(非zip)"
fi

# 音效:小于 512B 基本是空文件或损坏文件
min_size "system/media/audio/ui/Effect_Tick.ogg"  512 "Effect_Tick.ogg"
min_size "system/media/audio/ui/camera_click.ogg" 512 "camera_click.ogg"
min_size "system/media/audio/ui/VideoRecord.ogg"  512 "VideoRecord.ogg"

# WiFi 配置(安装时从原机取一份改出来的):被截断会让 WiFi 起不来,
# 这一项比上面那些更值得拦 —— 手表没网基本没法用
min_size "system/vendor/etc/wifi/WCNSS_qcom_cfg.ini" 1024 "WCNSS_qcom_cfg.ini"
min_size "system/etc/wifi/WCNSS_qcom_cfg.ini"        1024 "WCNSS_qcom_cfg.ini"

# ---------- 判定 ----------
# 在线版正在解包的特例:此时资源可能处于"解到一半"的状态,
# 任何"体积不对"都是假警报。统一在这里豁免一次,
# 免得把模块误判成文件损坏而打上 disable —— 那才是真的难恢复。
if [ -f "$MODDIR/.assets_lock" ]; then
  [ -n "$BROKEN" ] && \
    log "检测到 .assets_lock(在线版资源正在解包),本轮忽略完整性告警:$BROKEN"
  BROKEN=""
fi

ATTEMPTS=$((ATTEMPTS + 1))
echo "$ATTEMPTS" > "$ATTEMPTS_FILE" 2>/dev/null

if [ -n "$BROKEN" ]; then
  touch "$MODDIR/disable" 2>/dev/null
  touch "$MARK_FILE" 2>/dev/null
  log "自检发现文件异常:$BROKEN —— 已标记模块禁用,下次开机将跳过(本次已挂载,无法挽回)"
  exit 0
fi

if [ "$ATTEMPTS" -ge "$MAX_ATTEMPTS" ]; then
  touch "$MODDIR/disable" 2>/dev/null
  touch "$MARK_FILE" 2>/dev/null
  log "连续 $ATTEMPTS 次开机未确认成功 —— 已标记模块禁用,下次开机将跳过"
  exit 0
fi

log "自检通过(第 $ATTEMPTS 次启动尝试),文件完好"

exit 0
