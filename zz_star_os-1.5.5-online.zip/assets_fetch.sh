#!/system/bin/sh
##########################################################################
#  assets_fetch.sh —— Star OS 在线版:资源包的定位 / 下载 / 校验 / 解包
#
#  本文件只定义函数,自身不执行任何动作。由调用方 source 之后主动调用:
#    * customize.sh  刷入时 —— 有网就直接下好,资源随模块一起就位(首次开机即生效)
#    * service.sh    开机后 —— 刷入时没网(如 recovery / ATB 刷入)的兜底重试
#
#  ── 为什么要把资源拆出去 ─────────────────────────────────────────
#  桌面 APK + 字体 + SystemUI + 图标 + 开机动画合计 189 MB。
#  拆出去之后模块本体只剩 ~190 KB,传输和分发都轻松得多。
#
#  ── 资源包里放了什么(路径与模块根一致,直接解到模块目录即可)────
#    payload/*.apk                     Z12 桌面 / 侧边栏 / AI识屏
#    system/fonts/*.ttf                苹方 4 个字重
#    system/etc/fonts.xml              字重映射表
#    system/priv-app/XTCSystemUI/      SystemUI 补丁(含 2 个 .so)
#    system/vendor/res/theme/          主题背景 + 224 个 iOS 26 图标
#    system/media/bootanimation*.zip   开机动画
#
#  ⚠ fonts.xml 与字体文件必须"同生共死":只留下一个指向不存在字体的
#    fonts.xml 会让系统字体加载异常。所以它俩一起放资源包里 —— 要么全有、
#    要么全无。资源没到位时,模块对字体不做任何改动,系统保持原样。
#
#  ── 用什么下载 ───────────────────────────────────────────────────
#  Magisk 自带的 busybox(v1.36.1-Magisk)编进了 wget 和内置 TLS,另外还带
#  unzip / sha256sum —— 下载、校验、解包三件事在刷入脚本里就能做完。
#  唯一要注意的是它的 TLS 不校验证书(busybox 源码原话:
#  "TLS certificate validation not implemented"),所以完整性只能靠下面的
#  sha256 自己核 —— 镜像站被劫持或传输损坏,都会在这里被拦下。
#
#  ── ⚠⚠ 变量命名:踩过一个把刷入搞崩的大坑 ────────────────────────
#  ash / sh **没有 local**,函数里的变量全是全局的。曾经 af_progress 内部用
#  `_af_d` 暂存速度(kbps 换算出的整数),而 af_dl 用 `_af_d` 存"下载目标
#  路径"—— 下载中每 5 秒打一次进度,就把路径覆盖成了 "3";紧接着
#  `: > "${_af_o%/*}/dl_err.log"` 变成 `: > 3/dl_err.log`,而 `:` 是 POSIX
#  特殊内建命令,重定向失败会**直接终止整个脚本** → 刷入界面报
#  "can't create 3/dl_err.log: nonexistent directory" + "! Installation failed"
#  (2026-10-03 手表实测,已本地复现)。
#  ⇒ 铁律:每个函数用**独占前缀**,禁止再用 _af_xxx 这种通用名:
#      afp_ 进度   afm_ 单位换算   afb_ 读字节数   afv_ 校验
#      afe_ 报错行  afw_ 看门狗     afd_ 下载器
#      aff_ 主流程  afu_ URL列表    afr_ 资源探针
#      _AF_ 全大写 = 配置/全局状态(允许跨函数读写)
##########################################################################

# ---------------------------------------------------------------------------
# 输出出口
#   默认打到 stdout;调用方可以覆盖:
#     customize.sh -> af_out() { ui_print "$*"; }        走刷入日志
#     service.sh   -> af_out() { echo ... >> 抓取日志; }  走文件日志
# ---------------------------------------------------------------------------
if ! command -v af_out >/dev/null 2>&1; then
  af_out() { echo "$*"; }
fi

# 资源包主地址之外,额外尝试的 GitHub 加速镜像(前缀式:镜像地址 + 完整原始 URL)
# 顺序即优先级。2026-10-03 用 2MB 样本实测(同一 Release 资产):
#     gh-proxy.com   1.81 MB/s   ← 最快,排第一
#     ghfast.top     0.74 MB/s
#     ghproxy.net    0.095 MB/s  (174MB 要 31 分钟,只能当最后的备胎)
#     ghproxy.cc / gh.llkk.cc    连不上(HTTP 000),已移出列表省得白等
# 即便如此,下面仍然有"限速淘汰"机制:谁慢就当场换谁,不依赖这个顺序。
AF_MIRRORS="https://gh-proxy.com/ https://ghfast.top/ https://ghproxy.net/"

# ---------------------------------------------------------------------------
# 下载调参(单位:秒 / 字节)
#   为什么需要这些:第一版只写了 --max-time 3600,遇到慢源就得干等一小时,
#   而且全程没有任何进度输出,看起来像卡死。现在改成"看推进速度"而不是"数秒表":
#     AF_START_SECS  开下判定:这么久还没写出第一个字节 = 根本没连上,当场换源
#     AF_STALL_SECS  连续多久没有新字节 -> 判定卡住,当场换源
#     AF_SLOW_SECS / AF_SLOW_MIN
#                    开局 AF_SLOW_SECS 秒内没下满 AF_SLOW_MIN 字节 -> 判定太慢,换源
#     AF_MAX_SECS    单个源的总时长上限(兜底,正常靠上面三条触发)
#   注:AF_MAX_SECS 第一轮给到 900s(15 分钟)。手表 Wi-Fi 实测只有 0.3~0.6 MB/s,
#   174 MB 按 0.2 MB/s 也要 15 分钟 —— 上限卡太短会把"能下完的慢源"误杀,
#   反而逼着它从 0 重来。真正不可救的源由开下判定(8s)和卡住判定(15s)拦掉。
#   第一轮用严格值快速淘汰;万一所有源都被淘汰(比如整体网速就是差),
#   第二轮放宽成"只要还在动就等",保证不会比改之前更差。
# ---------------------------------------------------------------------------
AF_GATE=1                 # 1=启用限速淘汰(第一轮) 0=只要不卡住就等(第二轮)
AF_CONNECT=8              # 连接超时
AF_START_SECS=8           # 开下判定:这么久之后输出文件还不存在,说明根本没连上
AF_STALL_SECS=15          # 卡住判定
AF_SLOW_SECS=12           # 开局观察窗口
AF_SLOW_MIN=2097152       # 开局窗口内至少要下到 2 MB(≈170 KB/s)
AF_MAX_SECS=900           # 单源总上限
AF_PROGRESS_SECS=5        # 进度输出间隔

# 用户可以把资源包先下到这几个位置之一,脚本就不再联网(最可靠的一条路)
AF_LOCAL="
/sdcard/star_os_assets.zip
/storage/emulated/0/star_os_assets.zip
/data/media/0/star_os_assets.zip
/data/adb/star_os/assets.zip"

# 允许临时换源,不必重打包:/sdcard/star_os_url.txt 第一行非注释内容即地址
AF_URL_OVERRIDE="
/sdcard/star_os_url.txt
/storage/emulated/0/star_os_url.txt
/data/media/0/star_os_url.txt"

# ---------------------------------------------------------------------------
# 小工具
# ---------------------------------------------------------------------------
af_bytes() {
  # ⚠ 不能写成 `wc -c < "$1" 2>/dev/null`:重定向从左到右处理,文件不存在时
  # `<` 先失败,报错时 stderr 还没被重定向,会直接漏到刷机界面上
  # (实测在手表上每秒刷一行 "can't open ...: no such file")。
  # 先判存在,不存在就报 0 —— 看门狗轮询时文件还没创建是常态。
  if [ ! -f "$1" ]; then
    echo 0
    return 0
  fi
  _afb_b=$(wc -c < "$1" 2>/dev/null | tr -d ' \t')
  case "$_afb_b" in ''|*[!0-9]*) _afb_b=0 ;; esac
  echo "$_afb_b"
}

af_mb() {
  _afm_n=$(echo "${1:-0}" | tr -d ' \t')
  case "$_afm_n" in ''|*[!0-9]*) echo "?" ; return 0 ;; esac
  echo "$((_afm_n / 1048576)) MB"
}

# 是不是半个 zip(只看魔数)。用来判断残档能不能拿来做断点续传 ——
# 镜像返回的错误页 / HTML 也常是"非空文件",不能拿来续传。
af_is_zip() {
  [ -f "$1" ] || return 1
  _afz_h=$(head -c 2 "$1" 2>/dev/null)
  [ "$_afz_h" = "PK" ] && return 0
  return 1
}

# 下载工具的 stderr 会落到输出文件同目录的 dl_err.log 里(见 af_dl_watch)。
# 失败时把最后一行报错亮出来,不然"判定连不上"看不出到底是
# DNS 挂了 / 连不上服务器 / TLS 被拦 —— 手表侧排障全靠这个。
af_err_line() {
  _afe_f="${1%/*}/dl_err.log"
  [ -f "$_afe_f" ] || return 0
  _afe_l=$(tail -n 3 "$_afe_f" 2>/dev/null | tr '\n' ' ' \
           | sed 's/[[:space:]]\+/ /g;s/^ //;s/ $//' | cut -c1-96)
  [ -n "$_afe_l" ] && af_out "      详情: $_afe_l"
  return 0
}

# sha256:刷入时 Magisk 已把 busybox 加进 PATH,直接用同名命令即可
af_sha256() {
  [ -f "$1" ] || return 1
  if command -v sha256sum >/dev/null 2>&1; then
    sha256sum "$1" 2>/dev/null | cut -d' ' -f1
  elif [ -x /data/adb/magisk/busybox ]; then
    /data/adb/magisk/busybox sha256sum "$1" 2>/dev/null | cut -d' ' -f1
  elif command -v toybox >/dev/null 2>&1; then
    toybox sha256sum "$1" 2>/dev/null | cut -d' ' -f1
  else
    return 1
  fi
}

# 校验一个候选资源包:先比体积,再比 sha256。返回 0 才认为是可用的那一份。
af_verify() {
  _afv_f="$1"
  if [ ! -f "$_afv_f" ]; then
    af_out "    x 文件不存在"
    return 1
  fi

  _afv_sz=$(af_bytes "$_afv_f")
  if [ -n "$ASSETS_SIZE" ] && [ "$_afv_sz" != "$ASSETS_SIZE" ]; then
    af_out "    x 体积不符:实际 ${_afv_sz}B,应为 ${ASSETS_SIZE}B(下载被截断?)"
    return 1
  fi

  case "$ASSETS_SHA256" in
    ""|REPLACE*) af_out "    ! 未配置 sha256,只核对了体积"; return 0 ;;
  esac

  _afv_got=$(af_sha256 "$_afv_f")
  if [ -z "$_afv_got" ]; then
    af_out "    ! 本机没有可用的 sha256 工具,只核对了体积"
    return 0
  fi

  if [ "$_afv_got" != "$ASSETS_SHA256" ]; then
    af_out "    x sha256 不符 —— 文件内容不是我们要的那一份"
    af_out "        实际 $_afv_got"
    af_out "        应为 $ASSETS_SHA256"
    return 1
  fi

  af_out "    OK 体积 + sha256 均一致"
  return 0
}

# ---------------------------------------------------------------------------
# 下载
# ---------------------------------------------------------------------------
# 进度行:只在控制台/刷入日志里报"已下多少、百分比、当前速度"
# ⚠ 本函数必须只用 afp_ 前缀:曾经用 _af_d 暂存速度,把 af_dl 的目标路径
#   覆盖掉,导致刷入脚本被终止(见文件头)。
af_progress() {
  _afp_b="$1"          # 已下载字节
  _afp_s="$2"          # 已耗时秒数
  _afp_tot="${ASSETS_SIZE:-}"
  case "$_afp_tot" in ''|*[!0-9]*) _afp_tot=0 ;; esac

  _afp_cur=$((_afp_b / 1048576))
  if [ "$_afp_s" -gt 0 ]; then
    _afp_kbps=$((_afp_b / _afp_s / 1024))
  else
    _afp_kbps=0
  fi

  # 速度只报个大概:>=0.1 MB/s 用 MB/s(一位小数),再慢就报 KB/s
  if [ "$_afp_kbps" -ge 102 ]; then
    _afp_d=$((_afp_kbps * 10 / 1024))
    _afp_spd="$((_afp_d / 10)).$((_afp_d % 10)) MB/s"
  else
    _afp_spd="${_afp_kbps} KB/s"
  fi

  if [ "$_afp_tot" -gt 0 ]; then
    _afp_all=$((_afp_tot / 1048576))
    _afp_pct=$((_afp_b * 100 / _afp_tot))
    af_out "      已下 ${_afp_cur}/${_afp_all} MB (${_afp_pct}%)  约 ${_afp_spd}"
  else
    af_out "      已下 ${_afp_cur} MB  约 ${_afp_spd}"
  fi
}

# 掐掉一个后台下载进程(先温和后强杀,最后回收,免得留僵尸)
af_kill() {
  kill "$1" 2>/dev/null
  sleep 1
  kill -9 "$1" 2>/dev/null
  wait "$1" 2>/dev/null
  return 0
}

# ---------------------------------------------------------------------------
# af_dl_watch <输出文件> <下载命令...>
#   把下载命令丢到后台跑,前台每秒看一眼输出文件长了多少:
#     * 有新字节        -> 记一笔,顺便按 AF_PROGRESS_SECS 打进度
#     * 开局没动静      -> AF_START_SECS 内一个字节都没写 -> 判定连不上,换源
#     * 连续没新字节    -> AF_STALL_SECS 到了就掐掉换源
#     * 开局就特别慢    -> AF_SLOW_SECS 内没到 AF_SLOW_MIN 就掐掉换源(仅第一轮)
#     * 总时长超上限    -> 掐掉换源
#   返回:0 成功 / 1 命令失败 / 2 卡住 / 3 太慢 / 4 超时 / 5 连不上
#   注意:调度逻辑跑在前台 shell,所以 af_out 能正常走 ui_print 进刷入界面。
#   失败时**保留已下载的部分**,af_dl 会用 -c 让下一个源接着传(镜像断流很常见)。
# ---------------------------------------------------------------------------
af_dl_watch() {
  _afw_out="$1"
  shift

  # stderr 落盘。⚠ 目录必须真实存在:重定向失败在 ash 里可能直接终止脚本
  # (踩过一次 —— `: > 3/dl_err.log` 把整个刷入干掉了)。所以这里:
  #   1) 先确认目录存在,不存在就退回 /dev/null;
  #   2) 用 `true`(非特殊内建命令)而不是 `:`,即使失败也不会杀掉脚本。
  _afw_dir="${_afw_out%/*}"
  [ "$_afw_dir" = "$_afw_out" ] && _afw_dir="/data/local/tmp"
  _afw_err="/dev/null"
  if [ -d "$_afw_dir" ]; then
    _afw_err="$_afw_dir/dl_err.log"
    true > "$_afw_err" 2>/dev/null || _afw_err="/dev/null"
  fi

  "$@" >/dev/null 2>>"$_afw_err" &
  _afw_pid=$!

  _afw_el=0
  _afw_last=$(af_bytes "$_afw_out")   # 续传时起点不是 0
  _afw_stall=0

  while kill -0 "$_afw_pid" 2>/dev/null; do
    sleep 1
    _afw_el=$((_afw_el + 1))

    _afw_now=$(af_bytes "$_afw_out")
    if [ "$_afw_now" -gt "$_afw_last" ]; then
      _afw_stall=0
      _afw_last="$_afw_now"
    else
      _afw_stall=$((_afw_stall + 1))
    fi

    if [ "$AF_PROGRESS_SECS" -gt 0 ] && \
       [ $((_afw_el % AF_PROGRESS_SECS)) -eq 0 ] && [ "$_afw_now" -gt 0 ]; then
      af_progress "$_afw_now" "$_afw_el"
    fi

    if [ "$_afw_stall" -ge "$AF_STALL_SECS" ]; then
      af_out "      ! 连续 ${_afw_stall}s 没有新数据,判定卡住,换下一个源"
      af_kill "$_afw_pid"
      return 2
    fi

    # 开下判定:下载工具还挂着,但连一个字节都没写出来 —— 基本就是连不上。
    # 这种情况不该等满 AF_STALL_SECS,早点切下一个源。
    if [ "$_afw_el" -ge "$AF_START_SECS" ] && [ "$_afw_now" -le 0 ]; then
      af_out "      ! ${_afw_el}s 了还没开始下,判定连不上,换下一个源"
      af_kill "$_afw_pid"
      return 5
    fi

    if [ "$AF_GATE" = "1" ] && [ "$_afw_el" -ge "$AF_SLOW_SECS" ] && \
       [ "$_afw_now" -lt "$AF_SLOW_MIN" ]; then
      af_out "      ! 前 ${_afw_el}s 只下了 $(af_mb "$_afw_now"),太慢,换下一个源"
      af_kill "$_afw_pid"
      return 3
    fi

    if [ "$_afw_el" -ge "$AF_MAX_SECS" ]; then
      af_out "      ! 超过 ${AF_MAX_SECS}s 上限,换下一个源"
      af_kill "$_afw_pid"
      return 4
    fi
  done

  wait "$_afw_pid" 2>/dev/null
  _afw_rc=$?

  if [ "$_afw_rc" -eq 0 ] && [ -s "$_afw_out" ]; then
    return 0
  fi
  # 失败也**不删残档**:af_dl 会判断它是不是半个 zip,是就 -c 续传。
  return 1
}

# ---------------------------------------------------------------------------
# 依次尝试本机可用的下载工具。
#   返回 0 成功;>=2 表示是被看门狗掐掉的(卡住/太慢/超时/连不上)——
#   这种情况说明"这个源本身不行",不该再用别的工具重试同一个源,直接上抛。
#   残档处理:已有半个 zip 就用 -c 续传(镜像中途断流后不必从 0 重来);
#   残档不是 zip(多半是镜像返回的错误页)就丢掉重新下。
# ---------------------------------------------------------------------------
af_dl() {
  _afd_u="$1"
  _afd_d="$2"
  _afd_rc=1

  # 目标目录兜底:目录不在的话,下载工具的重定向失败会打断整个流程
  _afd_dir="${_afd_d%/*}"
  [ "$_afd_dir" = "$_afd_d" ] && _afd_dir="/data/local/tmp"
  [ -d "$_afd_dir" ] || mkdir -p "$_afd_dir" 2>/dev/null

  _afd_res=0
  if [ -f "$_afd_d" ]; then
    _afd_sz=$(af_bytes "$_afd_d")
    case "$ASSETS_SIZE" in
      ''|*[!0-9]*) _afd_lim=0 ;;
      *) _afd_lim="$ASSETS_SIZE" ;;
    esac
    if [ "$_afd_sz" -le 0 ] || { [ "$_afd_lim" -gt 0 ] && [ "$_afd_sz" -ge "$_afd_lim" ]; }; then
      # 空的,或者已经不小于目标体积(不可能是我们要的半成品)-> 不续传
      rm -f "$_afd_d" 2>/dev/null
    elif af_is_zip "$_afd_d"; then
      _afd_res=1
      af_out "      (已下 $(af_mb "$_afd_sz"),续传)"
    else
      rm -f "$_afd_d" 2>/dev/null
    fi
  fi

  # ⚠ 续传参数各工具不一样,不能共用一个 "-c":
  #   curl   -> `-C -`(`-c` 是保存 cookie,还会把后面的参数当文件名吃掉!)
  #   wget / busybox wget -> `-c`
  #   toybox wget -> 不支持,干脆不续传(它 -O 会截断重下,不会拼坏文件)
  if command -v curl >/dev/null 2>&1; then
    if [ "$_afd_res" = "1" ]; then
      af_dl_watch "$_afd_d" curl -fL -sS -C - --connect-timeout "$AF_CONNECT" \
        --max-time "$((AF_MAX_SECS + 120))" -o "$_afd_d" "$_afd_u"
    else
      af_dl_watch "$_afd_d" curl -fL -sS --connect-timeout "$AF_CONNECT" \
        --max-time "$((AF_MAX_SECS + 120))" -o "$_afd_d" "$_afd_u"
    fi
    _afd_rc=$?
    [ "$_afd_rc" -eq 0 ] && return 0
    [ "$_afd_rc" -ge 2 ] && return "$_afd_rc"
  fi

  # 刷入环境下通常只有这个:wget(Magisk 自带 busybox 编进了 wget + TLS)
  if command -v wget >/dev/null 2>&1; then
    if [ "$_afd_res" = "1" ]; then
      af_dl_watch "$_afd_d" wget -q -c -T "$AF_CONNECT" -O "$_afd_d" "$_afd_u"
    else
      af_dl_watch "$_afd_d" wget -q -T "$AF_CONNECT" -O "$_afd_d" "$_afd_u"
    fi
    _afd_rc=$?
    [ "$_afd_rc" -eq 0 ] && return 0
    [ "$_afd_rc" -ge 2 ] && return "$_afd_rc"
  fi

  if [ -x /data/adb/magisk/busybox ]; then
    if [ "$_afd_res" = "1" ]; then
      af_dl_watch "$_afd_d" /data/adb/magisk/busybox wget -q -c \
        -T "$AF_CONNECT" -O "$_afd_d" "$_afd_u"
    else
      af_dl_watch "$_afd_d" /data/adb/magisk/busybox wget -q \
        -T "$AF_CONNECT" -O "$_afd_d" "$_afd_u"
    fi
    _afd_rc=$?
    [ "$_afd_rc" -eq 0 ] && return 0
    [ "$_afd_rc" -ge 2 ] && return "$_afd_rc"
  fi

  # 高版本 Android 的 toybox 也带 wget(不支持续传)
  if command -v toybox >/dev/null 2>&1; then
    af_dl_watch "$_afd_d" toybox wget -O "$_afd_d" "$_afd_u"
    _afd_rc=$?
    [ "$_afd_rc" -eq 0 ] && return 0
    [ "$_afd_rc" -ge 2 ] && return "$_afd_rc"
  fi

  return 1
}

# ---------------------------------------------------------------------------
# 候选 URL 列表(去重,一行一个,按优先级)
#   镜像优先:国内直连 github.com 基本不通,把它排在最后当兜底
# ---------------------------------------------------------------------------
_AF_SEEN=""

af_push() {
  case "$_AF_SEEN" in
    *"|$1|"*) return 0 ;;
  esac
  _AF_SEEN="$_AF_SEEN|$1|"
  echo "$1"
}

af_is_github() {
  case "$1" in
    https://github.com/*|https://raw.githubusercontent.com/*) return 0 ;;
  esac
  return 1
}

af_urls() {
  # 1) 外置的临时换源文件
  _afu_ov=""
  for _afu_c in $AF_URL_OVERRIDE; do
    [ -f "$_afu_c" ] || continue
    _afu_ov=$(grep -v '^[[:space:]]*#' "$_afu_c" 2>/dev/null \
              | grep -v '^[[:space:]]*$' | head -1 | tr -d '\r ')
    [ -n "$_afu_ov" ] && break
  done

  _AF_SEEN=""
  _afu_all="$_afu_ov $ASSETS_URL"

  # 2) 换源地址如果不是 GitHub 地址,它就是一条完整可用的直链 —— 直接排第一,
  #    不必也不该等镜像试完再轮到它
  if [ -n "$_afu_ov" ] && ! af_is_github "$_afu_ov"; then
    af_push "$_afu_ov"
  fi

  # 3) 镜像优先:国内直连 github.com 基本不通
  #    换源地址的镜像排在主地址的镜像之前
  for _afu_u in $_afu_all; do
    if af_is_github "$_afu_u"; then
      for _afu_m in $AF_MIRRORS; do
        af_push "${_afu_m}${_afu_u}"
      done
    fi
  done

  # 4) 最后出原始地址本身(直连能通的话其实最快),换源在前、主地址兜底
  for _afu_u in $_afu_all; do
    af_push "$_afu_u"
  done
}

# ---------------------------------------------------------------------------
# 资源是否已就位:挑几样"必须有"的文件探一下
# ---------------------------------------------------------------------------
af_assets_present() {
  _afr_r="$1"
  [ -f "$_afr_r/payload/i3launcher.apk" ] || return 1
  [ -f "$_afr_r/system/fonts/font.ttf" ] || return 1
  [ -f "$_afr_r/system/etc/fonts.xml" ] || return 1
  [ -f "$_afr_r/system/priv-app/XTCSystemUI/XTCSystemUI.apk" ] || return 1
  [ -d "$_afr_r/system/vendor/res/theme/icon/ThemeYouth" ] || return 1
  return 0
}

# 解包出来的原生库需要可执行位,否则下次开机 dlopen 失败。
# service.sh 里没有 Magisk 的 set_perm(那是安装期才有的函数),所以用 chmod 补。
af_fix_perm() {
  _afperm_r="$1"
  if [ -d "$_afperm_r/system/priv-app/XTCSystemUI/lib" ]; then
    chmod -R 0755 "$_afperm_r/system/priv-app/XTCSystemUI/lib" 2>/dev/null
  fi
  return 0
}

# ---------------------------------------------------------------------------
# af_fetch <模块根目录>
#   成功返回 0;失败返回 1(原因已通过 af_out 说明)
# ---------------------------------------------------------------------------
af_fetch() {
  _af_root="$1"
  if [ -z "$_af_root" ]; then
    af_out "    x 没有指定模块目录"
    return 1
  fi
  mkdir -p "$_af_root" 2>/dev/null

  _af_zip=""
  _af_tmp=""

  # ---- 1) 先用本机已经存在的资源包(不联网,最稳) ----
  for _aff_c in $AF_LOCAL; do
    [ -f "$_aff_c" ] || continue
    af_out "  本机已有资源包:$_aff_c"
    if af_verify "$_aff_c"; then
      _af_zip="$_aff_c"
      break
    fi
    af_out "  这一份不可用,改用下载"
  done

  # ---- 2) 下载 ----
  if [ -z "$_af_zip" ]; then
    _af_tmp="$_af_root/.assets_dl"
    mkdir -p "$_af_tmp" 2>/dev/null || _af_tmp="/data/local/tmp"
    af_urls > "$_af_tmp/urls.txt" 2>/dev/null

    _af_total=$(wc -l < "$_af_tmp/urls.txt" 2>/dev/null | tr -d ' \t')
    case "$_af_total" in ''|*[!0-9]*) _af_total=0 ;; esac

    af_out "  资源包 $(af_mb "${ASSETS_SIZE:-0}"),共 ${_af_total} 个候选来源"

    _af_pass=1
    while [ "$_af_pass" -le 2 ] && [ -z "$_af_zip" ]; do
      if [ "$_af_pass" = "1" ]; then
        # 第一轮:严格的限速淘汰 —— 死源 8s 走人,慢源 12s 走人。
        # 但"慢而稳"的源给足 900s:手表 Wi-Fi 实测 0.3~0.6 MB/s,
        # 卡 240s 会把它误杀,反而逼它从 0 重来。
        AF_GATE=1
        AF_CONNECT=8
        AF_START_SECS=8
        AF_STALL_SECS=15
        AF_SLOW_SECS=12
        AF_SLOW_MIN=2097152
        AF_MAX_SECS=900
        [ "$_af_total" -gt 1 ] && af_out "  --- 第 1 轮:慢源直接淘汰 ---"
      else
        # 第二轮:所有源都没扛过限速(比如整体网速就是慢)。
        # 放宽成"只要还在动就继续等",避免比改之前更糟。
        AF_GATE=0
        AF_CONNECT=20
        AF_START_SECS=20
        AF_STALL_SECS=30
        AF_SLOW_SECS=0
        AF_SLOW_MIN=0
        AF_MAX_SECS=1800
        af_out "  --- 第 2 轮:放宽限速,耐心等慢速源 ---"
      fi

      _aff_idx=0
      while IFS= read -r _aff_u; do
        [ -n "$_aff_u" ] || continue
        _aff_idx=$((_aff_idx + 1))

        if [ "$_af_total" -gt 1 ]; then
          af_out "  [$_aff_idx/$_af_total] $_aff_u"
        else
          af_out "  $_aff_u"
        fi

        af_dl "$_aff_u" "$_af_tmp/assets.zip.part"
        _aff_rc=$?
        if [ "$_aff_rc" -ne 0 ]; then
          [ "$_aff_rc" -eq 1 ] && af_out "      下载失败"
          af_err_line "$_af_tmp/assets.zip.part"
          if af_is_zip "$_af_tmp/assets.zip.part"; then
            af_out "      ↳ 已保住 $(af_mb "$(af_bytes "$_af_tmp/assets.zip.part")"),下一个源接着传"
          fi
          continue
        fi

        _aff_sz=$(af_bytes "$_af_tmp/assets.zip.part")
        af_out "      下好了 $(af_mb "$_aff_sz"),正在校验..."

        if af_verify "$_af_tmp/assets.zip.part"; then
          mv -f "$_af_tmp/assets.zip.part" "$_af_tmp/assets.zip" 2>/dev/null
          _af_zip="$_af_tmp/assets.zip"
          break
        fi
        # 校验不过(截断 / 拼错 / 被劫持)—— 这份残档没用了,丢掉重来
        rm -f "$_af_tmp/assets.zip.part" 2>/dev/null
      done < "$_af_tmp/urls.txt"

      _af_pass=$((_af_pass + 1))
    done

    # 复位成默认值,免得影响后续调用
    AF_GATE=1
    AF_CONNECT=8
    AF_START_SECS=8
    AF_STALL_SECS=15
    AF_SLOW_SECS=12
    AF_SLOW_MIN=2097152
    AF_MAX_SECS=900
  fi

  if [ -z "$_af_zip" ]; then
    af_out "  x 所有来源都没能拿到完整可用的资源包"
    # 依据最后一轮的报错给个人话诊断,别让用户对着英文 stderr 猜
    if [ -n "$_af_tmp" ] && [ -f "$_af_tmp/dl_err.log" ]; then
      case "$(cat "$_af_tmp/dl_err.log" 2>/dev/null)" in
        *"bad address"*|*"Could not resolve"*|*"Name or service"*|*"not known"*)
          af_out "  ! 诊断:域名解析失败 —— 手表当前没有可用网络"
          af_out "    先连 Wi-Fi 重试,或把资源包放到内部存储根目录"
          af_out "    命名为 star_os_assets.zip(离线安装,不需要联网)" ;;
        *"can't connect"*|*"Failed to connect"*|*"Connection refused"*|*"timed out"*|*"timeout"*|*"Network is unreachable"*)
          af_out "  ! 诊断:连不上服务器 —— 网络不通或被拦截"
          af_out "    请确认 Wi-Fi 已连接;或改用本地包 star_os_assets.zip" ;;
        *"TLS"*|*"certificate"*|*"ssl"*)
          af_out "  ! 诊断:TLS 握手失败 —— 网络中间有拦截"
          af_out "    可改用本地包绕过:内部存储根目录放 star_os_assets.zip" ;;
      esac
    fi
    # 失败也要清干净:可能已经下了一半的残档,留着白占几十 MB
    [ -n "$_af_tmp" ] && rm -rf "$_af_tmp" 2>/dev/null
    return 1
  fi

  # ---- 3) 解包 ----
  af_out "  正在解包,手表上约需 1~3 分钟,请勿断电..."
  _af_lock="$_af_root/.assets_lock"
  # 解包期间立个哨兵:post-fs-data.sh 见到它会跳过完整性自检,
  # 免得"解到一半的字体"被当成文件损坏,把模块误判成开机失败而禁用。
  true > "$_af_lock" 2>/dev/null

  _af_ok=0
  if command -v unzip >/dev/null 2>&1; then
    unzip -o "$_af_zip" -d "$_af_root" >/dev/null 2>&1 && _af_ok=1
  elif [ -x /data/adb/magisk/busybox ]; then
    /data/adb/magisk/busybox unzip -o "$_af_zip" -d "$_af_root" >/dev/null 2>&1 && _af_ok=1
  fi

  if [ "$_af_ok" != "1" ]; then
    af_out "  x 解包失败(没有可用的 unzip,或资源包本身损坏)"
    rm -f "$_af_lock" 2>/dev/null
    return 1
  fi

  # 解包完成后清掉下载缓存,模块目录里不留 189MB 垃圾
  rm -rf "$_af_root/.assets_dl" 2>/dev/null

  # 再核一遍关键文件:zip 能解开不代表内容是齐的
  if ! af_assets_present "$_af_root"; then
    af_out "  x 解包后关键文件仍不完整"
    rm -f "$_af_lock" 2>/dev/null
    return 1
  fi

  af_fix_perm "$_af_root"
  rm -f "$_af_lock" 2>/dev/null
  af_out "  OK 资源包已就位"
  return 0
}
