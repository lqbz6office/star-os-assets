#!/system/bin/sh
# ============================================================================
#  Star OS · 深度净化 (cleanup.sh)   —— Pro+ / 终身版专属
#  ===========================================================
#  统一工具协议见 tools/power.sh 开头。
#
#    · 扫描:先算出每个系统垃圾目录占多少,不点也不知道该不该清
#    · 清理:清系统级垃圾(崩溃日志 / 临时文件 / 各应用 cache)
#    · 报真实数字:用 df 前后差算释放量,不喊"清掉 5GB"这种话
#
#  和「一键加速」的分工:
#    boost 清的是"内存"(后台进程 + 内核缓存),重开应用就回来;
#    cleanup 清的是"磁盘"(崩溃日志、临时目录、应用缓存),是真的落盘垃圾 ——
#    所以它需要 root 逐目录动手,放在 Pro+。
# ============================================================================

PWDIR=${0%/*}
[ -d "$PWDIR" ] || PWDIR=/data/adb/modules/zz_star_os
STAR=${STAR_DIR:-/data/adb/star_os}
CD=$STAR/cleanup
LOG=$STAR/logs/cleanup.log

mkdir -p "$CD" "$STAR/logs" 2>/dev/null

cl_log() { echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$LOG" 2>/dev/null; }

# 本地闸门(真值在台账,由应用联网核对后写入 pro.conf)
cl_tier() {
  clg_v=0
  if [ -f "$STAR/pro.conf" ]; then
    clg_v=$(sed -n 's/^tier=//p' "$STAR/pro.conf" 2>/dev/null | head -n 1)
  fi
  case "$clg_v" in
    ''|*[!0-9]*) echo 0 ;;
    *) echo "$clg_v" ;;
  esac
}

cl_gate() {
  [ "$(cl_tier)" -ge 2 ] && return 0
  echo "深度净化是 Pro+ / 终身版功能,当前等级不够" >&2
  return 5
}

# 系统级垃圾目录(可覆盖,便于测试);应用缓存单独一项
CL_DIRS=${CLEAN_DIRS:-"/data/local/tmp /data/anr /data/tombstones /data/system/dropbox /data/log /data/vendor/wifi/wlan_logs /data/misc/wifi/logs /data/misc/bluedroid"}
CL_DF_TARGET=${CLEAN_DF_TARGET:-/data}
CL_APPCACHE_GLOB=${CLEAN_APPCACHE_GLOB:-/data/data/*/cache}

cl_du_k() {
  cl_d="$1"
  [ -d "$cl_d" ] || { printf '0'; return; }
  # ⚠ 先 cut 再 tr:du -sk 是 "大小<TAB>路径",先删空白会把分隔符也删掉,
  #   剩下的整串再 cut 就取不到数字了(容量恒为 0,踩过)。
  cl_v=$(du -sk "$cl_d" 2>/dev/null | head -n 1 | cut -f1 | tr -d ' \t\r')
  case "$cl_v" in ''|*[!0-9]*) cl_v=0 ;; esac
  printf '%s' "$cl_v"
}

cl_mb() { echo "$(($1 / 1024))"; }

# 人类可读:不足 1MB 就显示 KB,别把 900KB 说成 0MB
cl_hum() {
  cl_k=$1
  case "$cl_k" in ''|*[!0-9]*) cl_k=0 ;; esac
  if [ "$cl_k" -lt 1024 ]; then
    printf '%s KB' "$cl_k"
  else
    printf '%s MB' "$((cl_k / 1024))"
  fi
}

# 可用空间(KB)
cl_avail_k() {
  cl_a=$(df -k "$CL_DF_TARGET" 2>/dev/null | tail -n 1 | tr -s ' ' | cut -d' ' -f4)
  case "$cl_a" in ''|*[!0-9]*) cl_a=0 ;; esac
  printf '%s' "$cl_a"
}

cl_scan() {
  echo "===== 扫描系统级垃圾 ====="
  cl_total=0
  for cl_d in $CL_DIRS; do
    cl_s=$(cl_du_k "$cl_d")
    cl_total=$((cl_total + cl_s))
    printf '  %-32s %8s\n' "$cl_d" "$(cl_hum "$cl_s")"
  done
  cl_ac=0
  for cl_c in $CL_APPCACHE_GLOB; do
    [ -d "$cl_c" ] || continue
    cl_ac=$((cl_ac + $(cl_du_k "$cl_c")))
  done
  cl_total=$((cl_total + cl_ac))
  printf '  %-32s %8s\n' "各应用 cache(/data/data/*/cache)" "$(cl_hum "$cl_ac")"
  echo ""
  echo "合计可清理: $(cl_hum "$cl_total")"
  echo "当前可用  : $(cl_hum "$(cl_avail_k)")"
  echo ""
  if [ "$cl_total" -le 0 ]; then
    echo "结论: 很干净,没什么可清的。"
  else
    echo "@item|立即清理这些垃圾|act|clean"
  fi
  return 0
}

cl_clean() {
  echo "===== 深度净化 ====="
  cl_before=$(cl_avail_k)
  cl_freed=0
  for cl_d in $CL_DIRS; do
    [ -d "$cl_d" ] || continue
    cl_b=$(cl_du_k "$cl_d")
    [ "$cl_b" -le 0 ] && continue
    # 只清目录里的内容,保留目录本身(有些系统服务指望目录存在)
    rm -rf "$cl_d"/* 2>/dev/null
    rm -rf "$cl_d"/.[!.]* 2>/dev/null
    cl_a=$(cl_du_k "$cl_d")
    cl_freed=$((cl_freed + cl_b - cl_a))
    printf '  清理 %-30s -%s\n' "$cl_d" "$(cl_hum "$((cl_b - cl_a))")"
  done

  # 应用缓存:逐个清,不清目录本身
  cl_acf=0
  for cl_c in $CL_APPCACHE_GLOB; do
    [ -d "$cl_c" ] || continue
    cl_b=$(cl_du_k "$cl_c")
    [ "$cl_b" -le 0 ] && continue
    rm -rf "$cl_c"/* 2>/dev/null
    rm -rf "$cl_c"/.[!.]* 2>/dev/null
    cl_a=$(cl_du_k "$cl_c")
    cl_acf=$((cl_acf + cl_b - cl_a))
  done
  cl_freed=$((cl_freed + cl_acf))
  printf '  清理 %-30s -%s\n' "各应用 cache" "$(cl_hum "$cl_acf")"

  sync 2>/dev/null
  cl_after=$(cl_avail_k)
  cl_real=$(( (cl_after - cl_before) / 1024 ))
  [ "$cl_real" -lt 0 ] && cl_real=0
  echo ""
  echo "目录统计释放 : $(cl_hum "$cl_freed")"
  echo "磁盘实际增加 : $(cl_hum "$((cl_real * 1024))") 可用"
  echo "现在可用     : $(cl_hum "$cl_after")"
  date '+%m-%d %H:%M' > "$CD/last" 2>/dev/null
  cl_log "clean: dirs=$(cl_mb "$cl_freed")MB real=${cl_real}MB avail=$(cl_mb "$cl_after")MB"
  return 0
}

cl_detail() {
  echo "===== 清理目录清单 ====="
  for cl_d in $CL_DIRS; do
    if [ -d "$cl_d" ]; then
      printf '  [有] %-32s %s\n' "$cl_d" "$(cl_hum "$(cl_du_k "$cl_d")")"
    else
      printf '  [无] %s\n' "$cl_d"
    fi
  done
  echo ""
  echo "上次清理: $(cat "$CD/last" 2>/dev/null || echo 还没清理过)"
}

cl_status() {
  cl_total=0
  for cl_d in $CL_DIRS; do cl_total=$((cl_total + $(cl_du_k "$cl_d"))); done
  echo "可清理垃圾 : 约 $(cl_hum "$cl_total")"
  echo "当前可用   : $(cl_hum "$(cl_avail_k)")"
  echo "上次清理   : $(cat "$CD/last" 2>/dev/null || echo 还没清理过)"
  echo ""
  echo "@item|扫描一下能清出多少|act|scan"
  echo "@item|立即深度净化|act|clean:pri"
  echo "@item|看看都清哪些目录|act|detail"
  return 0
}

case "$1" in
  meta)
    echo "cleanup|深度净化|清系统级垃圾(崩溃日志/临时/应用缓存),报真实释放|2|scan:扫描可清理:pri,clean:立即净化:pri,detail:清理目录:ghost"
    ;;
  status)
    cl_status
    ;;
  act)
    cl_gate || exit $?
    case "$2" in
      scan)   cl_scan ;;
      clean)  cl_clean ;;
      detail) cl_detail ;;
      *)      echo "未知动作:$2" >&2; exit 2 ;;
    esac
    ;;
  *)
    echo "用法:$0 {meta|status|act <scan|clean|detail>}" >&2
    exit 2
    ;;
esac
