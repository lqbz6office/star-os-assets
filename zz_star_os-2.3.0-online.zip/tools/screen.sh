#!/system/bin/sh
# ============================================================================
#  Star OS · 星屏 (screen.sh)   —— Pro+ / 终身版专属
#  ===========================================================
#  统一工具协议见 tools/power.sh 开头。
#
#  干的事:管屏幕的"脾气" —— 多久自动息屏、充电时要不要一直亮着、
#        转手腕时屏幕要不要跟着转。都是系统设置里的老开关,
#        只是原版藏得深、还得分好几步点,这里一页搞定。
#
#  和「星眼(eye)」的分工:
#    eye 管"多亮"(亮度 + 深色),screen 管"亮多久 / 转不转"。互不干涉。
# ============================================================================

PWDIR=${0%/*}
[ -d "$PWDIR" ] || PWDIR=/data/adb/modules/zz_star_os/tools
MODD=${PWDIR%/*}
[ -d "$MODD" ] || MODD=/data/adb/modules/zz_star_os
STAR=${STAR_DIR:-/data/adb/star_os}
SC=$STAR/screen
LOG=$STAR/logs/screen.log

mkdir -p "$SC" "$STAR/logs" 2>/dev/null

sc_log() { echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$LOG" 2>/dev/null; }

sc_tier() {
  scv=0
  if [ -f "$STAR/pro.conf" ]; then
    scv=$(sed -n 's/^tier=//p' "$STAR/pro.conf" 2>/dev/null | head -n 1)
  fi
  case "$scv" in
    ''|*[!0-9]*) echo 0 ;;
    *) echo "$scv" ;;
  esac
}

sc_gate() {
  [ "$(sc_tier)" -ge 2 ] && return 0
  echo "星屏是 Pro+ / 终身版功能,当前等级不够" >&2
  return 5
}

sc_get() { settings get "$1" "$2" 2>/dev/null; }
sc_put() { settings put "$1" "$2" "$3" >/dev/null 2>&1; }

# 息屏超时(毫秒) -> "30 秒 / 5 分" 这种
sc_timeout_txt() {
  sct=$(sc_get system screen_off_timeout)
  case "$sct" in ''|null|*[!0-9]*) echo "读不到"; return 0 ;; esac
  if [ "$sct" -ge 60000 ]; then
    echo "$((sct / 60000)) 分钟"
  else
    echo "$((sct / 1000)) 秒"
  fi
}

# 充电时常亮:stay_on_while_plugged_in 是位掩码(1=USB 2=AC 4=无线)
sc_stay_txt() {
  scs=$(sc_get global stay_on_while_plugged_in)
  case "$scs" in ''|null|*[!0-9]*) echo "关"; return 0 ;; esac
  [ "$scs" = "0" ] && { echo "关"; return 0; }
  echo "开(充电时不息屏)"
}

sc_rot_txt() {
  scr=$(sc_get system accelerometer_rotation)
  case "$scr" in 1) echo "自动旋转:开" ;; 0) echo "自动旋转:关(固定)" ;; *) echo "自动旋转:默认" ;; esac
}

# 取一个比当前短/长的档位
sc_timeout_step() {
  scd=$1
  sct=$(sc_get system screen_off_timeout)
  case "$sct" in ''|null|*[!0-9]*) sct=30000 ;; esac
  if [ "$scd" = "down" ]; then
    case "$sct" in
      *0000) scn=$((sct - 30000)) ;;
      *) scn=$((sct - 15000)) ;;
    esac
    [ "$scn" -lt 15000 ] && scn=15000
  else
    case "$sct" in
      *0000) scn=$((sct + 30000)) ;;
      *) scn=$((sct + 15000)) ;;
    esac
    [ "$scn" -gt 1800000 ] && scn=1800000
  fi
  sc_put system screen_off_timeout "$scn"
  echo "息屏:$(sc_timeout_txt)"
}

sc_status() {
  echo "息屏超时:$(sc_timeout_txt)"
  echo "$(sc_rot_txt)"
  echo "充电常亮:$(sc_stay_txt)"
  echo ""
  echo "@item|息屏短一点|act|tdown"
  echo "@item|息屏长一点|act|tup"
  echo "@item|充电时常亮 开/关|act|stay"
  echo "@item|自动旋转 开/关|act|rot"
  return 0
}

case "$1" in
  meta)
    echo "screen|星屏|息屏多久、充电常亮、自动旋转,一页管完|2|tdown:息屏更短:ghost,tup:息屏更长:ghost,stay:充电常亮:pri,rot:自动旋转:ghost"
    ;;
  status)
    sc_gate || exit 5
    sc_status
    ;;
  act)
    sc_gate || exit 5
    case "$2" in
      tdown) sc_timeout_step down ;;
      tup) sc_timeout_step up ;;
      stay)
        scs=$(sc_get global stay_on_while_plugged_in)
        if [ "$scs" = "0" ] || [ -z "$scs" ] || [ "$scs" = "null" ]; then
          sc_put global stay_on_while_plugged_in 7
          echo "充电时常亮:已开(USB/充电器都算)"
        else
          sc_put global stay_on_while_plugged_in 0
          echo "充电时常亮:已关"
        fi
        sc_log "stay=$(sc_get global stay_on_while_plugged_in)"
        ;;
      rot)
        scr=$(sc_get system accelerometer_rotation)
        if [ "$scr" = "1" ]; then
          sc_put system accelerometer_rotation 0
          echo "自动旋转:已关,屏幕固定不再跟着转"
        else
          sc_put system accelerometer_rotation 1
          echo "自动旋转:已开"
        fi
        ;;
      *)
        echo "未知动作:$2" >&2
        exit 2
        ;;
    esac
    ;;
  *)
    echo "用法:$0 {meta|status|act <动作>}" >&2
    exit 2
    ;;
esac
