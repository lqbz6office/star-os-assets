#!/system/bin/sh
##########################################################################
# uninstall.sh —— 卸载 Star OS 时执行
#
# 模块内的所有文件都只是挂载到系统分区上的“影子”,卸载即消失,
# 原始系统文件从未被改动,所以这里不需要、也不应该去“还原”任何东西。
#
# 要清理的只有模块自己在模块目录之外留下的痕迹:
#   * /data/adb/star_os/   —— 开机自检的状态与日志
#
# 另外顺手清掉 disable 标记:如果模块当前处于被自检禁用的状态,
# 残留的 disable 文件会让用户下次重装后依然失效,必须删掉。
#
# 注意:这里绝对不能执行 reboot,否则模块会因为重启而删不干净。
##########################################################################

MODDIR=${MODDIR:-${0%/*}}

# 0) 先停掉整合进来的两个守护进程
#    它们都是 while true 的常驻循环,脚本文件随模块一起被删掉后仍会在内存里
#    空转(一直去读已经不存在的节点),必须在这里先杀掉。
#    注意 ultra_performance 是二进制守护,它会自己再拉起 ultra_performance.sh,
#    所以要按命令行关键字一起匹配。
kill_by_cmdline() {
  # 优先 pgrep -f;老机型 toybox 不带这个参数就退化成 ps + grep
  _pids=$(pgrep -f "$1" 2>/dev/null)
  if [ -z "$_pids" ]; then
    _pids=$(ps -A 2>/dev/null | grep -v grep | grep "$1" | awk '{print $2}')
  fi
  for _pid in $_pids; do
    case "$_pid" in ''|*[!0-9]*) continue ;; esac
    [ "$_pid" = "$$" ] && continue
    kill "$_pid" 2>/dev/null
  done
}

for _pat in ultra_performance tweak_main.sh perfboost.sh; do
  kill_by_cmdline "$_pat"
done

# 锁文件也一并清掉,避免下次装上模块时被旧 PID 误判成"已经在跑"
rm -f /data/adb/star_os/tweak_loop.pid 2>/dev/null

# 1) 清除自检状态与日志
rm -rf /data/adb/star_os

# 1.5) 关于随模块安装的 桌面/侧边栏/AI识屏:
#      绝对不要在这里自动 pm uninstall!
#      com.xtc.i3launcher 是桌面(HOME),卸载它会让设备开完机没有桌面可进,
#      直接黑屏 —— 这正是“卸载模块 = 安全回退”这个前提被打破的地方。
#      这三个应用装在 data 分区,卸载模块后它们仍在,想删请自己到
#      设置->应用 里手动卸载,或者先装回一个桌面再删。
#      模块目录里的 payload/ 会随模块一起消失,不影响已安装的应用。

# 1.6) 清掉核心破解的提示文件(模块都卸了,这个提醒也该消失)
rm -f "/data/media/0/StarOS/请激活核心破解.txt" 2>/dev/null
#     在线版的「请重启一次」提示同理 —— 模块都没了,别再让人重启
rm -f "/data/media/0/StarOS/请重启一次.txt" 2>/dev/null

# 1.7) 在线版残留物:
#     * /data/adb/star_os 整个目录已在上面 1) 里删掉,assets_fetch.log 随之消失;
#     * .assets_lock 是"正在解包"的哨兵(在模块目录里),留着会让下次重装
#       的第一轮完整性自检被跳过;
#     * .assets_dl 是没下完的残档,可能几十上百 MB,必须清掉。
rm -f "$MODDIR/.assets_lock" 2>/dev/null
rm -rf "$MODDIR/.assets_dl" 2>/dev/null

# 2) 清除可能残留的禁用标记(防止重装后模块被自动跳过)
rm -f "$MODDIR/disable"
rm -f "$MODDIR/remove"
rm -f "$MODDIR/update"

# 3) 清掉模块目录里可能遗留的临时文件
rm -f "$MODDIR"/*.tmp "$MODDIR"/state 2>/dev/null

exit 0
