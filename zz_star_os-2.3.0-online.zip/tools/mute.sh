#!/system/bin/sh
# ============================================================================
#  Star OS · 星静 (mute.sh)   —— 基础功能(免费,人人可用)
#  ===========================================================
#  统一工具协议见 tools/power.sh 开头。
#
#  干的事:开会、上课、睡前想安静 —— 三个开关:勿扰、震动反馈、触摸音;
#        外加一个"一键安静"(三个一起摁下去,退出时原样还原)。
#
#  为什么免费:安静是刚需,不该拿来卖。
#
#  和技术细节有关的实话:
#    · 勿扰走 settings global zen_mode(0=关 1=仅重要 2=完全静音),8.1 上稳。
#    · 震动反馈 / 触摸音走 system 里的开关,稳。
#    · 不做"音量滑块" —— 各机型的音量键名不统一,写错了会显示成功但没反应,
#      这种"看着能用其实没用"的功能宁可不做。
# ============================================================================

PWDIR=${0%/*}
[ -d "$PWDIR" ] || PWDIR=/data/adb/modules/zz_star_os/tools
MODD=${PWDIR%/*}
[ -d "$MODD" ] || MODD=/data/adb/modules/zz_star_os
STAR=${STAR_DIR:-/data/adb/star_os}
MU=$STAR/mute
LOG=$STAR/logs/mute.log
SNAP=$MU/snap.conf

mkdir -p "$MU" "$STAR/logs" 2>/dev/null

mu_log() { echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$LOG" 2>/dev/null; }
mu_get() { settings get "$1" "$2" 2>/dev/null; }
mu_put() { settings put "$1" "$2" "$3" >/dev/null 2>&1; }

mu_zen() {
  muz=$(mu_get global zen_mode)
  case "$muz" in
    1) echo "仅重要" ;;
    2) echo "完全静音" ;;
    *) echo "关" ;;
  esac
}

mu_vib() {
  mv_v=$(mu_get system haptic_feedback_enabled)
  case "$mv_v" in
    1) echo "开" ;;
    0) echo "关" ;;
    *) echo "默认" ;;
  esac
}

mu_touch() {
  mt_v=$(mu_get system sound_effects_enabled)
  case "$mt_v" in
    1) echo "开" ;;
    0) echo "关" ;;
    *) echo "默认" ;;
  esac
}

# ---------------------------------------------------------------- 快照
# 一键安静之前,把三个开关的原值记下来,退出时一模一样还回去
mu_snapshot() {
  [ -f "$SNAP" ] && return 0
  true > "$SNAP"
  echo "zen=$(mu_get global zen_mode)" >> "$SNAP"
  echo "vib=$(mu_get system haptic_feedback_enabled)" >> "$SNAP"
  echo "touch=$(mu_get system sound_effects_enabled)" >> "$SNAP"
  mu_log "snapshot: $(tr '\n' ' ' < "$SNAP")"
}

mu_snap_get() { sed -n "s/^$1=//p" "$SNAP" 2>/dev/null | head -n 1; }

# 值为空/null 就不还原(别把系统键写成空串)
mu_restore_one() {
  mur_v=$(mu_snap_get "$1")
  case "$mur_v" in
    ''|null|*[!0-9]*) return 0 ;;
  esac
  mu_put "$2" "$3" "$mur_v"
}

mu_quiet_on() {
  mu_snapshot
  mu_put global zen_mode 2
  mu_put system haptic_feedback_enabled 0
  mu_put system sound_effects_enabled 0
  mu_log "一键安静 开"
}

mu_quiet_off() {
  mu_restore_one zen global zen_mode
  mu_restore_one vib system haptic_feedback_enabled
  mu_restore_one touch system sound_effects_enabled
  mu_log "一键安静 关,已还原"
}

mu_quiet_state() {
  mqs=$(mu_zen)
  mqv=$(mu_vib)
  mqt=$(mu_touch)
  if [ "$mqs" = "完全静音" ] && [ "$mqv" = "关" ] && [ "$mqt" = "关" ]; then
    echo "on"
  else
    echo "off"
  fi
}

# ---------------------------------------------------------------- 状态
mu_status() {
  mu_z=$(mu_zen)
  mu_v=$(mu_vib)
  mu_t=$(mu_touch)
  echo "勿扰:$mu_z"
  echo "震动反馈:$mu_v"
  echo "触摸音:$mu_t"
  echo ""
  if [ "$(mu_quiet_state)" = "on" ]; then
    echo "当前:已安静(三个都摁下去了)"
  else
    echo "当前:有声音"
  fi
  echo ""
  echo "@item|一键安静/恢复|act|quiet"
  echo "@item|勿扰开关(关->仅重要->完全静音)|act|zen"
  echo "@item|震动反馈开关|act|vib"
  echo "@item|触摸音开关|act|touch"
  return 0
}

case "$1" in
  meta)
    echo "mute|星静|勿扰/震动/触摸音三个开关,一键安静|0|quiet:一键安静:pri,zen:勿扰:ghost,vib:震动:ghost,touch:触摸音:ghost"
    ;;
  status)
    mu_status
    ;;
  act)
    case "$2" in
      quiet)
        if [ "$(mu_quiet_state)" = "on" ]; then
          mu_quiet_off
          echo "已恢复原来的声音设置"
        else
          mu_quiet_on
          echo "已一键安静:勿扰(完全静音)+ 关震动 + 关触摸音"
          echo "再点一次「一键安静/恢复」就还原。"
        fi
        ;;
      zen)
        muz=$(mu_get global zen_mode)
        case "$muz" in
          1) mu_put global zen_mode 2; echo "勿扰:仅重要 -> 完全静音" ;;
          2) mu_put global zen_mode 0; echo "勿扰:完全静音 -> 关" ;;
          *) mu_put global zen_mode 1; echo "勿扰:关 -> 仅重要提醒" ;;
        esac
        mu_log "zen=$(mu_get global zen_mode)"
        ;;
      vib)
        mv_v=$(mu_get system haptic_feedback_enabled)
        if [ "$mv_v" = "1" ]; then
          mu_put system haptic_feedback_enabled 0
          echo "震动反馈:已关"
        else
          mu_put system haptic_feedback_enabled 1
          echo "震动反馈:已开"
        fi
        ;;
      touch)
        mt_v=$(mu_get system sound_effects_enabled)
        if [ "$mt_v" = "1" ]; then
          mu_put system sound_effects_enabled 0
          echo "触摸音:已关"
        else
          mu_put system sound_effects_enabled 1
          echo "触摸音:已开"
        fi
        ;;
      *)
        echo "未知动作:$2" >&2
        exit 2
        ;;
    esac
    ;;
  *)
    echo "用法:$0 {meta|status|act <动作>}" >&2
    exit 2
    ;;
esac
