#!/system/bin/sh
# ============================================================================
#  Star OS · 星时 (focus.sh)   —— Pro+ / 终身版专属
#  ===========================================================
#  统一工具协议见 tools/power.sh 开头。
#
#  干的事:专注计时(番茄钟)。开一个 25/45/60 分钟,期间自动进免打扰,
#        到点提醒你;每一段都会记进日志,能看今天/这周一共专注了多久。
#
#  和「星际指令」的区别:指令是"条件→动作"的通用自动化;
#  星时是专用的、带计时和统计的专注工具 —— 场景固定,所以体验可以做得更顺:
#  一键开始、自动免打扰、到点震动、时长自动记账,不用自己写规则。
#
#  计时靠 tick(每分钟一次)判断到期,不靠 sleep 一个大循环 ——
#  这样即使应用被杀、甚至这个脚本被重启,专注状态也不会丢(状态在文件里)。
# ============================================================================

PWDIR=${0%/*}
[ -d "$PWDIR" ] || PWDIR=/data/adb/modules/zz_star_os
STAR=${STAR_DIR:-/data/adb/star_os}
FD=$STAR/focus
CUR=$FD/cur
LOG=$FD/log.tsv
FLOG=$STAR/logs/focus.log

mkdir -p "$FD" "$STAR/logs" 2>/dev/null

fo_log() { echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$FLOG" 2>/dev/null; }

fo_tier() {
  fog_v=0
  if [ -f "$STAR/pro.conf" ]; then
    fog_v=$(sed -n 's/^tier=//p' "$STAR/pro.conf" 2>/dev/null | head -n 1)
  fi
  case "$fog_v" in
    ''|*[!0-9]*) echo 0 ;;
    *) echo "$fog_v" ;;
  esac
}

fo_gate() {
  [ "$(fo_tier)" -ge 2 ] && return 0
  echo "星时是 Pro+ / 终身版功能,当前等级不够" >&2
  return 5
}

# 正在专注? 输出 "剩余秒数 总分钟",没在专注就输出空
fo_cur() {
  [ -f "$CUR" ] || return 0
  foc_u=$(sed -n 's/^until=//p' "$CUR" | head -n 1)
  foc_l=$(sed -n 's/^len=//p' "$CUR" | head -n 1)
  case "$foc_u" in ''|*[!0-9]*) return 0 ;; esac
  foc_n=$(date '+%s')
  foc_left=$((foc_u - foc_n))
  [ "$foc_left" -le 0 ] && return 0
  echo "$foc_left $foc_l"
}

fo_mmss() {
  echo "$(($1 / 60)) 分 $(($1 % 60)) 秒"
}

fo_log_add() {
  # $1=分钟
  fol_d=$(date '+%Y-%m-%d')
  echo "$fol_d	$1" >> "$LOG"
}

fo_sum_days() {
  # $1..= 要统计的日期(空格分隔),输出分钟合计
  fos_days="$1"
  fos_s=0
  [ -f "$LOG" ] || { echo 0; return 0; }
  while read -r fos_line; do
    [ -z "$fos_line" ] && continue
    fos_d=$(echo "$fos_line" | cut -f1)
    fos_v=$(echo "$fos_line" | cut -f2)
    case "$fos_v" in ''|*[!0-9]*) continue ;; esac
    for fos_x in $fos_days; do
      if [ "$fos_d" = "$fos_x" ]; then
        fos_s=$((fos_s + fos_v))
        break
      fi
    done
  done < "$LOG"
  echo "$fos_s"
}

fo_today() { fo_sum_days "$(date '+%Y-%m-%d')"; }

fo_week() {
  # ⚠ 别用 `date -d @<epoch>` 往前推日期:Android 的 toybox date 不一定支持 -d,
  #   支持与否还看 ROM。日志本身就是按日期追加的,直接取"最近 7 个不同日期"最稳。
  [ -f "$LOG" ] || { echo 0; return 0; }
  fow_days=$(cut -f1 "$LOG" 2>/dev/null | sort -u | tail -n 7 | tr '\n' ' ')
  [ -z "$(echo "$fow_days" | tr -d ' ')" ] && { echo 0; return 0; }
  fo_sum_days "$fow_days"
}

fo_hm() {
  if [ "$1" -ge 60 ]; then
    echo "$(( $1 / 60 )) 小时 $(( $1 % 60 )) 分"
  else
    echo "$1 分钟"
  fi
}

# ---------------------------------------------------------------- 进入/退出
fo_start() {
  fst_min=$1
  fos_c=$(fo_cur)
  if [ -n "$fos_c" ]; then
    echo "已经在专注中(还剩 $(fo_mmss "$(echo "$fos_c" | cut -d' ' -f1)"))"
    echo "要重新开始,先点「结束这段」。"
    return 0
  fi
  fst_now=$(date '+%s')
  # 先记住原来的免打扰状态,结束时要一模一样还回去
  fst_zen=$(settings get global zen_mode 2>/dev/null)
  echo "start=$fst_now" > "$CUR"
  echo "len=$fst_min" >> "$CUR"
  echo "until=$((fst_now + fst_min * 60))" >> "$CUR"
  echo "zen=$fst_zen" >> "$CUR"
  # 1 = 仅允许优先打扰(手表上等于静音)
  settings put global zen_mode 1 >/dev/null 2>&1
  cmd notification post -S bigtext -t "星时" star_os_focus "专注 $fst_min 分钟,已开启免打扰" >/dev/null 2>&1
  fo_log "start ${fst_min}min"
  echo "已开始专注 ${fst_min} 分钟"
  echo "免打扰已开启,到点会提醒你。中途想停就点「结束这段」。"
}

fo_stop() {
  fsc_c=$(fo_cur)
  if [ -z "$fsc_c" ]; then
    # 可能已经过期了(daemon 还没来得及收尾)
    [ -f "$CUR" ] && fo_expire && return 0
    echo "现在没有在专注"
    return 0
  fi
  fsc_start=$(sed -n 's/^start=//p' "$CUR" | head -n 1)
  fsc_len=$(sed -n 's/^len=//p' "$CUR" | head -n 1)
  fsc_now=$(date '+%s')
  fsc_done=$(( (fsc_now - fsc_start) / 60 ))
  [ "$fsc_done" -lt 1 ] && fsc_done=1
  fo_end_common
  fo_log_add "$fsc_done"
  echo "这段专注结束:${fsc_done} 分钟(计划 ${fsc_len} 分钟)"
  echo "已记账。今天累计 $(fo_hm "$(fo_today)")。"
}

# 自然到期:记为完整时长
fo_expire() {
  foe_len=$(sed -n 's/^len=//p' "$CUR" | head -n 1)
  case "$foe_len" in ''|*[!0-9]*) foe_len=0 ;; esac
  fo_end_common
  [ "$foe_len" -gt 0 ] && fo_log_add "$foe_len"
  cmd notification post -S bigtext -t "星时" star_os_focus "专注完成,休息一下 ☕" >/dev/null 2>&1
  fo_log "expire ${foe_len}min"
}

fo_end_common() {
  fez_z=$(sed -n 's/^zen=//p' "$CUR" 2>/dev/null | head -n 1)
  case "$fez_z" in
    ''|null|*[!0-9]*) fez_z=0 ;;
  esac
  settings put global zen_mode "$fez_z" >/dev/null 2>&1
  rm -f "$CUR" 2>/dev/null
}

# ---------------------------------------------------------------- 状态
fo_status() {
  foc=$(fo_cur)
  if [ -n "$foc" ]; then
    echo "状态:专注中"
    echo "剩余:$(fo_mmss "$(echo "$foc" | cut -d' ' -f1)")"
    echo "这段:$(echo "$foc" | cut -d' ' -f2) 分钟"
    echo ""
    echo "@item|提前结束这段|act|stop"
  else
    # 看看是不是刚好过期了
    if [ -f "$CUR" ]; then
      fo_expire >/dev/null 2>&1
      echo "状态:刚结束一段(已完成)"
    else
      echo "状态:空闲"
    fi
    echo "今天已专注:$(fo_hm "$(fo_today)")"
    echo "本周累计:$(fo_hm "$(fo_week)")"
    echo ""
    echo "@item|专注 25 分钟|act|m25"
    echo "@item|专注 45 分钟|act|m45"
    echo "@item|专注 60 分钟|act|m60"
  fi
  return 0
}

fo_stats() {
  echo "今天:$(fo_hm "$(fo_today)")"
  echo "最近 7 天:$(fo_hm "$(fo_week)")"
  echo ""
  if [ ! -f "$LOG" ] || [ "$(grep -c . "$LOG" 2>/dev/null)" = "0" ]; then
    echo "还没有记录。开一段专注试试。"
    return 0
  fi
  echo "最近 7 天每天:"
  fod_list=$(cut -f1 "$LOG" 2>/dev/null | sort -u | tail -n 7)
  if [ -z "$fod_list" ]; then
    echo "  (还没有记录)"
  else
    echo "$fod_list" | while read -r fod; do
      [ -z "$fod" ] && continue
      fov=$(fo_sum_days "$fod")
      # 用方块画个极简柱状图(手表上没有图表控件,字符最实在)
      fob=""
      foj=0
      while [ "$foj" -lt $((fov / 15)) ] && [ "$foj" -lt 20 ]; do
        fob="$fob#"
        foj=$((foj + 1))
      done
      echo "  $fod  ${fov}分 $fob"
    done
  fi
  echo ""
  echo "(每个 # 代表 15 分钟)"
}

case "$1" in
  meta)
    echo "focus|星时|专注计时 + 免打扰 + 自动记账|2|m25:25 分钟:pri,m45:45 分钟:pri,m60:60 分钟:ghost,stop:结束这段:ghost,stats:专注统计:ghost"
    ;;
  status)
    fo_gate || exit 5
    fo_status
    ;;
  act)
    fo_gate || exit 5
    case "$2" in
      m25) fo_start 25 ;;
      m45) fo_start 45 ;;
      m60) fo_start 60 ;;
      stop) fo_stop ;;
      stats) fo_stats ;;
      *)
        echo "未知动作:$2" >&2
        exit 2
        ;;
    esac
    ;;
  tick)
    # 每分钟来一次:只看有没有到期
    if [ -f "$CUR" ]; then
      foc=$(fo_cur)
      if [ -z "$foc" ]; then
        fo_expire
      fi
    fi
    ;;
  daemon)
    fo_log "星时 daemon 启动 (pid=$$)"
    while true; do
      "$0" tick >/dev/null 2>&1
      sleep 60
    done
    ;;
  *)
    echo "用法:$0 {meta|status|act <动作>|tick|daemon}" >&2
    exit 2
    ;;
esac
