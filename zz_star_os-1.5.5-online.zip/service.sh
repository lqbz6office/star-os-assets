#!/system/bin/sh
##########################################################################
# service.sh —— 开机自检的“收尾” + 桌面/配套应用的“最后安装”
#
# 本阶段异步执行,不会拖慢开机,所以可以放心等待。
#
# 做六件事:
#   1. 等系统真正启动完成(sys.boot_completed=1),再留一段观察期;
#   2. 确认稳定后把 post-fs-data.sh 累加的“启动尝试计数”清零
#      —— 计数不清零,模块就会在累计 3 次后被自检误判为“开机失败”而禁用;
#   3. 验证模块文件是否真的挂载到了系统路径上,结果写进日志,
#      出问题时可以直接看 /data/adb/star_os/guard.log 定位;
#   4. 检查核心破解(CorePatch)是否安装并激活,
#      没激活就把「请激活核心破解」写进日志和内部存储(见 corepatch_check.sh);
#   5. 拉起整合进来的三个增强模块(极致性能 / 桌面流畅度 / WiFi 绑定),
#      开关在 /data/adb/star_os/tweaks.conf;
#   6. 按一包通的顺序安装 Z12 桌面与配套应用(桌面【最后】装);
#   7. 模块「首次安装」或「更新之后」,开机弹一次 Star OS 欢迎页
#      —— 【注意】这一步不在这里做,而是开机最早期就交给
#      welcome_launch.sh 并发跑(见下面第 0 节),否则会被 1~6 步拖后
#      十几秒才弹出来(1.4.1fix2 的老毛病)。
#
# 为什么安装放在这里而不是 customize.sh:
#   刷模块时如果是在 recovery 里跑的,那会儿 Android 根本没起来,
#   pm(PackageManager)不存在,装不了任何应用。
#   所以 customize.sh 里只做“试着装一次”,真正保证装上的是这里 ——
#   等系统完全启动、包管理服务就绪之后再动手,这就是所谓“最后安装”。
##########################################################################

MODDIR=${MODDIR:-${0%/*}}
MODID=${MODDIR##*/}          # 模块 ID 就是目录名,用于日志里定位挂载冲突
STATE=/data/adb/star_os
mkdir -p "$STATE" 2>/dev/null   # 必须紧跟其后:下面所有 $STATE/... 读写都依赖它存在
LOG=$STATE/guard.log
PM=/system/bin/pm
CMDPKG=/system/bin/cmd
AM=/system/bin/am

log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" >> "$LOG" 2>/dev/null; }

# ==========================================================================
#  0. 【并行】开机完成即拉起欢迎页 —— 必须放在最前面
#
#  1.4.1fix2 及更早:弹欢迎页排在本文档最末尾,前面挡着
#    「等 sys.boot_completed → sleep 20 秒观察期 → 装三个 APK → 切默认桌面」,
#  于是用户进了桌面还要等十几二十秒才看到欢迎页 —— 就是这个 bug。
#
#  现在改成:开机最早期就把 welcome_launch.sh 甩到一个【独立会话】里跑,
#  它等 boot_completed 后立刻 am start,和下面 1~7 步完全并行、互不阻塞。
#
#  用 setsid 脱离父进程(而不是普通 &):service.sh 随时可能结束,
#  普通子进程会跟着壳一起被收走;脱了会话就能一直活到拉起为止。
#  没有 setsid 就退化成普通后台子进程(绝大多数设备用不到这条)。
# ==========================================================================
if [ -f "$MODDIR/welcome_launch.sh" ]; then
  chmod 0755 "$MODDIR/welcome_launch.sh" 2>/dev/null
  if command -v setsid >/dev/null 2>&1; then
    setsid sh "$MODDIR/welcome_launch.sh" "$MODDIR" >/dev/null 2>&1 &
  else
    sh "$MODDIR/welcome_launch.sh" "$MODDIR" >/dev/null 2>&1 &
  fi
  log "欢迎页: 拉起任务已并发启动(不等自检,开机完成即弹)"
fi

# ==========================================================================
#  0.1 【并行】插件开机钩子
#
#  同样是「不能让插件拖慢开机」的思路:每个插件的 boot 钩子都可能很慢
#  (联网、下载),所以也在最早时刻甩到独立会话里跑,和自检并行。
#  单个插件失败只进日志,绝不影响开机 —— plugin_exec.sh 自己保证这点。
# ==========================================================================
if [ -f "$MODDIR/plugin_exec.sh" ]; then
  chmod 0755 "$MODDIR/plugin_exec.sh" "$MODDIR/sos.sh" 2>/dev/null
  # plugin_exec.sh 的 boot 子命令自己会等 boot_completed + 15 秒缓冲,
  # 所以这里只要把它甩出去就行。
  if command -v setsid >/dev/null 2>&1; then
    setsid sh "$MODDIR/plugin_exec.sh" boot >/dev/null 2>&1 &
  else
    sh "$MODDIR/plugin_exec.sh" boot >/dev/null 2>&1 &
  fi
  log "插件: 开机钩子任务已并发启动(等开机完成 + 15 秒缓冲后执行)"
fi

# 核心破解检测函数(与 customize.sh 共用同一份实现,避免两边判断不一致)
[ -f "$MODDIR/corepatch_check.sh" ] && . "$MODDIR/corepatch_check.sh"

# 在线版:资源包状态。embedded = 离线全量版(文件本来就在,恒为"已就位");
# online = 在线版,若刷入时没下到,这里要负责兜底重试。
[ -f "$MODDIR/assets.conf" ] && . "$MODDIR/assets.conf"
[ -f "$MODDIR/assets_fetch.sh" ] && . "$MODDIR/assets_fetch.sh"
ASSETS_MISSING=0
if [ "$ASSETS_MODE" = "online" ]; then
  af_assets_present "$MODDIR" || ASSETS_MISSING=1
fi

# ---------- 1. 等开机完成(最多等 5 分钟,超时就放弃) ----------
i=0
while [ "$(getprop sys.boot_completed)" != "1" ] && [ "$i" -lt 150 ]; do
  sleep 2
  i=$((i + 1))
done

# 没等到就退出:计数保持不清零,交给 post-fs-data.sh 在下次开机累加判定
[ "$(getprop sys.boot_completed)" != "1" ] && exit 0

# ---------- 2. 观察期:排除“刚起来又崩”的情况 ----------
sleep 20
[ "$(getprop sys.boot_completed)" != "1" ] && exit 0

echo 0 > "$STATE/boot_attempts" 2>/dev/null

# ---------- 3. 验证模块是否真的挂载生效 ----------
# 光看"文件存在"不够 —— 文件可能在,但内容是别的模块的(magic mount 是按
# 模块 ID 字母序叠的,字母序更靠后的模块会把我们的文件盖掉)。
# 所以这里按【内容特征】判断归属,发现被顶掉就单独告警。
REPORT=""
CONFLICT=""

if [ "$ASSETS_MISSING" = "1" ]; then
  # 在线版还没拿到资源 —— 此时"字体缺失/图标缺失"是预期状态,不是挂载冲突,
  # 更不能据此把模块判成开机失败。直接给一行明确的结论走人。
  REPORT="$REPORT 资源包=未就绪(在线版待下载,模块对系统暂无改动)"
elif [ -f /system/etc/fonts.xml ]; then
  if grep -q 'PingFangSC' /system/etc/fonts.xml 2>/dev/null; then
    REPORT="$REPORT 字体=已生效"
  else
    REPORT="$REPORT 字体=被顶掉"
    CONFLICT="$CONFLICT fonts.xml"
  fi
else
  REPORT="$REPORT 字体=fonts.xml缺失"
  CONFLICT="$CONFLICT fonts.xml(缺失)"
fi

# 苹方各字重都 >10MB;原厂那个银河告白清新体只有 5.29MB,
# 所以体积能直接区分"挂的是我们的还是别人的"。
FTSZ=$(wc -c < /system/fonts/font.ttf 2>/dev/null | tr -d ' ')
case "$FTSZ" in ''|*[!0-9]*) FTSZ=0 ;; esac
if [ "$ASSETS_MISSING" = "1" ]; then
  :
elif [ "$FTSZ" -gt 10485760 ]; then
  REPORT="$REPORT 主字体=$((FTSZ / 1048576))MB(苹方)"
elif [ "$FTSZ" -gt 1048576 ]; then
  REPORT="$REPORT 主字体=$((FTSZ / 1048576))MB(不是苹方)"
  CONFLICT="$CONFLICT font.ttf"
else
  REPORT="$REPORT 主字体=异常(${FTSZ}B)"
  CONFLICT="$CONFLICT font.ttf(异常)"
fi

if [ "$ASSETS_MISSING" != "1" ]; then
if [ -f /system/media/bootanimation.zip ]; then
  BASZ=$(wc -c < /system/media/bootanimation.zip 2>/dev/null | tr -d ' ')
  case "$BASZ" in ''|*[!0-9]*) BASZ=0 ;; esac
  REPORT="$REPORT 开机动画=${BASZ}B"
else
  REPORT="$REPORT 开机动画=缺失"
fi

# SystemUI 是我们自己带的大包(14MB 级),被别的模块换成小包就说明被顶了
UISZ=$(wc -c < /system/priv-app/XTCSystemUI/XTCSystemUI.apk 2>/dev/null | tr -d ' ')
case "$UISZ" in ''|*[!0-9]*) UISZ=0 ;; esac
if [ "$UISZ" -gt 10485760 ]; then
  REPORT="$REPORT SystemUI=$((UISZ / 1048576))MB"
elif [ "$UISZ" -gt 0 ]; then
  REPORT="$REPORT SystemUI=${UISZ}B(偏小)"
fi

ICONN=$(ls /system/vendor/res/theme/icon/ThemeYouth/*.png 2>/dev/null | wc -l | tr -d ' ')
REPORT="$REPORT 图标=${ICONN}个"
fi

# 日志超过 64KB 就重开,避免无限增长
if [ -f "$LOG" ]; then
  LSZ=$(wc -c < "$LOG" 2>/dev/null | tr -d ' ')
  case "$LSZ" in ''|*[!0-9]*) LSZ=0 ;; esac
  [ "$LSZ" -gt 65536 ] && rm -f "$LOG"
fi

log "启动成功,计数已清零 |$REPORT"

# 有文件被顶掉时给出可操作的排查提示(而不是只在日志里留一句"未生效")
if [ -n "$CONFLICT" ]; then
  log "⚠ 挂载冲突:$CONFLICT 没有生效,内容不是本模块的"
  log "  本模块 id=$MODID,Magisk 按模块 ID 字母序挂载,靠后的覆盖靠前的。"
  log "  排查: ls /data/adb/modules/  查看是否装了其它会改同一批文件的模块"
  log "  处理: 卸载那个模块,或把它目录名改成字母序更靠前的(如 a_xxx)"
fi

# ==========================================================================
#  3.5 在线版:资源包兜底下载
#
#  走这条路说明刷入时没下到资源 —— 通常是在 recovery / ATB 里刷的(那种环境没有网络)。
#  现在系统已经起来、网络可用,放后台补下:
#    * 后台跑,不阻塞本脚本后面的增强模块与桌面安装;
#    * 下完解包进模块目录,字体/图标/开机动画要【下次重启】才挂载生效;
#    * 但桌面那三个 APK 是走 pm 安装的,不依赖挂载,所以这里顺手就装掉,
#      省得你为了装桌面再等一轮;
#    * 完成后在内部存储留一份「请重启一次.txt」,不开日志也能看到。
#
#  注意:资源缺失时上面已经把启动计数清零了 —— 模块什么都没挂载,
#  不能算开机失败,否则三次开机后会被自检误判并自动禁用。
# ==========================================================================
if [ "$ASSETS_MODE" = "online" ] && [ "$ASSETS_MISSING" = "1" ]; then
  log "在线版: 资源包未就绪,已在后台开始下载(约 $(af_mb "$ASSETS_SIZE"))"
  log "  下载详情: $STATE/assets_fetch.log"

  (
    # 抓取过程全部写进独立日志,不污染 guard.log
    af_out() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" >> "$STATE/assets_fetch.log" 2>/dev/null; }

    _try=0
    while [ "$_try" -lt 2 ]; do
      _try=$((_try + 1))
      af_out "===== 第 $_try 次尝试 ====="
      if af_fetch "$MODDIR"; then
        break
      fi
      if [ "$_try" -lt 2 ]; then
        af_out "  等 30 秒后重试(可能 WiFi 刚连上)"
        sleep 30
      fi
    done

    if af_assets_present "$MODDIR"; then
      af_fix_perm "$MODDIR"
      af_out "资源包已就位: 字体/图标/开机动画需重启一次才挂载生效"
      rm -f "$STATE/assets_pending" 2>/dev/null

      # 桌面等 APK 走 pm 安装,不依赖挂载,可以现在就装
      af_out "现在直接安装桌面与配套应用(不必等重启)"
      install_payload >> "$STATE/assets_fetch.log" 2>&1

      # 内部存储留提示:文件名本身就是内容,文件管理器里一眼能看到
      if mkdir -p /data/media/0/StarOS 2>/dev/null; then
        {
          echo "Star OS —— 资源包已下载完成"
          echo ""
          echo "请重启手表一次。"
          echo "字体(苹方)、主题图标、开机动画这三样需要重启后由 Magisk 挂载才会生效。"
          echo "桌面等应用已经自动装好了,不用你操作。"
          echo ""
          echo "重启后如果一切正常,这个文件可以直接删掉。"
          echo ""
          echo "日志:/data/adb/star_os/assets_fetch.log"
        } > "/data/media/0/StarOS/请重启一次.txt" 2>/dev/null
        chmod 644 "/data/media/0/StarOS/请重启一次.txt" 2>/dev/null
      fi
    else
      af_out "本次未能下载成功,下次开机会自动重试"
    fi
  ) >/dev/null 2>&1 &
else
  # 资源已经在位:清掉可能残留的提示文件,避免误导
  rm -f /data/media/0/StarOS/请重启一次.txt 2>/dev/null
fi

# ==========================================================================
#  4. 整合进来的三个增强模块(极致性能 / 桌面流畅度 / WiFi 绑定)
#
#  Star OS 0.1.2 Beta 起,把三个独立的 Magisk 模块合并进本模块,免得同时挂
#  三份互相抢文件/抢 sysfs 的模块。三个都可以单独关,见下面的 tweaks.conf。
#
#  为什么放在"最后安装桌面"之前启动:
#    * 桌面流畅度那个循环是每 4 秒扫一次进程名,桌面无论什么时候起来它都能
#      认出来,所以早点启动更好;
#    * 极致性能的守护进程越早起来越能影响整个开机过程。
# ==========================================================================

TWEKCONF=$STATE/tweaks.conf

# 第一次开机把模块里带的模板复制到状态目录,之后以设备上的那份为准
if [ ! -f "$TWEKCONF" ] && [ -f "$MODDIR/tweaks.conf" ]; then
  cp -f "$MODDIR/tweaks.conf" "$TWEKCONF" 2>/dev/null
  log "增强功能: 已生成开关文件 /data/adb/star_os/tweaks.conf(改完重启生效)"
fi

PERF=1
PERF_THERMAL=1
SMOOTH=1
WIFI=1
# 只取三个已知变量,避免把配置里随手写的别的东西带进脚本环境
if [ -f "$TWEKCONF" ]; then
  for _k in PERF PERF_THERMAL SMOOTH WIFI; do
    _v=$(grep -E "^[[:space:]]*${_k}=" "$TWEKCONF" 2>/dev/null | tail -1 | cut -d= -f2- | tr -d ' \t\r')
    case "$_v" in
      1) eval "$_k=1" ;;
      0) eval "$_k=0" ;;
    esac
  done
fi

# 已经在跑就不重复拉起(重刷模块后不重启的情况下也能兜住)
# 老机型的 toybox 不一定带 pgrep -f,所以准备两条路,哪条通用哪条
running() {
  if pgrep -f "$1" >/dev/null 2>&1; then
    return 0
  fi
  ps -A 2>/dev/null | grep -v grep | grep -q "$1"
}

# ---------- 4.1 极致性能 ----------
PERF_DIR=$MODDIR/tweaks/perf
if [ "$PERF" = "1" ] && [ -x "$PERF_DIR/ultra_performance" ]; then
  if [ "$PERF_THERMAL" = "1" ]; then
    sh "$PERF_DIR/perfboost.sh" thermal >/dev/null 2>&1 &
  else
    sh "$PERF_DIR/perfboost.sh" >/dev/null 2>&1 &
  fi

  if running "ultra_performance"; then
    log "极致性能: 守护进程已在运行,跳过"
  else
    # ultra_performance 内部是 exec "./ultra_performance.sh"(相对路径),
    # 所以必须切到它自己所在目录再启动,否则找不到脚本。
    ( cd "$PERF_DIR" && ./ultra_performance >/dev/null 2>&1 & )
    # 等一小会儿确认真的起来了,别让日志出现"启动了但其实立刻退了"的假象
    n=0
    while [ $n -lt 5 ]; do
      running "ultra_performance" && break
      sleep 1
      n=$((n + 1))
    done
    if running "ultra_performance"; then
      log "极致性能: 守护进程已启动 (温控解锁=$PERF_THERMAL)"
    else
      log "极致性能: 守护进程启动失败(缺文件或内核不支持被拒),本次跳过"
    fi
  fi
elif [ "$PERF" = "1" ]; then
  log "极致性能: 未找到 $PERF_DIR/ultra_performance,跳过"
else
  log "极致性能: 已按 tweaks.conf 关闭"
fi

# ---------- 4.2 桌面流畅度 ----------
if [ "$SMOOTH" = "1" ] && [ -f "$MODDIR/tweaks/tweak_main.sh" ]; then
  if running "tweak_main.sh"; then
    log "桌面流畅度: 守护循环已在运行,跳过"
  else
    sh "$MODDIR/tweaks/tweak_main.sh" >/dev/null 2>&1 &
    sleep 2
    if running "tweak_main.sh"; then
      log "桌面流畅度: 守护循环已启动(每 4 秒加固一次桌面进程)"
    else
      log "桌面流畅度: 守护循环启动失败,本次跳过"
    fi
  fi
elif [ "$SMOOTH" = "1" ]; then
  log "桌面流畅度: 未找到 tweaks/tweak_main.sh,跳过"
else
  log "桌面流畅度: 已按 tweaks.conf 关闭"
fi

# ---------- 4.3 WiFi 40MHz 绑定 ----------
# 这个功能在【安装时】就把改好的配置文件放进了模块 system 分区(见 customize.sh),
# 开机时由 Magisk 挂载,不需要在这里动任何东西。这里只做一次结果回报,
# 让你不用翻安装日志也能在 guard.log 里看到到底有没有生效。
if [ "$WIFI" = "1" ]; then
  _WIFIREPORT=""
  for _w in /vendor/etc/wifi/WCNSS_qcom_cfg.ini \
            /system/vendor/etc/wifi/WCNSS_qcom_cfg.ini \
            /system/etc/wifi/WCNSS_qcom_cfg.ini; do
    [ -f "$_w" ] || continue
    if grep -q '^[[:space:]]*gChannelBondingMode24GHz[[:space:]]*=[[:space:]]*1' "$_w" 2>/dev/null; then
      _WIFIREPORT="已生效($_w)"
    else
      _WIFIREPORT="未生效($_w 里没有 40MHz 参数)"
    fi
    break
  done
  [ -n "$_WIFIREPORT" ] || _WIFIREPORT="原机没有 WCNSS_qcom_cfg.ini,该机型不适用"
  log "WiFi 40MHz 绑定: $_WIFIREPORT"
else
  log "WiFi 40MHz 绑定: 已按 tweaks.conf 关闭"
fi

# ==========================================================================
#  4.5 核心破解(CorePatch)安装 / 激活检查
#
#  随模块装的桌面/侧边栏/AI识屏 都是开发签名,设备上若有正式签名的同名应用,
#  没有核心破解就会安装失败。开机后复检一次:
#    * 已激活 -> 只在日志里记一行;
#    * 未激活 -> 日志写「请激活核心破解」,并在内部存储留一份提示文件
#                (文件名本身就叫「请激活核心破解.txt」,用文件管理器一眼能看到)。
#  检测逻辑见模块根目录的 corepatch_check.sh(那里有完整的机制说明)。
# ==========================================================================
cp_probe 2>/dev/null
CP_RC_SAVED=$?

log "核心破解: $(cp_status_line 2>/dev/null)"

if [ "$CP_RC_SAVED" -ne 0 ]; then
  log "----------------------------------------------------------"
  cp_hint | while read -r _cp_l; do log "  $_cp_l"; done
  log "----------------------------------------------------------"

  # 内部存储留一份提示,方便不开 Magisk 也能看到
  # (/data/media/0 就是内部存储根目录,和导出安装包的位置一致)
  _cp_dir=/data/media/0/StarOS
  if mkdir -p "$_cp_dir" 2>/dev/null; then
    {
      echo "Star OS —— 需要你处理的一件事"
      echo ""
      cp_hint
      echo ""
      echo "补充说明:"
      echo "  本模块会在开机后自动安装 Z12 桌面(com.xtc.i3launcher)、"
      echo "  侧边栏(com.xtc.vassistant)、AI识屏(com.xtc.intelligentIdentify)。"
      echo "  这三个包是开发签名,如果设备上已经有正式签名的同名应用,"
      echo "  系统会拒绝覆盖安装并报 signatures do not match。"
      echo "  核心破解能禁用这套签名校验,是装上去的前提。"
      echo ""
      echo "  处理完成后重启手表,本模块会再自动装一次(不会重复装已装好的)。"
      echo "  日志:/data/adb/star_os/guard.log"
    } > "$_cp_dir/请激活核心破解.txt" 2>/dev/null
    chmod 644 "$_cp_dir/请激活核心破解.txt" 2>/dev/null
    log "提示文件已写入: 内部存储/StarOS/请激活核心破解.txt"
  fi
fi

# ==========================================================================
#  5. 最后安装:Z12 桌面 + 侧边栏 + AI 识屏
#
#  一包通的官方顺序是 ①开关 → ②SystemPlus → ③SystemUI → ④桌面(装完自动重启),
#  其中 ①③ 已经直接做进模块的 system 分区,开机即生效;
#  ②(Z12桌面) 与 ⑦⑧(侧边栏/AI识屏) 是普通 APK,只能以“装应用”的方式进去。
#
#  ★ 桌面必须【最后】装:安装 com.xtc.i3launcher 会触发 HOME 组件切换,
#    如果在它之后还装别的,新装的包可能被系统重新解析一遍,桌面状态反而乱。
#    所以这里的顺序固定为:AI识屏 → 侧边栏 → 【桌面】。
#
#  安全性:装上就更好,装不上也绝不影响开机 ——
#    签名不一致(Develop 版与原厂发布版签名不同)会返回 UPDATE_INCOMPATIBLE,
#    这种情况只记日志、保持原桌面不动,不会出现黑屏;想强装可以看日志里的提示。
# ==========================================================================

PAYLOAD=$MODDIR/payload
DONE=$STATE/payload_done

install_payload() {
  [ -d "$PAYLOAD" ] || return 0
  [ -f "$DONE" ] && return 0

  # 包管理服务可能还没完全就绪,最多再等 60 秒
  n=0
  while [ $n -lt 30 ]; do
    "$PM" list packages >/dev/null 2>&1 && break
    sleep 2
    n=$((n + 1))
  done
  if ! "$PM" list packages >/dev/null 2>&1; then
    log "组件安装: package 服务未就绪,本次放弃(下次开机会重试)"
    return 0
  fi

  # 再推迟一会儿,让用户先把开机后的系统用顺手,别一开机就吃满 IO
  sleep 30

  log "组件安装: 开始(按一包通顺序,桌面最后)"
  FAILED=""
  SIGFAIL=""     # 是否出现过“签名冲突”——有就是核心破解没生效的铁证

  # $1=apk路径  $2=包名  $3=显示名
  # 注意 -t:Develop 版 APK 常带 android:testOnly 标记,不加 -t 会被系统拒装
  install_one() {
    _apk="$1"; _pkg="$2"; _name="$3"

    if [ ! -f "$_apk" ]; then
      log "  $_name: 安装包缺失"
      FAILED="$FAILED $_name(缺包)"
      return 0
    fi

    if "$PM" path "$_pkg" >/dev/null 2>&1; then
      log "  $_name: 已安装,跳过"
      return 0
    fi

    _out=$("$PM" install -r -d -t -g "$_apk" 2>&1)

    case "$_out" in
      *Success*)
        log "  $_name: 安装成功"
        ;;
      *UPDATE_INCOMPATIBLE*|*INCONSISTENT_CERTIFICATES*|*signatures*do*not*match*|*INSTALL_FAILED_UPDATE_INCOMPATIBLE*)
        log "  $_name: 签名冲突 —— 设备上已有同名应用且签名不同,保持原样未改动"
        FAILED="$FAILED $_name(签名冲突)"
        SIGFAIL="1"
        ;;
      *INSTALL_FAILED_OLDER_SDK*)
        log "  $_name: 系统版本过低,该 APK 要求更高 SDK"
        FAILED="$FAILED $_name(版本不符)"
        ;;
      *)
        log "  $_name: 安装失败 -> $_out"
        FAILED="$FAILED $_name(失败)"
        ;;
    esac
    return 0
  }

  # 先配套,后桌面 —— 顺序不可调换
  install_one "$PAYLOAD/ai_screen.apk"  com.xtc.intelligentIdentify "AI识屏"
  install_one "$PAYLOAD/sidebar_ai.apk" com.xtc.vassistant         "侧边栏AI启动器"
  install_one "$PAYLOAD/i3launcher.apk" com.xtc.i3launcher         "Z12桌面(最后一个)"

  # 桌面装好后把它设成默认 HOME,否则按 HOME 键还是回原桌面
  if "$PM" path com.xtc.i3launcher >/dev/null 2>&1; then
    _home=$("$CMDPKG" package resolve-activity --brief \
              -a android.intent.action.MAIN -c android.intent.category.HOME \
              com.xtc.i3launcher 2>/dev/null | tail -1)
    case "$_home" in
      */*)
        if "$CMDPKG" package set-home-activity "$_home" >/dev/null 2>&1; then
          log "  默认桌面已切换: $_home"
        else
          log "  默认桌面切换失败,可在设置->应用->默认应用中手动选择"
        fi
        ;;
      *)
        log "  未取到桌面入口组件,默认桌面未改动"
        ;;
    esac
  fi

  if [ -n "$FAILED" ]; then
    log "组件安装: 完成(有问题:$FAILED)"
    log "  处理办法: 确认原机同名应用可卸载后,执行 pm uninstall <包名> 再重刷模块"

    # 出现过签名冲突 = 核心破解没生效的铁证。
    # 实测比开机时的预检更准(预检可能因为作用域还没加载而误判),所以这里再报一次。
    if [ -n "$SIGFAIL" ]; then
      log "----------------------------------------------------------"
      log "  安装失败原因含「签名不匹配」—— 核心破解没有生效。"
      cp_probe 2>/dev/null
      cp_hint | while read -r _cp_l; do log "  $_cp_l"; done
      log "----------------------------------------------------------"
    fi

    # 有装不上的,就把安装包放到内部存储,让你能用文件管理器手动点安装重试,
    # 不必再接线传一遍 100 多 MB(路径固定 /data/media/0 = 内部存储根目录)
    EXPORT=/data/media/0/StarOS
    if mkdir -p "$EXPORT" 2>/dev/null; then
      cp -f "$PAYLOAD"/*.apk "$EXPORT/" 2>/dev/null
      {
        echo "Star OS —— Z12 桌面 / 配套应用安装包"
        echo ""
        echo "自动安装时有部分没成功:$FAILED"
        echo ""
        echo "手动安装步骤:"
        echo "  1. 用文件管理器逐个点开下面的 APK 安装"
        echo "  2. 顺序:先 ai_screen.apk、sidebar_ai.apk,最后 i3launcher.apk(桌面)"
        echo "  3. ★ 装不上多半是签名冲突。首选办法是激活核心破解:"
        echo "     LSPosed -> 模块 -> 核心破解 -> 打开开关,作用域勾「系统框架」-> 重启"
        echo "     这样签名校验被禁用,不同签名的同名应用可以直接覆盖安装。"
        echo "  4. 不用核心破解的话,只能先在 设置->应用 里卸载设备上的同名应用再装。"
        echo "     (注意:com.xtc.i3launcher 是桌面,卸了会没桌面可用,别卸它)"
        echo "  5. 桌面装好后如果 HOME 键没反应,重启一次即可"
        echo ""
        echo "文件对应关系:"
        echo "  i3launcher.apk    Z12 桌面     com.xtc.i3launcher        14.6.00 Ver7.1"
        echo "  sidebar_ai.apk    侧边栏AI     com.xtc.vassistant        1.8.50"
        echo "  ai_screen.apk     AI识屏       com.xtc.intelligentIdentify  6.5.50"
      } > "$EXPORT/安装说明.txt" 2>/dev/null
      log "  安装包已导出到 内部存储/StarOS/"
    fi
  else
    log "组件安装: 全部成功"
  fi

  # 只有全部成功才打完成标记;有失败的下次开机会再试一遍
  [ -z "$FAILED" ] && touch "$DONE"
}

if [ "$ASSETS_MODE" = "online" ] && [ "$ASSETS_MISSING" = "1" ]; then
  # 资源都没下到,payload 目录还是空的,这里必然装不出东西。
  # 交给上面 3.5 的后台任务:它下载成功后会自己调用 install_payload。
  log "组件安装: 跳过 —— 在线版资源包尚未就绪(下载完成后会自动补装)"
else
  install_payload
fi

# ==========================================================================
#  8. 欢迎页 —— 见本文档第 0 节
#
#  欢迎页的拉起【不在这里】。它在开机最早期就被 welcome_launch.sh
#  以独立会话并发跑起来了,这样才不会被上面 1~7 步拖后十几秒。
#
#  旧写法(1.4.1fix2 及更早)是:在这里直接读应用私有目录
#  /data/data/com.staros.app/shared_prefs/staros.xml 判断弹过没有,
#  再 am start 拉起 WelcomeActivity。两个问题:
#    1. 位置太靠后 —— 前面还压着 sleep 20 观察期和安装三个 APK;
#    2. 职责错位 —— 该不该弹是应用自己的事,脚本不该去读人家私有目录。
#  现在判断权交回应用(无窗口的 GateActivity),脚本只负责「尽快踢一脚」。
# ==========================================================================

exit 0
