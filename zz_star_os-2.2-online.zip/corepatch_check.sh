#!/system/bin/sh
# ==========================================================================
#  核心破解 (CorePatch) 安装 / 激活 检测
#
#  本文件不被单独执行,而是由 customize.sh(刷入时)和 service.sh(开机后)
#  共同 source,因此这里不写 set -e 之类会污染调用方状态的东西,
#  变量一律用 _cp_ / CP_ 前缀,避免和调用方的变量撞名。
#
#  ── 为什么本模块需要核心破解 ──
#  payload/ 里的 Z12 桌面、侧边栏、AI识屏 都是「Develop 开发签名」的包。
#  设备上如果已有正式签名的同名应用(包管理器只比包名,不比版本),
#  安装就会返回 INSTALL_FAILED_UPDATE_INCOMPATIBLE / "signatures do not match"。
#  核心破解是 LSPosed 模块,作用域勾「系统框架」后禁用 PMS 的签名校验,
#  才能覆盖安装签名不同的同名应用。
#
#  ── 已知包名 ──
#    com.coderstory.toolkit   原版「核心破解」(Android 4.4~12,本机 8.1 适用)
#    org.lsposed.corepatch    新版 Core Patch N(要求 Android 9+,本机装了也不生效)
#    com.tsng.hook.xp         同系列历史包名,一并兜住
#  自编译 / 改名版可能用别的包名,届时往 cp_pkgs 里加一个即可。
#
#  ── 怎么判断「已激活」(按证据强弱排) ──
#  证据 1 · 实证:模块被加载进 system_server,/proc/<pid>/maps 里能看到它。
#          最硬,但**经常看不到** —— LSPosed 1.8+ 把模块的 dex 读成匿名内存
#          (memfd)再加载,进程 maps 里没有带包名的路径。所以这条只能当
#          "命中就是铁证",不能当"没命中就是没激活"。
#  证据 2 · 配置:LSPosed 的模块配置里有这个包名(用户已在框架里启用它)。
#          1.9.x 的路径是 /data/adb/lspd/config/modules_config.db(及 -wal);
#          不同版本文件名不一样,所以最后还会在整个 config 目录里搜一遍。
#          证据 2 命中 -> 判已激活(证据里注明是配置层面确认)。
#  证据 3 · EdXposed 的 enabled_modules.list 里有它。
#
#  ⚠ 老版本这里只认证据 1,而且证据 1 不中就**直接**判"未激活"——
#    结果 LSPosed 1.9.2 + 核心破解 3.5.3 明明启用了、作用域也勾了系统框架,
#    刷模块时还是提示"请激活核心破解"。现在改成:证据 1 不中就继续往下找,
#    三条都没有才说"未激活"。宁可不报警,也不要乱报警。
#
#  ── cp_probe 返回码 ──
#    0 = 已安装且已激活生效
#    1 = 已安装但未激活(含框架缺失)
#    2 = 未安装
#    3 = 无法确认
#  探测结论同时放在:CP_RC / CP_PKG / CP_FW / CP_EVIDENCE
# ==========================================================================

cp_pkgs="com.coderstory.toolkit org.lsposed.corepatch com.tsng.hook.xp"

# 下面这些路径留了覆盖口子,是为了能在电脑上用桩跑测试 —— 真机上就是默认值。
CP_PROC=${CP_PROC:-/proc}
CP_LSPD=${CP_LSPD:-/data/adb/lspd}
CP_EDXP=${CP_EDXP:-/data/adb/edxp}
CP_MODULES=${CP_MODULES:-/data/adb/modules}
CP_INSTALL_DIRS=${CP_INSTALL_DIRS:-"/data/app /data/app-private /system/app /system/priv-app"}

CP_RC=3
CP_PKG=""
CP_FW=""
CP_EVIDENCE=""

# --------------------------------------------------------------------------
#  包是否已安装
#  不依赖 pm:customize.sh 在 recovery 里跑时 Android 没起来,pm 不可用。
# --------------------------------------------------------------------------
cp_pkg_installed() {
  _cp_p="$1"
  [ -z "$_cp_p" ] && return 1

  # 1) 系统起来后用 pm 最准(能认出各种安装位置)
  if [ -x "${PM:-/system/bin/pm}" ]; then
    "${PM:-/system/bin/pm}" path "$_cp_p" >/dev/null 2>&1 && return 0
  fi

  # 2) 直接看安装目录(recovery / 早期启动时的兜底)
  for _cp_d in $CP_INSTALL_DIRS; do
    [ -d "$_cp_d" ] || continue
    ls -d "$_cp_d"/*"$_cp_p"* 2>/dev/null | grep -q . && return 0
    # 3) 新版本 Android 的 /data/app/~~xxx==/com.xxx-yyy==/ 两级目录结构
    find "$_cp_d" -maxdepth 2 -name "$_cp_p*" 2>/dev/null | grep -q . && return 0
  done

  return 1
}

# --------------------------------------------------------------------------
#  框架检测:LSPosed / EdXposed 任一在位即可(hook 框架是核心破解的前提)
# --------------------------------------------------------------------------
cp_framework() {
  [ -d "$CP_LSPD" ] && { echo "LSPosed"; return 0; }
  [ -d "$CP_EDXP" ] && { echo "EdXposed"; return 0; }
  [ -f "$CP_EDXP/enabled_modules.list" ] && { echo "EdXposed"; return 0; }
  [ -d "$CP_MODULES/../riru/modules/lsposed" ] && { echo "LSPosed"; return 0; }

  _cp_f=""
  for _cp_m in "$CP_MODULES"/*; do
    [ -e "$_cp_m" ] || continue
    case "$(basename "$_cp_m")" in
      *lsposed*|*LSPosed*|*LSPOSED*) _cp_f="LSPosed"; break ;;
      *edxposed*|*EdXposed*)          _cp_f="EdXposed"; break ;;
    esac
  done
  [ -n "$_cp_f" ] && { echo "$_cp_f"; return 0; }

  return 1
}

# --------------------------------------------------------------------------
#  system_server 的 PID
#  ⚠ 别用 awk —— Android 8.1 上没有 awk,取不到 PID 会一路退化成"无法确认"。
#    toybox 的 ps -A 是 "第一列 NAME/USER 第二列 PID" 的格式,用 sed 取第二列。
# --------------------------------------------------------------------------
cp_pid_of_system_server() {
  [ -n "${CP_PID_OVERRIDE:-}" ] && { echo "$CP_PID_OVERRIDE"; return 0; }
  _cpp=$(pidof system_server 2>/dev/null | tr ' ' '\n' | grep -E '^[0-9]+$' | head -n 1)
  if [ -z "$_cpp" ]; then
    _cpp=$(ps -A 2>/dev/null | grep -w system_server \
             | sed -n 's/^[^ 	][^ 	]*[ 	][ 	]*\([0-9][0-9]*\).*$/\1/p' | head -n 1)
  fi
  echo "$_cpp"
}

# --------------------------------------------------------------------------
#  是否真的激活生效
#  返回 0=已生效  1=没生效  3=无法确认
#  证据强弱见文件头的说明。
# --------------------------------------------------------------------------
cp_activated() {
  _cpa_p="$1"
  [ -z "$_cpa_p" ] && return 1
  CP_EVIDENCE=""

  # ---- 证据 1:模块被加载进 system_server(maps 里有包名) ----
  _cp_pid=$(cp_pid_of_system_server)
  _cp_maps_readable=0
  if [ -n "$_cp_pid" ] && [ -r "$CP_PROC/$_cp_pid/maps" ]; then
    _cp_maps_readable=1
    if grep -q "$_cpa_p" "$CP_PROC/$_cp_pid/maps" 2>/dev/null; then
      CP_EVIDENCE="system_server 已加载该模块(实证生效)"
      return 0
    fi
  fi

  # ---- 证据 2:LSPosed 配置里有这个模块 ----
  # (证据 1 没命中**不代表**没激活:LSPosed 1.8+ 用匿名内存加载模块,
  #  maps 里看不到包名是正常现象,所以这里必须继续查,不能直接判死)
  for _cp_db in "$CP_LSPD/config/modules_config.db" "$CP_LSPD/config/modules.db"; do
    [ -f "$_cp_db" ] || continue
    if grep -q "$_cpa_p" "$_cp_db" 2>/dev/null || grep -q "$_cpa_p" "$_cp_db-wal" 2>/dev/null; then
      if [ "$_cp_maps_readable" = "1" ]; then
        CP_EVIDENCE="框架配置里已启用(maps 未见路径:新版 LSPosed 走匿名内存加载,属正常)"
      else
        CP_EVIDENCE="框架配置里有该模块记录(配置层面确认)"
      fi
      return 0
    fi
  done
  # 不同版本的库文件名不一样,兜底把整个 config 目录搜一遍
  if [ -d "$CP_LSPD/config" ] && grep -rlq "$_cpa_p" "$CP_LSPD/config" 2>/dev/null; then
    CP_EVIDENCE="框架配置目录里有该模块记录(配置层面确认)"
    return 0
  fi

  # ---- 证据 3:EdXposed 启用列表 ----
  if [ -f "$CP_EDXP/enabled_modules.list" ] && \
     grep -q "$_cpa_p" "$CP_EDXP/enabled_modules.list" 2>/dev/null; then
    CP_EVIDENCE="EdXposed 启用列表里有该模块"
    return 0
  fi

  # ---- 三条都没有,才敢说没激活 ----
  if [ "$_cp_maps_readable" = "1" ]; then
    CP_EVIDENCE="框架里没有这个模块 —— 可能没启用,或作用域没勾「系统框架」,或刚勾选还没重启系统框架"
    return 1
  fi
  CP_EVIDENCE="读不到 system_server 进程信息,也没有框架配置记录"
  return 3
}

# --------------------------------------------------------------------------
#  总入口:探测并把结论放进 CP_* 变量,同时返回同样的状态码
# --------------------------------------------------------------------------
cp_probe() {
  CP_RC=3; CP_PKG=""; CP_FW=""; CP_EVIDENCE=""

  for _cp_c in $cp_pkgs; do
    if cp_pkg_installed "$_cp_c"; then
      CP_PKG="$_cp_c"
      break
    fi
  done
  if [ -z "$CP_PKG" ]; then
    CP_RC=2
    return 2
  fi

  CP_FW=$(cp_framework 2>/dev/null)

  cp_activated "$CP_PKG"
  _cp_r=$?
  case "$_cp_r" in
    0) CP_RC=0; return 0 ;;
    1) CP_RC=1; return 1 ;;
    *) CP_RC=3; return 3 ;;
  esac
}

# --------------------------------------------------------------------------
#  结论行(供调用方往日志 / 界面里输出)
#  带上证据 —— 出问题时一眼能看出是"真没激活"还是"读不到信息"。
# --------------------------------------------------------------------------
cp_status_line() {
  case "$CP_RC" in
    0) echo "核心破解: 已激活${CP_FW:+ [$CP_FW] }($CP_PKG)${CP_EVIDENCE:+ —— $CP_EVIDENCE}" ;;
    1) echo "核心破解: 已安装($CP_PKG)但【未生效】${CP_EVIDENCE:+ —— $CP_EVIDENCE}" ;;
    2) echo "核心破解: 未安装" ;;
    *) echo "核心破解: 状态无法确认${CP_EVIDENCE:+ —— $CP_EVIDENCE}" ;;
  esac
}

# --------------------------------------------------------------------------
#  「请激活核心破解」提示块
#  按需求:只要没激活就写出这句;并把原因、步骤、当前状态一起给出。
# --------------------------------------------------------------------------
cp_hint() {
  echo "请激活核心破解"
  echo "原因: 随模块安装的 Z12 桌面 / 侧边栏 / AI识屏 都是开发签名(Develop)的包,"
  echo "      设备上若已有正式签名的同名应用,没有核心破解会安装失败。"
  echo "步骤: 1) 确认已安装 LSPosed 框架并重启过一次"
  echo "      2) 打开 LSPosed -> 模块 -> 核心破解,打开开关"
  echo "      3) 作用域勾选「系统框架」(android) —— 这一步最关键"
  echo "      4) 重启手表,本模块下次开机时会自动复检"
  case "$CP_RC" in
    1) echo "当前: 已安装($CP_PKG)但未激活${CP_EVIDENCE:+ —— $CP_EVIDENCE}" ;;
    2) echo "当前: 未检测到核心破解${CP_FW:+ (框架 $CP_FW 在位)}" ;;
    *) echo "当前: 无法确认${CP_EVIDENCE:+ —— $CP_EVIDENCE}" ;;
  esac
}
