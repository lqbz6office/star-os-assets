#!/system/bin/sh
# ============================================================================
#  Star OS · 星盾 (shield.sh)   —— Pro+ / 终身版专属
#  ===========================================================
#  统一工具协议见 tools/power.sh 开头。
#
#  干的事:把不想被人翻的应用"冻结"起来 —— 冻结后它在桌面消失、也起不来,
#        要用时在这里解冻即可。相当于给手表上了把抽屉锁。
#
#  为什么用"冻结"而不是"要密码的应用锁":
#    应用锁需要在应用启动的瞬间把它拦下来(盯着窗口焦点轮询 + 弹自己的锁屏),
#    这种做法在手表上又费电又容易被滑过去(息屏、分屏、直接跳转都可能绕过),
#    而且一旦自己那个锁屏 Activity 崩了,用户就被锁在外面 —— 风险全给用户了。
#    冻结是系统自己的能力:桌面上根本看不到,谁也起不来,没有绕过一说。
#
#  真值来源:pm 自己的状态(pm list packages -d),不另存一份清单 ——
#  避免"清单说冻结了但系统没冻"这种对不上的情况。
# ============================================================================

PWDIR=${0%/*}
[ -d "$PWDIR" ] || PWDIR=/data/adb/modules/zz_star_os
STAR=${STAR_DIR:-/data/adb/star_os}
LOG=$STAR/logs/shield.log

mkdir -p "$STAR/logs" 2>/dev/null

sh_log() { echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$LOG" 2>/dev/null; }

# 本地闸门(真值在台账,由应用联网核对后写入 pro.conf)
sh_tier() {
  shg_v=0
  if [ -f "$STAR/pro.conf" ]; then
    shg_v=$(sed -n 's/^tier=//p' "$STAR/pro.conf" 2>/dev/null | head -n 1)
  fi
  case "$shg_v" in
    ''|*[!0-9]*) echo 0 ;;
    *) echo "$shg_v" ;;
  esac
}

sh_gate() {
  [ "$(sh_tier)" -ge 2 ] && return 0
  echo "星盾是 Pro+ / 终身版功能,当前等级不够" >&2
  return 5
}

# 常见应用的友好名 —— 手表上认名字比认包名快得多
sh_friendly() {
  case "$1" in
    com.tencent.mm) echo "微信" ;;
    com.tencent.mobileqq) echo "QQ" ;;
    com.tencent.mobileqqi) echo "QQ(国际)" ;;
    com.eg.android.AlipayGphone) echo "支付宝" ;;
    com.ss.android.ugc.aweme) echo "抖音" ;;
    com.xtc.watch) echo "小天才" ;;
    com.xtc.*) echo "小天才组件" ;;
    com.netease.*) echo "网易系" ;;
    com.tencent.tmgp.*) echo "腾讯游戏" ;;
    com.tencent.qqlive*) echo "腾讯视频" ;;
    com.youku.phone) echo "优酷" ;;
    com.taobao.taobao) echo "淘宝" ;;
    com.achievo.vipshop) echo "唯品会" ;;
    tv.danmaku.bili) echo "哔哩哔哩" ;;
    com.tencent.qqmusic) echo "QQ音乐" ;;
    com.kugou.android) echo "酷狗" ;;
    com.ximalaya.ting.android) echo "喜马拉雅" ;;
    *) echo "$1" ;;
  esac
}

# 该包现在冻结了没(1=冻结)
sh_is_frozen() {
  pm list packages -d -3 2>/dev/null | grep -q "^package:$1$" && echo 1 || echo 0
}

sh_frozen_list() {
  pm list packages -d -3 2>/dev/null | sed -n 's/^package://p' | sort
}

sh_third_list() {
  pm list packages -3 2>/dev/null | sed -n 's/^package://p' | sort
}

sh_status() {
  shf_l=$(sh_frozen_list)
  if [ -z "$shf_l" ]; then
    echo "已保护:还没有"
    echo ""
    echo "下面「挑应用加锁」进去,勾选想藏起来的应用。"
    echo "冻结后它在桌面直接消失,要用时在这里解冻。"
  else
    echo "已保护 ($(echo "$shf_l" | grep -c .) 个):"
    echo "$shf_l" | while read -r shs_p; do
      [ -z "$shs_p" ] && continue
      echo "@item|$(sh_friendly "$shs_p") · 解冻|act|unfreeze:$shs_p"
    done
  fi
  echo ""
  echo "@item|挑应用加锁(冻结)|act|pick"
  return 0
}

case "$1" in
  meta)
    echo "shield|星盾|把不想被人翻的应用冻结藏起来|2|pick:挑应用加锁:pri,list:已保护:ghost"
    ;;
  status)
    sh_gate || exit 5
    sh_status
    ;;
  act)
    sh_gate || exit 5
    case "$2" in
      pick)
        echo "点一个应用把它冻起来(在桌面会立刻消失)"
        echo "再点一次同一行可以取消(如果它已经在「已保护」里)。"
        echo ""
        sh_third_list | while read -r shp_p; do
          [ -z "$shp_p" ] && continue
          if [ "$(sh_is_frozen "$shp_p")" = "1" ]; then
            echo "@item|[已锁] $(sh_friendly "$shp_p")|act|unfreeze:$shp_p"
          else
            echo "@item|$(sh_friendly "$shp_p")|act|freeze:$shp_p"
          fi
        done
        ;;
      list)
        shf_l=$(sh_frozen_list)
        if [ -z "$shf_l" ]; then
          echo "(空)"
        else
          echo "$shf_l"
        fi
        ;;
      freeze)
        [ -z "$3" ] && { echo "缺少包名" >&2; exit 2; }
        # 兜底:别把桌面/系统框架冻了,那会直接变砖
        case "$3" in
          com.android.*|android|com.xtc.watch|com.staros.*) 
            echo "这个应用不能冻结(冻了手表可能起不来)" >&2
            exit 3 ;;
        esac
        if pm disable-user --user 0 "$3" >/dev/null 2>&1; then
          # ⚠ 绝不要顺手 pm clear —— 那是删数据,不是"藏起来"。
          #   冻结的语义是"桌面看不到、起不来,解冻后一切如常"。
          echo "已冻结:$(sh_friendly "$3")"
          echo "它已从桌面消失。想用的时候在这里解冻即可,数据还在。"
          sh_log "freeze $3"
        else
          echo "冻结失败:$3(可能它不允许被禁用)" >&2
          exit 1
        fi
        ;;
      unfreeze)
        [ -z "$3" ] && { echo "缺少包名" >&2; exit 2; }
        if pm enable "$3" >/dev/null 2>&1; then
          echo "已解冻:$(sh_friendly "$3")"
          echo "它已经回到桌面了。"
          sh_log "unfreeze $3"
        else
          echo "解冻失败:$3" >&2
          exit 1
        fi
        ;;
      *)
        echo "未知动作:$2" >&2
        exit 2
        ;;
    esac
    ;;
  *)
    echo "用法:$0 {meta|status|act <动作> [参数]}" >&2
    exit 2
    ;;
esac
