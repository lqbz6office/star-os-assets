#!/system/bin/sh
# ============================================================================
#  Star OS · 星感 (sensor.sh)   —— Pro+ / 终身版专属
#  ===========================================================
#  统一工具协议见 tools/power.sh 开头。
#
#  干的事:把这块表身上的传感器摊开给你看 —— 有哪些、现在读数是多少,
#        还能把手速/姿态/心率这类读数采样成一份 CSV(存存储卡,能导出去)。
#
#  数据来源:系统自带的 dumpsys sensorservice(只读,不改任何东西)。
#  说明:不同批次的 4100 传感器不一样(有的带心率有的不带),
#       所以这里不做死假设 —— 机器上报什么就列什么。
# ============================================================================

PWDIR=${0%/*}
[ -d "$PWDIR" ] || PWDIR=/data/adb/modules/zz_star_os
STAR=${STAR_DIR:-/data/adb/star_os}
SE=$STAR/sensor
LOG=$STAR/logs/sensor.log
SE_OUT=${SENSOR_OUT_DIR:-/sdcard/StarOS/采样}

mkdir -p "$SE" "$STAR/logs" 2>/dev/null

se_log() { echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$LOG" 2>/dev/null; }

se_tier() {
  seg_v=0
  if [ -f "$STAR/pro.conf" ]; then
    seg_v=$(sed -n 's/^tier=//p' "$STAR/pro.conf" 2>/dev/null | head -n 1)
  fi
  case "$seg_v" in
    ''|*[!0-9]*) echo 0 ;;
    *) echo "$seg_v" ;;
  esac
}

se_gate() {
  [ "$(se_tier)" -ge 2 ] && return 0
  echo "星感是 Pro+ / 终身版功能,当前等级不够" >&2
  return 5
}

se_dump() { dumpsys sensorservice 2>/dev/null; }

# 传感器清单:每行形如 "0x00000000) ACCELEROMETER(1) ..." —— 取括号前的名字
se_list() {
  sel_raw=$(se_dump | grep -E "^0x[0-9a-fA-F]+\)")
  if [ -z "$sel_raw" ]; then
    echo "(没读到传感器列表)"
    return 0
  fi
  echo "$sel_raw" | head -n 16 | while read -r sel_l; do
    sel_n=$(echo "$sel_l" | sed 's/^0x[0-9a-fA-F]*) *//' | cut -d'(' -f1 | cut -d' ' -f1)
    [ -n "$sel_n" ] && echo "  $sel_n"
  done
}

# 最近事件:系统会缓存每个传感器最后几次读数,原样截一段出来
se_events() {
  see_raw=$(se_dump | sed -n '/Recent Sensor events/,$p' | sed -n '2,14p')
  if [ -z "$see_raw" ]; then
    echo "(暂时没有事件。传感器要有人读它才出数,摇一摇表再试。)"
    return 0
  fi
  echo "$see_raw" | while read -r see_l; do
    [ -z "$see_l" ] && continue
    echo "  $see_l"
  done
}

# ---------------------------------------------------------------- 采样
# 一段时间的读数存成 CSV(时间戳 + 事件原文),拿来分析或给学生看都行
se_record() {
  mkdir -p "$SE_OUT" 2>/dev/null
  ser_f="$SE_OUT/sensor-$(date '+%Y%m%d-%H%M%S').csv"
  echo "ts,event" > "$ser_f"
  ser_i=0
  ser_n=10
  echo "开始采样($ser_n 次,每次隔 1 秒),采样时最好摇一摇或戴在手上…"
  while [ "$ser_i" -lt "$ser_n" ]; do
    ser_t=$(date '+%s')
    ser_v=$(se_dump | sed -n '/Recent Sensor events/,$p' | sed -n '2p' | sed 's/,/;/g')
    echo "$ser_t,$ser_v" >> "$ser_f"
    ser_i=$((ser_i + 1))
    sleep 1
  done
  se_log "record $ser_f"
  echo "已存:$ser_f"
  echo "($(grep -c . "$ser_f" 2>/dev/null) 行,含表头)"
}

se_status() {
  echo "传感器清单:"
  se_list
  echo ""
  echo "当前读数(最近事件):"
  se_events
  echo ""
  echo "@item|刷新读数|act|scan"
  echo "@item|采样 10 秒存成 CSV|act|record"
  return 0
}

case "$1" in
  meta)
    echo "sensor|星感|看清表上的传感器和实时读数,可采样导出|2|scan:刷新读数:pri,record:采样导出:ghost"
    ;;
  status)
    se_gate || exit 5
    se_status
    ;;
  act)
    se_gate || exit 5
    case "$2" in
      scan) se_status ;;
      record) se_record ;;
      *)
        echo "未知动作:$2" >&2
        exit 2
        ;;
    esac
    ;;
  *)
    echo "用法:$0 {meta|status|act <动作>}" >&2
    exit 2
    ;;
esac
