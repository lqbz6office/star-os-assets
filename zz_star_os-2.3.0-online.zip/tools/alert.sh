#!/system/bin/sh
# ============================================================================
#  Star OS · 星哨 (alert.sh)   —— Pro+ / 终身版专属
#  ===========================================================
#  统一工具协议见 tools/power.sh 开头。
#
#  干的事:替你盯着三个数 —— 电量、温度、存储。谁越过线就记一笔(并尽量
#        发一条通知),不用人自己反复去看。
#        · 电量掉到阈值以下 → 提醒充电(避免"一觉醒来关机了")
#        · 温度超过阈值     → 提醒歇一会儿(边充边玩容易烫)
#        · 存储超过阈值     → 提醒清理(满了啥都干不了)
#
#  阈值都能自己调,默认:电量 20% / 温度 42℃ / 存储 90%。
# ============================================================================

PWDIR=${0%/*}
[ -d "$PWDIR" ] || PWDIR=/data/adb/modules/zz_star_os/tools
MODD=${PWDIR%/*}
[ -d "$MODD" ] || MODD=/data/adb/modules/zz_star_os
STAR=${STAR_DIR:-/data/adb/star_os}
AL=$STAR/alert
LOG=$STAR/logs/alert.log
CONF=$AL/conf
RECENT=$AL/recent.log

mkdir -p "$AL" "$STAR/logs" 2>/dev/null

al_log() { echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$LOG" 2>/dev/null; }

al_conf_init() {
  [ -f "$CONF" ] && return 0
  true > "$CONF"
  echo "lowbat=20" >> "$CONF"
  echo "temp=42" >> "$CONF"
  echo "disk=90" >> "$CONF"
}

al_cfg() { sed -n "s/^$1=//p" "$CONF" 2>/dev/null | head -n 1; }

al_cfg_set() {
  alcs_k=$1
  alcs_v=$2
  true > "$CONF.tmp"
  alcs_hit=0
  while read -r alcs_l; do
    [ -z "$alcs_l" ] && continue
    case "$alcs_l" in
      "$alcs_k"=*) echo "$alcs_k=$alcs_v" >> "$CONF.tmp"; alcs_hit=1 ;;
      *) echo "$alcs_l" >> "$CONF.tmp" ;;
    esac
  done < "$CONF"
  [ "$alcs_hit" = "0" ] && echo "$alcs_k=$alcs_v" >> "$CONF.tmp"
  mv "$CONF.tmp" "$CONF" 2>/dev/null
}

# ---------------------------------------------------------------- 读数
al_battery() {
  alb_l=$(dumpsys battery 2>/dev/null | sed -n 's/.*level: \([0-9][0-9]*\).*/\1/p' | head -n 1)
  case "$alb_l" in ''|*[!0-9]*) echo -1 ;; *) echo "$alb_l" ;; esac
}

al_temp() {
  # temperature 是"摄氏度×10"的整数
  alt_t=$(dumpsys battery 2>/dev/null | sed -n 's/.*temperature: \([0-9-][0-9]*\).*/\1/p' | head -n 1)
  case "$alt_t" in ''|*[!0-9-]*) echo -1 ;; *) echo "$alt_t" ;; esac
}

# 返回内部存储使用率(整数百分比),取不到给 -1
al_disk_pct() {
  ald_l=$(df -k -P /data 2>/dev/null | sed -n '2p')
  [ -z "$ald_l" ] && ald_l=$(df -k /data 2>/dev/null | sed -n '2p')
  ald_tot=$(echo "$ald_l" | sed -n 's/^[^ 	][^ 	]*[ 	][ 	]*\([0-9][0-9]*\).*/\1/p')
  ald_av=$(echo "$ald_l" | sed -n 's/^[^ 	][^ 	]*[ 	][ 	]*[0-9][0-9]*[ 	][ 	]*[0-9][0-9]*[ 	][ 	]*\([0-9][0-9]*\).*/\1/p')
  case "$ald_tot" in ''|*[!0-9]*) echo -1; return 0 ;; esac
  case "$ald_av" in ''|*[!0-9]*) echo -1; return 0 ;; esac
  [ "$ald_tot" -le 0 ] && { echo -1; return 0; }
  echo $(( (ald_tot - ald_av) * 100 / ald_tot ))
}

al_temp_c() {  # "320" -> "32.0";读不到(-1 等)给 "?"
  altc=$1
  case "$altc" in ''|*[!0-9]*) echo "?" ; return 0 ;; esac
  echo "$((altc / 10)).$((altc % 10))"
}

# 尽量发通知(8.1 上不一定支持,发不出去也不影响记录)
al_notify() {
  if command -v cmd >/dev/null 2>&1; then
    cmd notification post -S bigtext -t "Star OS 星哨" "staros_alert" "$1" >/dev/null 2>&1
  fi
}

al_record() {  # $1=内容
  echo "$(date '+%m-%d %H:%M') $1" >> "$RECENT" 2>/dev/null
  # 只留最近 20 条
  alr_n=$(wc -l < "$RECENT" 2>/dev/null)
  case "$alr_n" in ''|*[!0-9]*) alr_n=0 ;; esac
  if [ "$alr_n" -gt 20 ]; then
    tail -n 20 "$RECENT" > "$RECENT.tmp" 2>/dev/null && mv "$RECENT.tmp" "$RECENT" 2>/dev/null
  fi
  al_log "ALERT: $1"
  al_notify "$1"
}

# ---------------------------------------------------------------- 检查
al_check() {
  al_conf_init
  alc_hits=0
  alc_b=$(al_battery)
  alc_t=$(al_temp)
  alc_d=$(al_disk_pct)
  alc_bl=$(al_cfg lowbat)
  alc_tl=$(al_cfg temp)
  alc_dl=$(al_cfg disk)

  if [ "$alc_b" -ge 0 ] && [ "$alc_bl" -ge 0 ] && [ "$alc_b" -le "$alc_bl" ]; then
    al_record "电量低:${alc_b}%(阈值 ${alc_bl}%)"
    alc_hits=$((alc_hits + 1))
  fi
  if [ "$alc_t" -ge 0 ] && [ "$alc_tl" -ge 0 ] && [ "$alc_t" -ge $((alc_tl * 10)) ]; then
    al_record "温度高:$(al_temp_c "$alc_t")℃(阈值 ${alc_tl}℃)"
    alc_hits=$((alc_hits + 1))
  fi
  if [ "$alc_d" -ge 0 ] && [ "$alc_dl" -ge 0 ] && [ "$alc_d" -ge "$alc_dl" ]; then
    al_record "存储满:${alc_d}%(阈值 ${alc_dl}%)"
    alc_hits=$((alc_hits + 1))
  fi
  echo "$alc_hits"
}

# ---------------------------------------------------------------- 状态
al_status() {
  al_conf_init
  alb=$(al_battery)
  alt=$(al_temp)
  ald=$(al_disk_pct)
  echo "电量:${alb}%   温度:$(al_temp_c "$alt")℃   内部存储已用:${ald}%"
  echo "阈值:电量 ≤ $(al_cfg lowbat)%  温度 ≥ $(al_cfg temp)℃  存储 ≥ $(al_cfg disk)%"
  echo ""
  echo "最近告警:"
  if [ -s "$RECENT" ]; then
    tail -n 5 "$RECENT" | sed 's/^/  /'
  else
    echo "  (还没有)"
  fi
  echo ""
  echo "@item|立刻检查一次|act|test"
  echo "@item|调低电量阈值(-5%)|act|lowbat-"
  echo "@item|调高电量阈值(+5%)|act|lowbat+"
  echo "@item|调高温度阈值(+1℃)|act|temp+"
  echo "@item|清空告警记录|act|clear"
  return 0
}

al_tune() {  # $1=key $2=delta $3=min $4=max
  altk=$1
  altc=$(al_cfg "$altk")
  case "$altc" in ''|*[!0-9]*) altc=0 ;; esac
  altn=$((altc + $2))
  [ "$altn" -lt "$3" ] && altn=$3
  [ "$altn" -gt "$4" ] && altn=$4
  al_cfg_set "$altk" "$altn"
  echo "$altk:$altc -> $altn"
}

case "$1" in
  meta)
    echo "alert|星哨|电量/温度/存储越线就提醒,阈值自己调|2|test:检查一次:pri,lowbat-:电量-:ghost,lowbat+:电量+:ghost,temp+:温度+:ghost,clear:清记录:ghost"
    ;;
  status)
    al_status
    ;;
  act)
    case "$2" in
      test)
        aln=$(al_check)
        if [ "$aln" = "0" ]; then
          echo "一切正常:电量/温度/存储都没越线"
        else
          echo "触发 $aln 条告警(已记录)"
        fi
        ;;
      lowbat-) al_tune lowbat -5 5 80 ;;
      lowbat+) al_tune lowbat 5 5 80 ;;
      temp+)   al_tune temp 1 30 60 ;;
      clear)
        true > "$RECENT"
        echo "告警记录已清空"
        ;;
      *)
        echo "未知动作:$2" >&2
        exit 2
        ;;
    esac
    ;;
  tick)
    al_check >/dev/null 2>&1
    ;;
  daemon)
    al_log "星哨 daemon 启动 (pid=$$)"
    while true; do
      "$0" tick >/dev/null 2>&1
      sleep 300
    done
    ;;
  *)
    echo "用法:$0 {meta|status|act <动作>|tick|daemon}" >&2
    exit 2
    ;;
esac
