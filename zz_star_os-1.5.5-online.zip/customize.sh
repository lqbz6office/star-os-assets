#!/system/bin/sh
##########################################################################
# customize.sh —— 安装脚本,只在"刷入模块"那一刻执行一次
#
# 可用变量：
#   MODPATH   模块被解压到的临时目录(安装完成后再搬到 /data/adb/modules/<id>)
#   TMPDIR    临时目录
#   ZIPFILE   模块 zip 的路径
#   API       SDK 版本,例如 Android 14 = 34
#   ARCH      arm64 / arm / x86_64 / x86 ...
#   IS64BIT   true / false
#   BOOTMODE  true 表示在 Magisk 应用里安装(非 recovery)
#
# 可用函数(Magisk 注入)：
#   ui_print "文字"                        打印到刷入日志
#   abort "! 出错了"                       中断安装并报错
#   set_perm <文件> <uid> <gid> <mode>
#   set_perm_recursive <目录> <uid> <gid> <目录mode> <文件mode>
#   grep_prop <键> <文件>                   读取 prop 值
##########################################################################

# 0 = Magisk 先把 zip 全部解压到 $MODPATH,再执行本脚本(默认,推荐)
# 1 = 不解压,由你自己在这里解压(只有做特殊处理时才用)
SKIPUNZIP=0

# ==========================================================================
#  品牌字符画(ASCII Banner)
#  * 每行都用【单引号】包裹 —— 单引号内不做任何转义,
#    字符画里的 \ / _ | 才能原样输出,不用写成 \\  \\_ 这种鬼东西。
#  * 宽度控制在 40 列以内,保证在 TWRP 终端和 Magisk 应用日志里都不折行。
#  * 想换图形,直接用在线 figlet 生成器出图,再把每行贴进来即可。
# ==========================================================================
ui_print ' '
ui_print '  ____ _____  _    ____     ___  ____  '
ui_print ' / ___|_   _|/ \  |  _ \   / _ \/ ___| '
ui_print ' \___ \ | | / _ \ | |_) | | | | \___ \ '
ui_print '  ___) || |/ ___ \|  _ <  | |_| |___) |'
ui_print ' |____/ |_/_/   \_\_| \_\  \___/|____/ '
ui_print ' '
ui_print '       >>  1.5  <<'
ui_print ' '
ui_print '    让你的4100变成z12'
ui_print '         by  星'
ui_print ' '
ui_print '----------------------------------------'
ui_print ' '

# ---------- 1. 机型校验 ----------
# 只支持一个机型:
#   4100 -> SDK 27 (Android 8.1.x)  完整支持
#
# 5100(SDK 30)支持在 1.4 加过,1.5 已【移除】。理由:实测问题太多
# (字体加载不出来、开机动画与系统组件行为不一致、开机自检多处误判),
# 修不干净 —— 与其放着半残的兼容不如明确不支持,免得刷上去变成开机问题。
# 所以 SDK 30 现在直接 abort。
#
# 用字符串比较而不是 -ne,是为了 API 变量意外为空时也不会报语法错。
# SDK 不符直接 abort 中断安装,避免刷进不兼容的机器导致无法开机。
ui_print '- 正在检查机型...'
ui_print "  架构: $ARCH ($IS64BIT) | SDK: $API"
ui_print ' '

if [ "$API" != "27" ]; then
  ui_print '  [!!] 不 支 持 的 机 型 [!!]'
  ui_print ' '
  if [ "$API" = "30" ]; then
    ui_print '  检测到 5100(SDK 30)。'
    ui_print '  本模块从 1.5 起【已移除 5100 支持】:'
    ui_print '  5100 上问题较多(字体无法正常'
    ui_print '  加载、开机自检误判),暂时修不'
    ui_print '  干净,故不再支持。'
    ui_print ' '
    abort "! 1.5 起不再支持 5100(SDK 30),本模块仅支持 4100(SDK 27)"
  fi
  abort "! 本模块仅支持 4100(SDK 27),当前设备为 SDK $API"
fi

ui_print '- 机型校验通过'
ui_print '  您的设备为4100机型'
ui_print ' '

# ---------- 核心破解(CorePatch)检测 ----------
# 随模块携带的 Z12 桌面 / 侧边栏 / AI识屏 都是开发签名(Develop)的包,
# 设备上若已有正式签名的同名应用,没有核心破解就装不上(签名校验不通过)。
# 所以安装时先检查一遍,把结论直接打进刷入日志 —— 你刷的时候就能看到。
# 这里【只提示不中断】:核心破解不是刷机的前提,而且有些设备本来就没有
# 同名应用冲突,照样能装上。
if [ -f "$MODPATH/corepatch_check.sh" ]; then
  . "$MODPATH/corepatch_check.sh"

  ui_print '- 正在检查核心破解(CorePatch)...'
  cp_probe
  _cp_rc=$?
  ui_print "  $(cp_status_line)"
  if [ "$_cp_rc" -ne 0 ]; then
    ui_print ' '
    cp_hint | while read -r _cp_l; do ui_print "  $_cp_l"; done
  fi
  ui_print ' '
fi

# ---------- 取自己的模块 ID ----------
# 不写死目录名:模块 id 是 zz_star_os,刻意加了 zz_ 前缀。
# Magisk 的模块挂载顺序 = 模块 ID 的字母序,靠后的覆盖靠前的,
# 而官方并没有优先级设置项 —— 想让本模块的文件不被别的模块盖掉,
# 只能靠 ID 抢字母序。这里动态取值,以后改 id 也不用动脚本。
MODID=$(grep_prop id "$MODPATH/module.prop" 2>/dev/null)
[ -n "$MODID" ] || MODID=$(basename "$MODPATH")
ui_print "- 模块 ID: $MODID (字母序靠后 = 挂载优先级更高)"
ui_print ' '

# ---------- 旧模块冲突清理 ----------
# 1) 本模块已经把 XTC-Patch_SystemUI 的功能合并了进来。
#    如果设备上还留着那个独立模块,两个模块会同时挂载 system/priv-app/XTCSystemUI,
#    造成文件冲突。这里给旧模块打 remove 标记,Magisk 下次重启会干净地删掉它。
# 2) 模块 id 由 star_os 改成了 zz_star_os(为了抢挂载优先级)。
#    旧 id 的模块目录必须一并清掉,否则两个模块会同时挂载同一批文件,
#    而且旧模块的优先级比新的低,反而可能把我们的文件盖回去。
clean_old_module() {
  _d="/data/adb/modules/$1"
  [ -d "$_d" ] || return 0
  [ "$1" = "$MODID" ] && return 0
  ui_print "- 检测到旧模块 $1,已标记为卸载(重启后自动清除)"
  # 旧模块可能给文件加了 immutable 属性,先解锁再删
  [ -x /data/adb/magisk/busybox ] && \
    /data/adb/magisk/busybox chattr -R -i "$_d" 2>/dev/null
  rm -f "$_d/disable"
  touch "$_d/remove"
}

clean_old_module XTCPatch_SystemUI
clean_old_module star_os
# 0.1.2 Beta 起整合了三个独立增强模块,如果设备上装着它们的原版,
# 必须一并清掉 —— 否则同一个 sysfs 节点会有两拨脚本轮流写,互相打架。
clean_old_module ultra_performance        # 极致性能 v13.5
clean_old_module wear_soc_mod             # WearSoC Tweak(桌面流畅度)
clean_old_module wifi-bonding             # Wifi Bonding (Qualcomm)
ui_print ' '

# ---------- 1.5 资源包(在线版专用) ----------
# 离线全量版走到这里是空操作:资源本来就在包里(ASSETS_MODE=embedded)。
#
# 在线版则在这里把 189 MB 的大文件拉下来 ——
#   payload 三个 APK / 苹方字体 / fonts.xml / SystemUI / 主题图标 / 开机动画。
#
# 为什么下载放在刷入阶段而不是开机后:
#   Magisk 在 post-fs-data 阶段就把模块目录挂载到 /system 了,开机后(service.sh)
#   才写进去的文件要等下次重启才生效。刷入时下完,第一次开机就是完整的。
#
# 为什么下不到也不 abort:
#   在 recovery / ATB 里刷的时候是没有网络的。失败就让模块先装上(它此时只是
#   一个空壳,不影响开机),重启后由 service.sh 联网自动重试,下好了提示你重启一次。
#   这样"有网"和"没网"两种情况下都能成功,只是后者多一次重启。
# 网络可用性标记:0=未知 1=可用 2=已知不可用
# 只用来给下面的"检查更新"省时间 —— 资源包都没下动的地方,不必再等第二个地址超时。
STAR_NET=0

[ -f "$MODPATH/assets.conf" ] && . "$MODPATH/assets.conf"
if [ "$ASSETS_MODE" = "online" ]; then
  ui_print '- 在线版:正在获取资源包'
  ui_print "    ${ASSETS_NAME:-资源包}  ($(echo "${ASSETS_SIZE:-0}" | awk '{printf "%.0f MB", $1/1048576}'))"
  ui_print '    来源:GitHub(自动尝试多个加速镜像)'
  ui_print ' '
  if [ -f "$MODPATH/assets_fetch.sh" ]; then
    . "$MODPATH/assets_fetch.sh"
    af_out() { ui_print "$*"; }      # 让下载器的每一步都出现在刷入日志里
    if af_fetch "$MODPATH"; then
      ui_print ' '
      ui_print '- 资源包获取完成,首次开机即为完整功能'
    else
      STAR_NET=2
      ui_print ' '
      ui_print '! 资源包没拿到,模块仍会正常安装(此时它对系统不做任何改动)'
      ui_print '  重启后系统联网时会自动重试下载,完成后会提示你重启一次'
      ui_print '  想立刻解决,也可以自己在电脑/手机上下载资源包,'
      ui_print '  命名为 star_os_assets.zip 放到内部存储根目录再刷一次本模块。'
      mkdir -p /data/adb/star_os 2>/dev/null
      # 用 true 而不是 `:` —— `:` 是 POSIX 特殊内建命令,重定向失败会
      # 直接终止整个安装脚本(2026-10-03 被这个坑过一次)
      true > /data/adb/star_os/assets_pending 2>/dev/null
    fi
  else
    ui_print '! 缺少 assets_fetch.sh,跳过下载(资源将由开机后重试)'
  fi
  ui_print ' '
fi

# ---------- 1.6 检查更新(安装时顺手看一眼) ----------
# 和上面的资源包下载是两件完全不同的事:
#   上面解决「这一份装完之后完不完整」,
#   这里解决「你装的这一份是不是已经过时了」。
#
# 做法:拉一个几 KB 的 update.json,比对 versionCode。发现新版就在刷入日志里
# 提醒你走 Magisk 的更新通道。纯提示 —— 不会替你把新版下下来替换掉。
#
# 失败(没网 / 超时 / 清单读不出来)只打印一行说明,绝不 abort:
# 检测更新失败不该妨碍安装这件事本身。
#
# ⚠ 另一条独立的更新通道在 module.prop 的 updateJson= 字段里:
#   Magisk 应用会自己拿它做「模块页的更新按钮」(手动检测),与这段脚本无关。
#   两条路都读同一个 update.json,所以只会有一个"最新版本"的答案。
if [ -f "$MODPATH/update_check.sh" ]; then
  . "$MODPATH/update_check.sh"
  # 让检查结果进刷入界面(离线全量版里 af_out 还没被定义过,这里统一接上)
  af_out() { ui_print "$*"; }
  # 资源包刚下失败过 = 这台设备此刻没网,别再多等一个地址的超时
  if [ "$STAR_NET" = "2" ]; then
    AUC_TRIES=1
    AUC_WAIT=4
  fi
  auc_check "$MODPATH"
  ui_print ' '
fi

# ---------- 2. 系统文件替换 ----------
# 你放进 system/ 目录的东西,Magisk 会在开机时 magic mount 到 /system 对应位置。
#   举例: put  system/fonts/NotoSansCJK-Regular.ttc
#         → 设备上生效为 /system/fonts/NotoSansCJK-Regular.ttc
# 如果某个目录要被整体替换,而不是逐个文件合并,把目录名写进 REPLACE:
#
# REPLACE="
# /system/fonts
# /system/app/SomeApp
# "
#
# 注意: REPLACE 列表里的路径所在的整个目录都会被模块目录覆盖
#       (模块里没有的文件 = 设备上该文件消失),用错了会导致开机异常,慎用。

# ---------- 属性确认 ----------
# 把 system.prop 里"实际生效"的条目回显一遍(自动跳过 # 注释和空行),
# 刷入时扫一眼就知道有没有写错键名、有没有手滑漏了 #
if [ -f "$MODPATH/system.prop" ]; then
  ui_print '- 已写入系统属性:'
  grep -v '^[[:space:]]*#' "$MODPATH/system.prop" | grep '=' \
    | sed 's/^[[:space:]]*/    /' \
    | while IFS= read -r prop_line; do ui_print "$prop_line"; done
fi
ui_print ' '

# ---------- 系统应用确认 ----------
# 列出随模块一起装入 /system/app、/system/priv-app 的应用,刷入时可核对
if [ -d "$MODPATH/system/app" ] || [ -d "$MODPATH/system/priv-app" ]; then
  ui_print '- 将随模块安装的系统应用:'
  for app_dir in "$MODPATH/system/app" "$MODPATH/system/priv-app"; do
    [ -d "$app_dir" ] || continue
    for apk in "$app_dir"/*/*.apk; do
      [ -f "$apk" ] || continue
      ui_print "    [$(basename "$app_dir")] $(basename "$apk")"
    done
  done
fi
ui_print ' '

# ---------- 字体替换确认 ----------
# 模块把系统字体换成 iOS 苹方(PingFang SC)。
#
# 为什么只需要动一个 font.ttf 就能换掉全局字体:
#   设备提取件解析结果显示, /system/fonts/font.ttf 是系统真正在用的字体,
#   而 RobotoFake-*.ttf / GoogleSans-*.ttf 全都是只有 2 个字形的空壳占位文件,
#   连拉丁字母都要回退到 font.ttf 渲染 —— 全系统字体收敛在这一个文件上。
#
# 所以做法是:
#   1) 用苹方 Regular 覆盖 font.ttf (兜底: 即使 fonts.xml 没生效, 中文也已变苹方)
#   2) 附带 Light / Medium / Semibold 三个字重文件
#   3) 生成打过补丁的 system/etc/fonts.xml, 把 5 组字体族的字重指向对应文件,
#      这样粗体是真粗体, 而不是系统伪加粗
if [ -f "$MODPATH/system/fonts/font.ttf" ]; then
  ui_print '- 字体替换: iOS 苹方 PingFang SC'
  ui_print '    font.ttf                => Regular  (覆盖系统原字体)'
  ui_print '    PingFangSC-Light.ttf    => Thin / Light'
  ui_print '    PingFangSC-Medium.ttf   => Medium'
  ui_print '    PingFangSC-Semibold.ttf => Semibold / Black'
  ui_print '    已生成 system/etc/fonts.xml 字重映射表'
fi
ui_print ' '

# ---------- XTCSystemUI 安装 ----------
# 合并自 XTC-Patch_SystemUI v1.7.50 的 4100 机型包。
# 原模块用「挂载到 priv-app」+「pm install 立即注册」双保险:
#   挂载保证重启后系统扫描得到,pm install 保证刷完不用重启就生效。
# pm 在 recovery 刷入环境下不可用,所以失败也不 abort,交给重启后的系统扫描兜底。
SYS_UI_APK="$MODPATH/system/priv-app/XTCSystemUI/XTCSystemUI.apk"
if [ -f "$SYS_UI_APK" ]; then
  ui_print '- 正在安装 XTCSystemUI ...'
  pm install -r -d "$SYS_UI_APK"
  if [ $? -eq 0 ]; then
    ui_print '  XTCSystemUI 安装成功'
  else
    ui_print '  XTCSystemUI 即时安装未成功,重启后由系统扫描 priv-app 兜底'
  fi
fi
ui_print ' '

# ---------- 开机动画与音效确认 ----------
# Z12 原厂规格是 320x360、单 part0 循环(desc.txt: "320 360 5 / c 0 0 part0")。
# 1.4 起用的是 81 帧 320x360 @8fps 的星空 + 四角星生长动画(播 1 遍 + 末帧定格)。
# 帧必须 RGBA 32 位(24 位会渲染成黑屏),desc.txt 必须 LF 换行,内部必须全 STORED。
#
# 为什么写两个文件名:设备提取件里叫 bootanimation_4100.zip(带机型后缀),
# 而 Android 系统固定读取 bootanimation.zip。哪个是当前生效的没法离线确认,
# 一起覆盖最稳。(1.4~1.4.1fix2 还额外写过 bootanimation_5100.zip,
#  1.5 移除 5100 支持后已删除。)
if [ -f "$MODPATH/system/media/bootanimation.zip" ]; then
  ui_print '- 开机动画: Star OS 星轨 (320x360 / 8fps / 81帧)'
  ui_print '    system/media/bootanimation.zip        已写入'
  [ -f "$MODPATH/system/media/bootanimation_4100.zip" ] && \
    ui_print '    system/media/bootanimation_4100.zip   已写入(机型专用名)'
fi

# 音效:替换 UI 点击音,并补上原厂被禁用成空文件的相机快门与录像提示音
if [ -d "$MODPATH/system/media/audio/ui" ]; then
  ui_print '- 系统音效替换:'
  for snd in "$MODPATH/system/media/audio/ui"/*.ogg; do
    [ -f "$snd" ] || continue
    sndsz=$(wc -c < "$snd" 2>/dev/null | tr -d ' ')
    ui_print "    $(basename "$snd")  (${sndsz}B)"
  done
fi
ui_print ' '

# ---------- Z12 桌面与配套应用(开机后最后安装) ----------
# 一包通的完整顺序:①开关 → ②SystemPlus → ③SystemUI → ④桌面(最后)
#   ①③ 已直接做进模块的 system 分区,开机即生效;
#   ④ 桌面(com.xtc.i3launcher) 与 ⑦⑧ 是普通 APK,必须走“安装应用”的路径。
#
# 为什么不在刷入时直接装完:
#   recovery 里刷模块时 Android 没起来,pm 命令不存在,装了也白装。
#   所以这里只把它带进模块,真正安装交给 service.sh,在系统启动完成后
#   按 AI识屏 → 侧边栏 → 【桌面】 的顺序装,桌面保证是最后一个。
if [ -d "$MODPATH/payload" ]; then
  ui_print '- 将随模块携带并在开机后最后安装:'
  ui_print '    1) AI识屏          com.xtc.intelligentIdentify   (16MB)'
  ui_print '    2) 侧边栏AI启动器  com.xtc.vassistant             (34MB)'
  ui_print '    3) Z12 桌面        com.xtc.i3launcher  14.6.00 Ver7.1 (64MB) <-- 最后安装'
  ui_print "    合计: $(du -sh "$MODPATH/payload" 2>/dev/null | cut -f1) 随模块存放"
  ui_print '    它们在开机完成后自动安装,桌面装好会自动设为默认桌面'
fi
ui_print ' '

# ---------- 整合进来的三个增强模块 ----------
# 0.1.2 Beta 把三个独立模块合并了进来,免得同时挂三份互相抢 sysfs / 抢文件的模块:
#   1) 极致性能 v13.5       —— ultra_performance 守护进程
#   2) WearSoC Tweak v2.9   —— 桌面抗卡顿循环
#   3) Wifi Bonding         —— WCNSS_qcom_cfg.ini 开 40MHz
# 三者的开关都在 /data/adb/star_os/tweaks.conf,第一次开机自动生成。
ui_print '- 整合的增强模块:'

# --- 1. 极致性能:按设备架构挑出对应的可执行文件 ---
# 原模块把 4 个架构的二进制都塞进 zip,安装时挑一个、删掉其余,
# 这样同一个包能同时兼容 arm64 / arm / x86 / x86_64 设备。
PERF_DIR="$MODPATH/tweaks/perf"
if [ -d "$PERF_DIR/bin" ]; then
  case "$ARCH" in
    arm64) ABI=arm64-v8a ;;
    arm)   ABI=armeabi-v7a ;;
    x86)   ABI=x86 ;;
    x64)   ABI=x86_64 ;;
    *)     ABI=arm64-v8a ;;
  esac
  if [ -f "$PERF_DIR/bin/$ABI/ultra_performance" ]; then
    cp -f "$PERF_DIR/bin/$ABI/ultra_performance" "$PERF_DIR/ultra_performance"
    chmod 0755 "$PERF_DIR/ultra_performance"
    ui_print "    1) 极致性能        ultra_performance 守护 ($ARCH -> $ABI)"
  else
    ui_print "    [!!] 找不到 $ABI 对应的 ultra_performance,该功能将不可用"
  fi
  rm -rf "$PERF_DIR/bin"
fi

# --- 2. 桌面流畅度 ---
if [ -f "$MODPATH/tweaks/tweak_main.sh" ]; then
  ui_print '    2) 桌面流畅度      WearSoC Tweak 抗卡顿循环 (每 4 秒加固桌面进程)'
fi

# --- 3. WiFi 40MHz 绑定 ---
# ★ 关键说明:你提供的那个「Wifi增强(高通)」zip 里【一个 system 文件都没有】。
#   它是上游模板仓库的状态(config.sh 里 PROPFILE/POSTFSDATA/LATESTARTSERVICE
#   全是 false,REPLACE 为空),直接刷它等于什么都不做 —— 真正起作用的那份
#   WCNSS_qcom_cfg.ini 根本没打进去。
#   所以这里改成:安装时从【你设备上取原机那一份】,复制进模块后补上 40MHz
#   参数,再让 Magisk 挂载回去。这样既能增强,又不会因为"用一个缺参数的模板
#   替换掉原文件"而把 WiFi 弄坏(原文件里的射频校准参数丢一个都可能导致
#   连不上网)。
#
#   注意:这一步需要能读到 /vendor,在 Magisk 应用里安装(非 recovery)最稳。
WIFI_SRC=""
for _c in /vendor/etc/wifi/WCNSS_qcom_cfg.ini \
          /system/vendor/etc/wifi/WCNSS_qcom_cfg.ini \
          /vendor/firmware/wlan/prima/WCNSS_qcom_cfg.ini \
          /system/vendor/firmware/wlan/prima/WCNSS_qcom_cfg.ini \
          /system/etc/wifi/WCNSS_qcom_cfg.ini; do
  if [ -f "$_c" ]; then
    WIFI_SRC="$_c"
    break
  fi
done

if [ -n "$WIFI_SRC" ]; then
  # /vendor/... 这种路径在模块里要写成 system/vendor/... (Magisk 会挂到 /vendor)
  case "$WIFI_SRC" in
    /system/*) WIFI_DST="$MODPATH$WIFI_SRC" ;;
    *)         WIFI_DST="$MODPATH/system$WIFI_SRC" ;;
  esac
  mkdir -p "$(dirname "$WIFI_DST")" 2>/dev/null
  if cat "$WIFI_SRC" > "$WIFI_DST" 2>/dev/null; then
    # 统一成 LF:有些机型的 ini 是 CRLF 换行,补进去的值会带上 \r 导致解析异常
    tr -d '\r' < "$WIFI_DST" > "$WIFI_DST.tmp" 2>/dev/null && mv -f "$WIFI_DST.tmp" "$WIFI_DST"
    for _k in gChannelBondingMode24GHz gChannelBondingMode5GHz; do
      if grep -q "^[[:space:]]*${_k}=" "$WIFI_DST" 2>/dev/null; then
        sed -i "s/^[[:space:]]*${_k}=.*/${_k}=1/" "$WIFI_DST"
      else
        echo "${_k}=1" >> "$WIFI_DST"
      fi
    done
    echo "# 40MHz 绑定参数由 Star OS 追加" >> "$WIFI_DST"
    _wsz=$(wc -c < "$WIFI_DST" 2>/dev/null | tr -d ' ')
    ui_print "    3) WiFi 40MHz 绑定 取自 $_wsz 字节的原机配置 -> ${WIFI_DST#$MODPATH}"
  else
    ui_print '    [!!] 读到了原机 WiFi 配置但复制失败,已跳过该功能'
  fi
else
  ui_print '    3) WiFi 40MHz 绑定  原机没有 WCNSS_qcom_cfg.ini,该机型不适用,已跳过'
  ui_print '       (只有高通 WCNSS 平台的机型才有这个文件)'
fi
ui_print '    开关文件: /data/adb/star_os/tweaks.conf (第一次开机生成)'
ui_print ' '

# ---------- 安装时完整性校验 ----------
# 防砖的第一道关。如果打进包里的关键文件本身就是残的(字体被截断、
# fonts.xml 被改坏、zip 半截),绝不能放它进系统 —— 与其开机后崩溃黑屏,
# 不如现在就让安装失败,你能立刻知道是哪个文件的问题,而系统分毫未动。
ui_print '- 正在校验关键文件完整性...'

BROKEN=""
chk_min() {
  # $1=路径  $2=最小字节  $3=名称
  [ -f "$1" ] || return 0
  _sz=$(wc -c < "$1" 2>/dev/null | tr -d ' ')
  case "$_sz" in ''|*[!0-9]*) _sz=0 ;; esac
  [ "$_sz" -lt "$2" ] && BROKEN="$BROKEN ${3}(${_sz}B)"
  return 0
}

chk_min "$MODPATH/system/fonts/font.ttf"                1048576 "font.ttf"
chk_min "$MODPATH/system/fonts/PingFangSC-Light.ttf"    1048576 "PingFangSC-Light.ttf"
chk_min "$MODPATH/system/fonts/PingFangSC-Medium.ttf"   1048576 "PingFangSC-Medium.ttf"
chk_min "$MODPATH/system/fonts/PingFangSC-Semibold.ttf" 1048576 "PingFangSC-Semibold.ttf"
chk_min "$MODPATH/system/media/audio/ui/Effect_Tick.ogg"  512 "Effect_Tick.ogg"
chk_min "$MODPATH/system/media/audio/ui/camera_click.ogg" 512 "camera_click.ogg"
chk_min "$MODPATH/system/media/audio/ui/VideoRecord.ogg"  512 "VideoRecord.ogg"
chk_min "$MODPATH/system/vendor/res/theme/caremeos5/bg_care_me.png" 1024 "bg_care_me.png"

# 整合进来的增强模块:脚本太小说明被截断;ultra_performance 必须还是完整的 ELF
chk_min "$MODPATH/tweaks/tweak_main.sh" 1024 "tweak_main.sh"
chk_min "$MODPATH/tweaks/perf/ultra_performance.sh" 1024 "ultra_performance.sh"
_UP="$MODPATH/tweaks/perf/ultra_performance"
if [ -f "$_UP" ]; then
  _upsz=$(wc -c < "$_UP" 2>/dev/null | tr -d ' ')
  case "$_upsz" in ''|*[!0-9]*) _upsz=0 ;; esac
  [ "$_upsz" -lt 4096 ] && BROKEN="$BROKEN ultra_performance(${_upsz}B)"
  # ELF 魔数 0x7F 'E' 'L' 'F';取不到 od 输出时不做判断,避免误报
  _umagic=$(head -c 4 "$_UP" 2>/dev/null | od -An -tx1 2>/dev/null | tr -d ' \n')
  if [ -n "$_umagic" ] && [ "$_umagic" != "7f454c46" ]; then
    BROKEN="$BROKEN ultra_performance(非ELF)"
  fi
fi

# WiFi 配置:被截断的 ini 会让 WiFi 模块加载失败,宁可现在中止
for _wc in "$MODPATH/system/vendor/etc/wifi/WCNSS_qcom_cfg.ini" \
           "$MODPATH/system/etc/wifi/WCNSS_qcom_cfg.ini"; do
  [ -f "$_wc" ] && chk_min "$_wc" 1024 "$(basename "$_wc")"
done

# 桌面/配套 APK:体积下限按真实值砍半,再确认 zip 魔数 ——
# 半截的 APK 装到一半失败,会在系统里留下残留包记录,比不装更麻烦
chk_min "$MODPATH/payload/i3launcher.apk"  33554432 "i3launcher.apk"
chk_min "$MODPATH/payload/sidebar_ai.apk"  16777216 "sidebar_ai.apk"
chk_min "$MODPATH/payload/ai_screen.apk"    8388608 "ai_screen.apk"
for _pk in "$MODPATH/payload"/*.apk; do
  [ -f "$_pk" ] || continue
  if [ "$(head -c 2 "$_pk" 2>/dev/null)" != "PK" ]; then
    BROKEN="$BROKEN $(basename "$_pk")(非zip)"
  fi
done

# fonts.xml 单独判:体积之外还要有完整的结束标签,截断的 XML 会直接导致无法开机
_FX="$MODPATH/system/etc/fonts.xml"
if [ -f "$_FX" ]; then
  _fxsz=$(wc -c < "$_FX" 2>/dev/null | tr -d ' ')
  case "$_fxsz" in ''|*[!0-9]*) _fxsz=0 ;; esac
  if [ "$_fxsz" -lt 4096 ]; then
    BROKEN="$BROKEN fonts.xml(${_fxsz}B)"
  elif ! grep -q '</familyset>' "$_FX" 2>/dev/null; then
    BROKEN="$BROKEN fonts.xml(缺少结束标签)"
  fi
fi

# 开机动画必须是完整的 zip(头部魔数 PK)
for _ba in "$MODPATH/system/media/bootanimation.zip" "$MODPATH/system/media/bootanimation_4100.zip"; do
  [ -f "$_ba" ] || continue
  if [ "$(head -c 2 "$_ba" 2>/dev/null)" != "PK" ]; then
    BROKEN="$BROKEN $(basename "$_ba")(非zip)"
  fi
done

if [ -n "$BROKEN" ]; then
  ui_print '  [!!] 以下文件不完整:'
  ui_print "     $BROKEN"
  ui_print ' '
  abort "! 关键文件校验失败,已中止安装(你的系统分毫未动)"
fi
ui_print '  校验通过'
ui_print ' '

# ---------- 重置自检状态 ----------
# 重装就是一次全新的开始:清掉上一轮遗留的禁用标记与启动计数,
# 否则 post-fs-data.sh 会把历史的启动失败次数继续累加,导致刚装好又被自动禁用。
rm -f "/data/adb/modules/$MODID/disable" 2>/dev/null
rm -f /data/adb/star_os/boot_attempts 2>/dev/null
rm -f /data/adb/star_os/auto_disabled 2>/dev/null
# 重刷 = 重新装一遍桌面/侧边栏/AI识屏:清掉“已完成”标记,否则会被跳过
rm -f /data/adb/star_os/payload_done 2>/dev/null
# 守护循环的锁:不清掉的话,如果重刷后没重启,新进程会因为"旧 PID 还活着"而退出
rm -f /data/adb/star_os/tweak_loop.pid 2>/dev/null

# ---------- 3. 权限兜底 ----------
ui_print "- 正在设置文件权限..."
set_perm_recursive "$MODPATH" 0 0 0755 0644

# 注意:上面那句 set_perm_recursive 会把所有文件压成 0644,
# 所以可执行文件必须在它之后一个个补回来,漏一个就少一个执行位。
for f in "$MODPATH/customize.sh" "$MODPATH/service.sh" \
         "$MODPATH/post-fs-data.sh" "$MODPATH/uninstall.sh" \
         "$MODPATH/boot-completed.sh" \
         "$MODPATH/tweaks/tweak_main.sh" \
         "$MODPATH/tweaks/perf/perfboost.sh" \
         "$MODPATH/tweaks/perf/ultra_performance.sh" \
         "$MODPATH/tweaks/perf/ultra_performance"; do
  [ -f "$f" ] && set_perm "$f" 0 0 0755
done

# XTCSystemUI 的原生库需要可执行位,否则 dlopen 会失败
for so in "$MODPATH/system/priv-app/XTCSystemUI/lib/"*/*.so; do
  [ -f "$so" ] && set_perm "$so" 0 0 0755
done

# ---------- 4. 替换系统应用时的清理(按需启用) ----------
# 替换系统 APK 后,旧的包缓存可能让应用闪退/回滚到旧版本,可清理:
# ui_print "- 正在清理包管理缓存..."
# rm -rf /data/system/package_cache/* 2>/dev/null

# ---------- 5. 收尾 ----------
ui_print "- 安装完成,重启后生效"
ui_print " "
ui_print "- 随模块一起安装的「Star OS」应用(桌面图标可打开):"
ui_print "  system/app/StarOS/StarOS.apk  (versionCode 与模块同步)"
ui_print "  1) 模块首次安装或更新后,开机会自动弹一次 Star OS 欢迎页,"
ui_print "     点底部「进入桌面」即回到桌面,该页不再出现。"
ui_print "  2) 打开应用可检测模块更新:发现新版本可直接下载并安装,"
ui_print "     首次使用请在 Magisk 里给「Star OS」授权 root(否则装不了)。"
ui_print " "
ui_print "- 重启后请稍等 1~2 分钟:"
ui_print "  模块会在系统启动完成后自动安装 Z12 桌面与配套应用,"
ui_print "  顺序为 AI识屏 -> 侧边栏 -> 桌面(最后一个),全程无需手动操作。"
ui_print "  三个增强模块(极致性能/桌面流畅度/WiFi)同时启动。"
ui_print "  进度与结果可查看 /data/adb/star_os/guard.log"
ui_print " "
ui_print "- 想关掉其中某个增强,编辑 /data/adb/star_os/tweaks.conf 后重启:"
ui_print "    PERF=0          关掉极致性能(含温控解锁,发热大时建议关)"
ui_print "    PERF_THERMAL=0  只关温控解锁,性能守护保留"
ui_print "    SMOOTH=0        关掉桌面抗卡顿循环"
ui_print "    WIFI=0          关掉 WiFi 40MHz 绑定提示"
ui_print " "

# ---------- 6. 注意事项(摘自发布说明,内容原样保留) ----------
# 说明:只有两行因超过 40 列而折行(在逗号处断开),文字未做任何改动。
# 全部用单引号包裹,避免 + - _ | ( ) & 等符号被 shell 解释。
ui_print '--------------------------------------------------'
ui_print '注意事项:'
ui_print ' 1.(反馈)必须将桌面传到手表上进行安装,因为桌面安装之后将自动'
ui_print '    重启,所以不能使用ATB安装(ADB工具箱似乎可以)'
ui_print ' 2.(反馈)关于systemUI模块无法刷入的问题,将提供两种模块可供选择'
ui_print ' 3.请一定一定一定要保存你原桌面的apk,不然想回退原来的桌面'
ui_print '    查找资源将会很麻烦'
ui_print ' 如有问题需要可在群中反馈'
ui_print ' 模块作者：星'
ui_print ' 编辑人:梧影浅酌（3642673319）'
ui_print ' 相关资源作者:枫茶夜雨&新初创极光&早茶光&伍潵&huanli233'
ui_print ' 相关群号:935758246(Nature主群)'
ui_print ' 907491503(ATB主群)'
ui_print ' 1128072612：star os'
ui_print ' 最后编辑时间:17:50,2026/10/02'
ui_print '--------------------------------------------------'
ui_print ' '
