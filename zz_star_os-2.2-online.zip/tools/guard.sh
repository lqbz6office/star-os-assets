#!/system/bin/sh
# ============================================================================
#  Star OS · 星控 (guard.sh)   —— Pro+ / 终身版专属
#  ===========================================================
#  统一工具协议见 tools/power.sh 开头。
#
#  干的事:把"应用偷偷在后台跑"这件事管起来 —— 禁了自启的应用,只有你打开它时
#        才活;你一退出,它就真的睡了。
#
#  和「星盾」的分工:
#    星盾 = 让应用整个消失(桌面上都看不到,起不来);
#    星控 = 应用还在、还能正常打开,只是不许它自己偷偷在后台常驻。
#    一个是"藏起来",一个是"别乱跑"。
#
#  实现:用系统自带的 appops(RUN_IN_BACKGROUND)——这是 Android 官方就有的
#   "后台运行"开关,不是 hook 也不是补丁,所以既不伤系统也不会被判定成异常。
#
#  真值来源:appops 自己的状态(每次现查),不另存一份名单 ——
#  免得出现"名单说禁了但系统没禁"这种对不上的情况。
# ============================================================================

PWDIR=${0%/*}
[ -d "$PWDIR" ] || PWDIR=/data/adb/modules/zz_star_os
STAR=${STAR_DIR:-/data/adb/star_os}
LOG=$STAR/logs/guard.log

mkdir -p "$STAR/logs" 2>/dev/null

gu_log() { echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$LOG" 2>/dev/null; }

# 本地闸门(真值在台账,由应用联网核对后写入 pro.conf)
gu_tier() {
  gug_v=0
  if [ -f "$STAR/pro.conf" ]; then
    gug_v=$(sed -n 's/^tier=//p' "$STAR/pro.conf" 2>/dev/null | head -n 1)
  fi
  case "$gug_v" in
    ''|*[!0-9]*) echo 0 ;;
    *) echo "$gug_v" ;;
  esac
}

gu_gate() {
  [ "$(gu_tier)" -ge 2 ] && return 0
  echo "星控是 Pro+ / 终身版功能,当前等级不够" >&2
  return 5
}

# 友好名 —— 手表上认名字比认包名快
gu_friendly() {
  case "$1" in
    com.tencent.mm) echo "微信" ;;
    com.tencent.mobileqq) echo "QQ" ;;
    com.eg.android.AlipayGphone) echo "支付宝" ;;
    com.ss.android.ugc.aweme) echo "抖音" ;;
    com.xtc.watch) echo "小天才" ;;
    com.xtc.*) echo "小天才组件" ;;
    com.netease.*) echo "网易系" ;;
    com.tencent.tmgp.*) echo "腾讯游戏" ;;
    com.tencent.qqlive*) echo "腾讯视频" ;;
    tv.danmaku.bili) echo "哔哩哔哩" ;;
    com.tencent.qqmusic) echo "QQ音乐" ;;
    com.kugou.android) echo "酷狗" ;;
    com.ximalaya.ting.android) echo "喜马拉雅" ;;
    *) echo "$1" ;;
  esac
}

gu_has_appops() {
  if command -v cmd >/dev/null 2>&1; then
    cmd appops get android RUN_IN_BACKGROUND >/dev/null 2>&1 && echo 1 || echo 0
  else
    echo 0
  fi
}

# 1=已被禁后台 0=允许或没记录
gu_state() {
  gus_o=$(cmd appops get "$1" RUN_IN_BACKGROUND 2>/dev/null)
  case "$gus_o" in
    *deny*|*ignore*) echo 1 ;;
    *) echo 0 ;;
  esac
}

gu_thirds() {
  pm list packages -3 2>/dev/null | sed -n 's/^package://p' | sort
}

# 这些包永远不碰:禁了可能让手表起不来或通话/短信失联
gu_protected() {
  case "$1" in
    com.android.*|android|com.xtc.watch|com.staros.*|com.coderstory.*) return 0 ;;
  esac
  return 1
}

gu_status() {
  if [ "$(gu_has_appops)" != "1" ]; then
    echo "这台机器不支持 appops 管制,用不了这个功能。"
    return 0
  fi
  gub_n=0
  gub_list=""
  for gub_p in $(gu_thirds); do
    [ -z "$gub_p" ] && continue
    gu_protected "$gub_p" && continue
    if [ "$(gu_state "$gub_p")" = "1" ]; then
      gub_n=$((gub_n + 1))
      gub_list="$gub_list$gub_p
"
    fi
  done
  if [ "$gub_n" = "0" ]; then
    echo "已管制:还没有"
    echo ""
    echo "下面「挑应用管制」进去,勾选不想让它偷偷后台跑的应用。"
    echo "管制后应用照样能打开用,只是退出后不再自己复活。"
  else
    echo "已管制 ($gub_n 个):"
    echo "$gub_list" | while read -r gus_p; do
      [ -z "$gus_p" ] && continue
      echo "@item|$(gu_friendly "$gus_p") · 恢复自启|act|allow:$gus_p"
    done
  fi
  echo ""
  echo "@item|挑应用管制(禁自启)|act|pick"
  return 0
}

case "$1" in
  meta)
    echo "guard|星控|禁止应用偷偷在后台常驻,退出就真睡了|2|pick:挑应用管制:pri,restore:全部恢复自启:ghost"
    ;;
  status)
    gu_gate || exit 5
    gu_status
    ;;
  act)
    gu_gate || exit 5
    case "$2" in
      pick)
        if [ "$(gu_has_appops)" != "1" ]; then
          echo "这台机器不支持 appops 管制。" >&2
          exit 1
        fi
        echo "点一个应用禁止它自启(应用本身照样能用,只是退出后不再后台复活)。"
        echo "已经在管制里的,点一下可以放行。"
        echo ""
        gu_thirds | while read -r gup_p; do
          [ -z "$gup_p" ] && continue
          gu_protected "$gup_p" && continue
          if [ "$(gu_state "$gup_p")" = "1" ]; then
            echo "@item|[已禁] $(gu_friendly "$gup_p")|act|allow:$gup_p"
          else
            echo "@item|$(gu_friendly "$gup_p")|act|deny:$gup_p"
          fi
        done
        ;;
      deny)
        [ -z "$3" ] && { echo "缺少包名" >&2; exit 2; }
        if gu_protected "$3"; then
          echo "这个应用不能管制(禁了手表可能出问题)" >&2
          exit 3
        fi
        if cmd appops set "$3" RUN_IN_BACKGROUND deny >/dev/null 2>&1; then
          echo "已禁止自启:$(gu_friendly "$3")"
          echo "它退出后就不会再自己跑起来了。"
          gu_log "deny $3"
        else
          echo "管制失败:$3" >&2
          exit 1
        fi
        ;;
      allow)
        [ -z "$3" ] && { echo "缺少包名" >&2; exit 2; }
        # 用 default 而不是 allow:回到"系统默认",比强行放开更规矩
        cmd appops set "$3" RUN_IN_BACKGROUND default >/dev/null 2>&1
        echo "已恢复自启:$(gu_friendly "$3")"
        gu_log "allow $3"
        ;;
      restore)
        echo "正在全部放行…"
        gun_n=0
        for gur_p in $(gu_thirds); do
          [ -z "$gur_p" ] && continue
          gu_protected "$gur_p" && continue
          if [ "$(gu_state "$gur_p")" = "1" ]; then
            cmd appops set "$gur_p" RUN_IN_BACKGROUND default >/dev/null 2>&1
            gun_n=$((gun_n + 1))
          fi
        done
        echo "已放行 $gun_n 个应用的自启。"
        gu_log "restore-all $gun_n"
        ;;
      *)
        echo "未知动作:$2" >&2
        exit 2
        ;;
    esac
    ;;
  *)
    echo "用法:$0 {meta|status|act <动作> [参数]}" >&2
    exit 2
    ;;
esac
