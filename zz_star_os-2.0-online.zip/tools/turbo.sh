#!/system/bin/sh
# ============================================================================
#  Star OS · 性能调度 (turbo.sh)   —— Pro+ / 终身版专属
#  ===========================================================
#  统一工具协议见 tools/power.sh 开头。
#
#    · 三档调度:性能 / 均衡 / 省电 —— 一次调好 CPU governor、IO 调度、内存回收倾向
#    · 真值不另存:档位记一份,但"当前 governor"永远现读 /sys,不靠猜
#    · 说不动的就说不动:老内核没有某些节点是常态,缺了就跳过并如实报告
#
#  和「续航管家」的分工:
#    power 管的是"屏幕亮多久、后台停不停"这类用户能感知的开关;
#    turbo 动的是内核调度参数 —— 更底层、更硬核,所以放在 Pro+。
# ============================================================================

PWDIR=${0%/*}
[ -d "$PWDIR" ] || PWDIR=/data/adb/modules/zz_star_os
STAR=${STAR_DIR:-/data/adb/star_os}
TD=$STAR/turbo
LOG=$STAR/logs/turbo.log

mkdir -p "$TD" "$STAR/logs" 2>/dev/null

tb_log() { echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$LOG" 2>/dev/null; }

# 本地闸门(真值在台账,由应用联网核对后写入 pro.conf)
tb_tier() {
  tbg_v=0
  if [ -f "$STAR/pro.conf" ]; then
    tbg_v=$(sed -n 's/^tier=//p' "$STAR/pro.conf" 2>/dev/null | head -n 1)
  fi
  case "$tbg_v" in
    ''|*[!0-9]*) echo 0 ;;
    *) echo "$tbg_v" ;;
  esac
}

tb_gate() {
  [ "$(tb_tier)" -ge 2 ] && return 0
  echo "性能调度是 Pro+ / 终身版功能,当前等级不够" >&2
  return 5
}

# 可覆盖路径(留口子是为了能在电脑上跑测试;真机上就是默认值)
TB_CPU=${TURBO_CPU_DIR:-/sys/devices/system/cpu}
TB_VM=${TURBO_VM_DIR:-/proc/sys/vm}
TB_IO=${TURBO_IO_DIR:-/sys/block}

tb_cur_gov() { cat "$TB_CPU/cpu0/cpufreq/scaling_governor" 2>/dev/null | tr -d ' \r\n'; }
tb_avail_gov() { cat "$TB_CPU/cpu0/cpufreq/scaling_available_governors" 2>/dev/null | tr -d '\r\n'; }
tb_cur_sched() { cat "$TB_IO/mmcblk0/queue/scheduler" 2>/dev/null | tr -d '\r\n'; }
tb_swappiness() { cat "$TB_VM/swappiness" 2>/dev/null | tr -d ' \r\n'; }
tb_profile() { cat "$TD/profile" 2>/dev/null | tr -d ' \r\n'; }

tb_label() {
  case "$1" in
    perf) echo "性能" ;;
    bal)  echo "均衡" ;;
    save) echo "省电" ;;
    *)    echo "未设置" ;;
  esac
}

# 从候选里挑第一个"这台机器真的支持"的 governor
tb_pick_gov() {
  tb_av=$(tb_avail_gov)
  for tbc in "$@"; do
    case " $tb_av " in
      *" $tbc "*) printf '%s' "$tbc"; return 0 ;;
    esac
  done
  printf ''
  return 1
}

# 从候选里挑第一个支持的 IO 调度器
tb_pick_sched() {
  tb_av=$(tb_cur_sched)
  for tbc in "$@"; do
    case "$tb_av" in
      *"$tbc"*) printf '%s' "$tbc"; return 0 ;;
    esac
  done
  printf ''
  return 1
}

tb_apply() {
  tb_p="$1"
  case "$tb_p" in
    perf) tb_gov=$(tb_pick_gov performance schedutil interactive); tb_sw=60;  tb_io=$(tb_pick_sched deadline cfq) ;;
    bal)  tb_gov=$(tb_pick_gov schedutil interactive ondemand);    tb_sw=100; tb_io=$(tb_pick_sched cfq deadline) ;;
    save) tb_gov=$(tb_pick_gov powersave conservative schedutil);  tb_sw=100; tb_io=$(tb_pick_sched noop deadline) ;;
    *) echo "未知档位:$tb_p" >&2; return 2 ;;
  esac

  echo "===== 应用「$(tb_label "$tb_p")」档 ====="

  # 1) CPU governor:逐核心写,写不动就跳过
  tb_n=0
  tb_ok=0
  for tbc in "$TB_CPU"/cpu[0-9]*; do
    [ -e "$tbc" ] || continue
    tb_n=$((tb_n + 1))
    if [ -n "$tb_gov" ] && [ -w "$tbc/cpufreq/scaling_governor" ]; then
      echo "$tb_gov" > "$tbc/cpufreq/scaling_governor" 2>/dev/null && tb_ok=$((tb_ok + 1))
    fi
  done
  if [ "$tb_n" -eq 0 ]; then
    echo "CPU   : 读不到 cpufreq 节点(可能被内核锁定),跳过"
  elif [ "$tb_ok" -gt 0 ]; then
    echo "CPU   : 已设 $(tb_label "$tb_p") 调度 = ${tb_gov:-无匹配},影响 $tb_ok/$tb_n 个核心"
  else
    echo "CPU   : 有节点但写不进去(内核只读),跳过(可用 governor: ${tb_av:-未知})"
  fi

  # 2) IO 调度
  if [ -n "$tb_io" ] && [ -w "$TB_IO/mmcblk0/queue/scheduler" ]; then
    echo "$tb_io" > "$TB_IO/mmcblk0/queue/scheduler" 2>/dev/null \
      && echo "IO    : 已设为 $tb_io" || echo "IO    : 写入失败,跳过"
  else
    echo "IO    : 无 mmcblk0 调度节点,跳过"
  fi

  # 3) 内存回收倾向(vm.swappiness)
  if [ -n "$tb_sw" ] && [ -w "$TB_VM/swappiness" ]; then
    echo "$tb_sw" > "$TB_VM/swappiness" 2>/dev/null \
      && echo "内存  : swappiness = $(tb_swappiness)" || echo "内存  : swappiness 写不进去,跳过"
  else
    echo "内存  : 无 swappiness 节点,跳过"
  fi

  printf '%s\n' "$tb_p" > "$TD/profile" 2>/dev/null
  echo "已记录档位:$(tb_label "$tb_p")"
  tb_log "profile=$tb_p gov=${tb_gov:-none} io=${tb_io:-none} sw=${tb_sw:-none}"
  return 0
}

tb_status() {
  echo "当前档位 : $(tb_label "$(tb_profile)")"
  tb_g=$(tb_cur_gov)
  echo "CPU 调度 : ${tb_g:-读不到}"
  tb_ag=$(tb_avail_gov)
  echo "可用调度 : ${tb_ag:-读不到}"
  echo "IO 调度  : $(tb_cur_sched)"
  echo "swappiness: $(tb_swappiness)"
  echo ""
  echo "@item|切到「性能」档(最跟手)|act|perf"
  echo "@item|切到「均衡」档(推荐)|act|bal"
  echo "@item|切到「省电」档(最省电)|act|save"
  echo "@item|看看这台机器支持哪些调度|act|detail"
  return 0
}

tb_detail() {
  echo "===== 调度器详情 ====="
  echo "CPU 核心数: $(ls -d "$TB_CPU"/cpu[0-9]* 2>/dev/null | wc -l)"
  echo "当前 governor: $(tb_cur_gov)"
  echo "可用 governor: ${$(tb_avail_gov)}" 2>/dev/null
  tb_ag=$(tb_avail_gov)
  echo "可用 governor: ${tb_ag:-读不到}"
  echo ""
  echo "各核心当前调度:"
  for tbc in "$TB_CPU"/cpu[0-9]*; do
    [ -e "$tbc/cpufreq/scaling_governor" ] || continue
    printf '  %-8s %s\n' "$(basename "$tbc")" "$(cat "$tbc/cpufreq/scaling_governor" 2>/dev/null)"
  done
  echo ""
  echo "当前频率范围(cpu0):"
  echo "  min $(cat "$TB_CPU/cpu0/cpufreq/scaling_min_freq" 2>/dev/null)"
  echo "  max $(cat "$TB_CPU/cpu0/cpufreq/scaling_max_freq" 2>/dev/null)"
}

case "$1" in
  meta)
    echo "turbo|性能调度|CPU/IO/内存内核参数三档一键切换(Pro+)|2|perf:性能档:pri,bal:均衡档:pri,save:省电档:ghost,detail:调度详情:ghost"
    ;;
  status)
    tb_status
    ;;
  act)
    tb_gate || exit $?
    case "$2" in
      perf|bal|save) tb_apply "$2" ;;
      detail)        tb_detail ;;
      *)             echo "未知动作:$2" >&2; exit 2 ;;
    esac
    ;;
  *)
    echo "用法:$0 {meta|status|act <perf|bal|save|detail>}" >&2
    exit 2
    ;;
esac
