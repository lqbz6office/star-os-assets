#!/system/bin/sh
# ============================================================================
#  Star OS · 星云 (snapshot.sh)   —— 基础功能(免费)
#  ===========================================================
#  统一工具协议见 tools/power.sh 开头。
#
#  干的事:把"你调出来的那套东西"打成一个包 —— 工具开关、Dock 布局、
#        主题与表盘选择、插件启用状态、XP 配置。换桌面、刷机、换表,
#        一条命令还原,不用再从头点一遍。
#
#  ⚠ 绝不打包的东西:发码令牌 / 投稿令牌 / 任何密码。
#     打包前会显式删掉,免得快照外流等于把钥匙送人。
#
#  数据:内部存储/StarOS/快照/snap-<日期-时间>.tar
# ============================================================================

PWDIR=${0%/*}
[ -d "$PWDIR" ] || PWDIR=/data/adb/modules/zz_star_os/tools
MODD=${PWDIR%/*}
[ -d "$MODD" ] || MODD=/data/adb/modules/zz_star_os
STAR=${STAR_DIR:-/data/adb/star_os}
SN=$STAR/snapshot
LOG=$STAR/logs/snapshot.log
OUT=${SNAP_OUT_DIR:-/sdcard/StarOS/快照}
APPD=/data/data/com.staros.app
SDC=/sdcard/StarOS
WORK=$SN/work
mkdir -p "$SN" "$STAR/logs" "$OUT" 2>/dev/null

sn_log() { echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$LOG" 2>/dev/null; }

sn_last() { ls -t "$OUT"/snap-*.tar 2>/dev/null | head -n 1; }

sn_collect() {
  # 清空工作目录(不用 rm -rf 整目录,逐项删更稳)
  rm -rf "$WORK" 2>/dev/null
  mkdir -p "$WORK/module" "$WORK/appprefs" "$WORK/sdcard" 2>/dev/null

  # 1. 模块侧状态:只拿配置和状态,不要 logs/report/snapshot 本身
  for sn_f in "$STAR"/*.conf "$STAR"/*.txt; do
    [ -f "$sn_f" ] || continue
    cp -f "$sn_f" "$WORK/module/" 2>/dev/null
  done
  for sn_d in state theme dial plugins; do
    [ -d "$STAR/$sn_d" ] && cp -r "$STAR/$sn_d" "$WORK/module/" 2>/dev/null
  done

  # 2. StarOS 应用的 SharedPreferences(Dock/灵动岛/XP 开关/工具调参都在这里)
  if [ -d "$APPD/shared_prefs" ]; then
    cp -f "$APPD/shared_prefs/"*.xml "$WORK/appprefs/" 2>/dev/null
  fi

  # 3. 存储卡上的用户配置
  for sn_g in "$SDC"/*.txt "$SDC"/*.conf "$SDC"/*.json; do
    [ -f "$sn_g" ] || continue
    cp -f "$sn_g" "$WORK/sdcard/" 2>/dev/null
  done

  # 4. ⚠ 敏感文件一律剔除(令牌 / 密码 / 私钥)
  rm -f "$WORK/sdcard/发码令牌.txt" "$WORK/sdcard/投稿令牌.txt" 2>/dev/null
  rm -f "$WORK/module/发码令牌.txt" "$WORK/module/投稿令牌.txt" 2>/dev/null
  for sn_s in "$WORK"/sdcard/*.txt "$WORK"/module/*.txt; do
    case "$sn_s" in
      *令牌*|*token*|*TOKEN*|*密码*|*pass*|*PASS*|*key*|*KEY*) rm -f "$sn_s" 2>/dev/null ;;
    esac
  done

  # 5. 记一份清单,还原时能看出这一包是哪台机器、哪个版本
  {
    echo "model=$(getprop ro.product.model)"
    echo "version=$(grep '^version=' "$MODD/module.prop" 2>/dev/null | cut -d= -f2)"
    echo "time=$(date '+%Y-%m-%d %H:%M:%S')"
    echo "files=$(find "$WORK" -type f 2>/dev/null | wc -l)"
  } > "$WORK/META.txt" 2>/dev/null
}

sn_save() {
  sn_collect
  sn_f="$OUT/snap-$(date '+%Y%m%d-%H%M%S').tar"
  ( cd "$WORK" && tar -cf "$sn_f" . 2>/dev/null )
  if [ -s "$sn_f" ]; then
    sn_n=$(find "$WORK" -type f 2>/dev/null | wc -l)
    sn_sz=$(du -h "$sn_f" 2>/dev/null | cut -f1)
    sn_log "save $sn_f ($sn_n files, $sn_sz)"
    echo "快照已保存:"
    echo "$sn_f"
    echo ""
    echo "($sn_n 个文件, $sn_sz;令牌类文件已排除)"
    # 只留最近 10 份,免得越攒越多
    ls -t "$OUT"/snap-*.tar 2>/dev/null | tail -n +11 | while read -r sn_old; do
      rm -f "$sn_old" 2>/dev/null
    done
  else
    echo "快照失败:写不进 $OUT" >&2
    exit 1
  fi
}

sn_list() {
  sn_l=$(ls -t "$OUT"/snap-*.tar 2>/dev/null)
  if [ -z "$sn_l" ]; then
    echo "还没有快照。点「保存快照」先存一份。"
    return 0
  fi
  echo "已有快照(新→旧):"
  echo "$sn_l" | while read -r sn_x; do
    [ -z "$sn_x" ] && continue
    echo "  $(basename "$sn_x")  $(du -h "$sn_x" 2>/dev/null | cut -f1)"
  done
}

sn_restore() {
  sn_r="$1"
  if [ -z "$sn_r" ]; then
    sn_r=$(sn_last)
  fi
  if [ -z "$sn_r" ] || [ ! -f "$sn_r" ]; then
    echo "找不到快照文件。" >&2
    exit 1
  fi
  echo "正在还原:$(basename "$sn_r")"
  rm -rf "$WORK" 2>/dev/null
  mkdir -p "$WORK" 2>/dev/null
  tar -xf "$sn_r" -C "$WORK" 2>/dev/null || {
    echo "解包失败:文件可能损坏" >&2
    exit 1
  }

  sn_c=0
  # 模块侧
  if [ -d "$WORK/module" ]; then
    for sn_f in "$WORK/module"/*.conf "$WORK/module"/*.txt; do
      [ -f "$sn_f" ] || continue
      cp -f "$sn_f" "$STAR/" 2>/dev/null && sn_c=$((sn_c+1))
    done
    for sn_d in state theme dial plugins; do
      [ -d "$WORK/module/$sn_d" ] || continue
      cp -r "$WORK/module/$sn_d" "$STAR/" 2>/dev/null && sn_c=$((sn_c+1))
    done
  fi
  # 应用配置
  if [ -d "$WORK/appprefs" ]; then
    mkdir -p "$APPD/shared_prefs" 2>/dev/null
    for sn_f in "$WORK/appprefs"/*.xml; do
      [ -f "$sn_f" ] || continue
      cp -f "$sn_f" "$APPD/shared_prefs/" 2>/dev/null && sn_c=$((sn_c+1))
    done
    chown -R "$(stat -c %u:%g "$APPD" 2>/dev/null)" "$APPD/shared_prefs" 2>/dev/null
    chmod 660 "$APPD/shared_prefs/"*.xml 2>/dev/null
  fi
  # 存储卡配置
  if [ -d "$WORK/sdcard" ]; then
    mkdir -p "$SDC" 2>/dev/null
    for sn_f in "$WORK/sdcard"/*; do
      [ -f "$sn_f" ] || continue
      cp -f "$sn_f" "$SDC/" 2>/dev/null && sn_c=$((sn_c+1))
    done
  fi

  sn_log "restore $sn_r ($sn_c items)"
  echo ""
  echo "已还原 $sn_c 项。"
  echo "重启一次让 StarOS 和桌面重新读取配置。"
}

sn_status() {
  sn_r=$(sn_last)
  if [ -n "$sn_r" ]; then
    echo "最近快照:$(basename "$sn_r")"
    echo "大小:$(du -h "$sn_r" 2>/dev/null | cut -f1)"
  else
    echo "最近快照:还没有"
  fi
  echo "存放位置:$OUT"
  echo ""
  echo "包含:工具开关 / Dock 布局 / 主题与表盘 / 插件状态 / XP 配置"
  echo "不含:令牌、密码(打包时已剔除)"
  echo ""
  echo "@item|保存快照|act|save"
  echo "@item|查看已有快照|act|list"
  echo "@item|还原最近一份|act|restore"
  return 0
}

case "$1" in
  meta)
    echo "snapshot|星云|把工具开关/Dock/主题/插件打包,换机刷机一条命令还原|0|save:保存快照:pri,list:已有快照:ghost,restore:还原最近:ghost"
    ;;
  status)
    sn_status
    ;;
  act)
    case "$2" in
      save)    sn_save ;;
      list)    sn_list ;;
      restore) sn_restore "$3" ;;
      *)
        echo "未知动作:$2" >&2
        exit 2
        ;;
    esac
    ;;
  *)
    echo "用法:$0 {meta|status|act <动作>}" >&2
    exit 2
    ;;
esac
