#!/system/bin/sh
##########################################################################
# welcome_launch.sh —— 开机后【尽快】拉起「欢迎页判断门」
#
# 由 service.sh 在最早时刻以后台子进程方式启动(见 service.sh 第 0 节),
# 和开机自检并行跑。它只做一件事:等到系统启动完成,立刻 am start。
#
# 为什么单独一个脚本、还要脱离父进程:
#   service.sh 第 1~7 步要「等 boot_completed → sleep 20 秒观察期 →
#   装三个 APK → 切默认桌面」,全跑完才轮到弹欢迎页 —— 这是 1.4.1fix2
#   及更早版本「进桌面好久才弹」的根因。拆出来单独跑,就不再受它拖累。
#
# 为什么拉起的是 GateActivity 而不是 WelcomeActivity:
#   GateActivity 是无窗口(Theme.NoDisplay)的「判断门」,由应用自己决定
#   这个版本弹过没有 —— 弹过就静默结束(屏幕上什么都不出现),没弹过才转
#   真正的欢迎页。这样脚本侧不需要读应用私有目录、不需要 root 判版本、
#   更不需要写死延迟。
#
# 参数:$1 = 模块目录(用于日志定位;不传则用默认路径)
##########################################################################

MODDIR=${1:-/data/adb/modules/zz_star_os}
STATE=/data/adb/star_os
LOG=$STATE/guard.log
PM=/system/bin/pm
CMDPKG=/system/bin/cmd
AM=/system/bin/am

mkdir -p "$STATE" 2>/dev/null
log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" >> "$LOG" 2>/dev/null; }

PKG=com.staros.app
ACT=$PKG/.GateActivity

uptime_s() { cut -d. -f1 /proc/uptime 2>/dev/null; }

# ---------- 1. 等系统启动完成(最多 3 分钟) ----------
wlc_i=0
while [ "$(getprop sys.boot_completed)" != "1" ] && [ "$wlc_i" -lt 180 ]; do
  sleep 1
  wlc_i=$((wlc_i + 1))
done
if [ "$(getprop sys.boot_completed)" != "1" ]; then
  log "欢迎页: 等开机完成超时(3 分钟),本次放弃"
  exit 0
fi
log "欢迎页: 检测到开机完成(uptime $(uptime_s)s),开始拉起"

# ---------- 2. 等应用被包管理器扫到(系统应用,通常几秒;最多 20 秒) ----------
wlc_i=0
while [ "$wlc_i" -lt 20 ]; do
  "$PM" path "$PKG" >/dev/null 2>&1 && break
  sleep 1
  wlc_i=$((wlc_i + 1))
done
if ! "$PM" path "$PKG" >/dev/null 2>&1; then
  log "欢迎页: 未找到 StarOS 应用,本次跳过"
  exit 0
fi

# ---------- 3. 立刻拉起,1 秒一次重试(最多 10 次) ----------
# am 在某些 ROM 上不可用,这时换 cmd activity(两者可用的那个不一样)。
wlc_i=0
while [ "$wlc_i" -lt 10 ]; do
  if "$AM" start --user 0 -n "$ACT" >/dev/null 2>&1; then
    log "欢迎页: 已拉起(第 $((wlc_i + 1)) 次尝试,uptime $(uptime_s)s)"
    exit 0
  fi
  if "$CMDPKG" activity start-activity --user 0 -n "$ACT" >/dev/null 2>&1; then
    log "欢迎页: 已拉起(走 cmd activity,uptime $(uptime_s)s)"
    exit 0
  fi
  sleep 1
  wlc_i=$((wlc_i + 1))
done

log "欢迎页: 拉起失败(不影响开机;开机广播那条路还会再试一次)"
exit 0
