#!/system/bin/sh
# ============================================================================
#  Star OS · 网络优选 (netboost.sh)   —— Pro+ / 终身版专属
#  ===========================================================
#  统一工具协议见 tools/power.sh 开头。
#
#    · 测速优选:逐个 ping 公共 DNS,挑最快的那台
#    · 一键写入:把最优 DNS 写进系统(能用哪条通道就写哪条,写不动就说写不动)
#    · TCP 调优:开几个对移动网络更友好的内核开关
#
#  诚实声明:
#    写 DNS 有两条通道 —— setprop(老式)和 ndc resolver(8.1 上更靠谱)。
#    有些机型在联网后会自己覆盖回去,所以写完都读回来看一眼,以系统实际为准;
#    不吹"提速 300%"这种话,快不快跑一次测速自己看。
# ============================================================================

PWDIR=${0%/*}
[ -d "$PWDIR" ] || PWDIR=/data/adb/modules/zz_star_os
STAR=${STAR_DIR:-/data/adb/star_os}
ND=$STAR/netboost
LOG=$STAR/logs/netboost.log

mkdir -p "$ND" "$STAR/logs" 2>/dev/null

nb_log() { echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$LOG" 2>/dev/null; }

# 本地闸门(真值在台账,由应用联网核对后写入 pro.conf)
nb_tier() {
  nbg_v=0
  if [ -f "$STAR/pro.conf" ]; then
    nbg_v=$(sed -n 's/^tier=//p' "$STAR/pro.conf" 2>/dev/null | head -n 1)
  fi
  case "$nbg_v" in
    ''|*[!0-9]*) echo 0 ;;
    *) echo "$nbg_v" ;;
  esac
}

nb_gate() {
  [ "$(nb_tier)" -ge 2 ] && return 0
  echo "网络优选是 Pro+ / 终身版功能,当前等级不够" >&2
  return 5
}

# 候选 DNS(可覆盖,便于测试)
NB_DNS=${NETBOOST_DNS:-"223.5.5.5 119.29.29.29 114.114.114.114 180.76.76.76 8.8.8.8 1.1.1.1"}
NB_PING=${NETBOOST_PING:-ping}
NB_IPV4=${NETBOOST_IPV4_DIR:-/proc/sys/net/ipv4}

nb_getprop() { command -v getprop >/dev/null 2>&1 && getprop "$1" 2>/dev/null; }

# 单个 DNS 的往返延迟(ms);失败输出空
nb_ping_ms() {
  nb_out=$("$NB_PING" -c 1 -W 2 "$1" 2>/dev/null)
  nb_v=$(printf '%s' "$nb_out" | sed -n 's/.*time=\([0-9.]*\).*/\1/p' | head -n 1)
  printf '%s' "$nb_v"
}

nb_test() {
  echo "===== DNS 测速优选 ====="
  nb_best=""; nb_best_ms=""
  nb_2nd=""; nb_2nd_ms=""
  for nb_ip in $NB_DNS; do
    nb_ms=$(nb_ping_ms "$nb_ip")
    if [ -n "$nb_ms" ]; then
      printf '  %-16s %8s ms\n' "$nb_ip" "$nb_ms"
    else
      printf '  %-16s %8s\n' "$nb_ip" "不通"
    fi
    # 用整数比较(取整)避免小数比较的坑
    nb_i=${nb_ms%%.*}
    case "$nb_i" in ''|*[!0-9]*) continue ;; esac
    if [ -z "$nb_best_ms" ] || [ "$nb_i" -lt "$nb_best_ms" ]; then
      nb_2nd="$nb_best"; nb_2nd_ms="$nb_best_ms"
      nb_best="$nb_ip"; nb_best_ms="$nb_i"
    elif [ -z "$nb_2nd_ms" ] || [ "$nb_i" -lt "$nb_2nd_ms" ]; then
      nb_2nd="$nb_ip"; nb_2nd_ms="$nb_i"
    fi
  done
  echo ""
  if [ -z "$nb_best" ]; then
    echo "结论: 一台都 ping 不通 —— 先确认手表联网了(可先跑「网络体检」)。"
    return 1
  fi
  echo "最优 DNS : $nb_best (${nb_best_ms} ms)"
  [ -n "$nb_2nd" ] && echo "次选 DNS : $nb_2nd (${nb_2nd_ms} ms)"
  printf '%s\n' "$nb_best" > "$ND/best" 2>/dev/null
  printf '%s\n' "$nb_2nd" > "$ND/second" 2>/dev/null
  nb_log "test best=$nb_best(${nb_best_ms}ms) 2nd=$nb_2nd"
  return 0
}

nb_apply() {
  nb_best=$(cat "$ND/best" 2>/dev/null | tr -d ' \r\n')
  nb_2nd=$(cat "$ND/second" 2>/dev/null | tr -d ' \r\n')
  if [ -z "$nb_best" ]; then
    echo "还没测速,先点「测速优选」再写入。"
    return 1
  fi
  echo "===== 写入最优 DNS ====="
  echo "首选: $nb_best   次选: ${nb_2nd:-无}"
  echo ""

  nb_done=0
  if command -v setprop >/dev/null 2>&1; then
    setprop net.dns1 "$nb_best" 2>/dev/null && nb_done=1
    [ -n "$nb_2nd" ] && setprop net.dns2 "$nb_2nd" 2>/dev/null
    echo "通道1 setprop : 已尝试"
  else
    echo "通道1 setprop : 本机没有 setprop,跳过"
  fi

  if command -v ndc >/dev/null 2>&1; then
    ndc resolver setnetdns "" "$nb_best" "$nb_2nd" >/dev/null 2>&1 \
      && echo "通道2 ndc     : 已写入" || echo "通道2 ndc     : 写入失败"
  else
    echo "通道2 ndc     : 本机没有 ndc,跳过"
  fi

  echo ""
  echo "读回确认:"
  echo "  net.dns1 = $(nb_getprop net.dns1)"
  if [ "$nb_done" -eq 0 ]; then
    echo "  两条通道都没写成功 —— 这台机器的 DNS 由系统托管,改不了。"
  else
    echo "  注:部分机型联网后会用自己的 DNS 覆盖回去,以系统实际为准。"
  fi
  nb_log "apply dns1=$nb_best dns2=$nb_2nd"
  return 0
}

nb_tcp() {
  echo "===== TCP 参数调优 ====="
  for nb_kv in tcp_timestamps=1 tcp_sack=1 tcp_window_scaling=1 \
               tcp_tw_reuse=1 tcp_fin_timeout=30 tcp_keepalive_time=600; do
    nb_k=${nb_kv%%=*}
    nb_v=${nb_kv#*=}
    nb_f="$NB_IPV4/$nb_k"
    if [ -w "$nb_f" ]; then
      if echo "$nb_v" > "$nb_f" 2>/dev/null; then
        printf '  %-22s -> %s\n' "$nb_k" "$(cat "$nb_f" 2>/dev/null)"
      else
        printf '  %-22s 写失败,跳过\n' "$nb_k"
      fi
    else
      printf '  %-22s 不可写,跳过\n' "$nb_k"
    fi
  done
  echo ""
  echo "已尽量打开对移动网络友好的 TCP 开关(缺的节点说明这内核没有)。"
  return 0
}

nb_status() {
  echo "当前 DNS1 : $(nb_getprop net.dns1)"
  echo "当前 DNS2 : $(nb_getprop net.dns2)"
  echo "上次优选   : $(cat "$ND/best" 2>/dev/null || echo 还没测过)"
  echo ""
  echo "@item|测速,挑出最快的 DNS|act|test"
  echo "@item|把最快 DNS 写进系统|act|apply"
  echo "@item|打开 TCP 网络调优开关|act|tcp:ghost"
  return 0
}

case "$1" in
  meta)
    echo "netboost|网络优选|DNS 测速优选 + TCP 调优,让解析更快|2|test:测速优选:pri,apply:写入系统:pri,tcp:TCP 调优:ghost"
    ;;
  status)
    nb_status
    ;;
  act)
    nb_gate || exit $?
    case "$2" in
      test)  nb_test ;;
      apply) nb_apply ;;
      tcp)   nb_tcp ;;
      *)     echo "未知动作:$2" >&2; exit 2 ;;
    esac
    ;;
  *)
    echo "用法:$0 {meta|status|act <test|apply|tcp>}" >&2
    exit 2
    ;;
esac
