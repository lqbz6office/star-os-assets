#!/system/bin/sh
# ============================================================================
#  Star OS · 星眼 (eye.sh)   —— 基础功能(免费,人人可用)
#  ===========================================================
#  统一工具协议见 tools/power.sh 开头。
#
#  干的事:晚上看手表刺眼 —— 一键把亮度压到护眼档、切深色主题,
#        还能设「几点到几点自动开」,到点自动暗下来、到点自动还原。
#
#  为什么免费:护眼和续航一样是刚需,不该拿来卖。
#
#  和「续航管家(power)」的分工:
#    power 压亮度是为了省电,顺手还要关动画、清后台;
#    eye 只管"看得舒不舒服"(亮度 + 深色),不碰息屏/动画/后台。
#    两边各记各的快照,各自进出,互不干扰 —— 开了省电又开护眼也不会打架。
# ============================================================================

PWDIR=${0%/*}
[ -d "$PWDIR" ] || PWDIR=/data/adb/modules/zz_star_os
STAR=${STAR_DIR:-/data/adb/star_os}
EY=$STAR/eye
SNAP=$EY/snap.conf
MODE=$EY/mode
AUTO=$EY/auto.conf
LOG=$STAR/logs/eye.log

mkdir -p "$EY" "$STAR/logs" 2>/dev/null

ey_log() { echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$LOG" 2>/dev/null; }

# 护眼档亮度(255 制)。手表屏小,太暗就真看不清了,40 是留了余量的下限。
EY_BRIGHT=${EYE_BRIGHTNESS:-40}

ey_get() { settings get "$1" "$2" 2>/dev/null; }
ey_put() { settings put "$1" "$2" "$3" >/dev/null 2>&1; }

# ---------------------------------------------------------------- 基础读取
ey_brightness() {
  eyb_v=$(ey_get system screen_brightness)
  case "$eyb_v" in
    ''|null|*[!0-9]*) echo -1 ;;
    *) echo "$eyb_v" ;;
  esac
}

ey_mode() {
  eym_v=$(cat "$MODE" 2>/dev/null)
  case "$eym_v" in on) echo on ;; *) echo off ;; esac
}

# ---------------------------------------------------------------- 快照
# 进护眼前把原亮度/深色记下来,退出时一模一样还回去。
# (和 power 一样踩过的坑:不记的话,用户"关了护眼怎么还是暗的",最招骂)
ey_snapshot() {
  [ -f "$SNAP" ] && return 0
  true > "$SNAP"
  echo "brightness=$(ey_get system screen_brightness)" >> "$SNAP"
  echo "night=$(ey_get secure ui_night_mode)" >> "$SNAP"
  ey_log "snapshot: $(tr '\n' ' ' < "$SNAP")"
}

ey_snap_get() { sed -n "s/^$1=//p" "$SNAP" 2>/dev/null | head -n 1; }

# 值为空或 null 就不动,别把系统设置写坏
ey_restore_one() {
  eyr_v=$(ey_snap_get "$1")
  case "$eyr_v" in
    ''|null|*[!0-9]*) return 0 ;;
  esac
  ey_put "$2" "$3" "$eyr_v"
}

# ---------------------------------------------------------------- 动作
ey_on() {
  ey_snapshot
  ey_put system screen_brightness "$EY_BRIGHT"
  # 深色主题:8.1 上不一定生效,尽力而为 —— 无效只是"没变深色",不会出错
  ey_put secure ui_night_mode 2
  echo on > "$MODE"
  ey_log "护眼开启 (亮度 $EY_BRIGHT)"
}

ey_off() {
  ey_restore_one brightness system screen_brightness
  ey_restore_one night secure ui_night_mode
  echo off > "$MODE"
  ey_log "护眼关闭,已还原"
}

# ---------------------------------------------------------------- 定时
ey_auto_conf() {
  eyac_on=$(sed -n 's/^on=//p' "$AUTO" 2>/dev/null | head -n 1)
  eyac_s=$(sed -n 's/^start=//p' "$AUTO" 2>/dev/null | head -n 1)
  eyac_e=$(sed -n 's/^end=//p' "$AUTO" 2>/dev/null | head -n 1)
  case "$eyac_on" in 1) ;; *) eyac_on=0 ;; esac
  case "$eyac_s" in [0-2][0-9]:[0-5][0-9]) ;; *) eyac_s=22:00 ;; esac
  case "$eyac_e" in [0-2][0-9]:[0-5][0-9]) ;; *) eyac_e=07:00 ;; esac
  echo "$eyac_on $eyac_s $eyac_e"
}

ey_auto_set() {
  echo "on=$1" > "$AUTO"
  echo "start=$2" >> "$AUTO"
  echo "end=$3" >> "$AUTO"
}

# "22:30" -> 1350。用分钟数比大小,不靠字符串比较(ash 的 test 不保证支持 > <)
ey_hm2min() {
  eyh_h=${1%%:*}
  eyh_m=${1##*:}
  case "$eyh_h" in ''|*[!0-9]*) eyh_h=0 ;; esac
  case "$eyh_m" in ''|*[!0-9]*) eyh_m=0 ;; esac
  echo $((eyh_h * 60 + eyh_m))
}

# 当前时间落在 [start,end) 里吗(支持跨零点,如 22:00-07:00)
ey_in_window() {
  eyw_s=$(ey_hm2min "$1")
  eyw_e=$(ey_hm2min "$2")
  eyw_n=$(ey_hm2min "$(date '+%H:%M')")
  if [ "$eyw_s" -le "$eyw_e" ]; then
    [ "$eyw_n" -ge "$eyw_s" ] && [ "$eyw_n" -lt "$eyw_e" ] && return 0
    return 1
  fi
  [ "$eyw_n" -ge "$eyw_s" ] && return 0
  [ "$eyw_n" -lt "$eyw_e" ] && return 0
  return 1
}

# ---------------------------------------------------------------- 状态
ey_status() {
  eyc_b=$(ey_brightness)
  if [ "$eyc_b" -ge 0 ]; then
    echo "当前亮度:$eyc_b / 255"
  else
    echo "当前亮度:读不到"
  fi
  if [ "$(ey_mode)" = "on" ]; then
    echo "护眼:已开启 (亮度 $EY_BRIGHT + 深色)"
  else
    echo "护眼:关"
  fi
  eya=$(ey_auto_conf)
  eya1=$(echo "$eya" | cut -d' ' -f1)
  eya2=$(echo "$eya" | cut -d' ' -f2)
  eya3=$(echo "$eya" | cut -d' ' -f3)
  if [ "$eya1" = "1" ]; then
    echo "定时护眼:开 ($eya2 到 $eya3 自动开,过了自动关)"
  else
    echo "定时护眼:关"
  fi
  echo ""
  echo "@item|开/关护眼(亮度压到 $EY_BRIGHT + 深色)|act|night"
  if [ "$eya1" = "1" ]; then
    echo "@item|关掉定时护眼|act|auto"
  else
    echo "@item|定时护眼(22:00-07:00)|act|auto"
  fi
  return 0
}

case "$1" in
  meta)
    echo "eye|星眼|夜里看手表不刺眼,还能定时自动护眼|0|night:开/关护眼:pri,auto:定时护眼:ghost,dimmer:再暗一点:ghost,brighter:亮一点:ghost"
    ;;
  status)
    ey_status
    ;;
  act)
    case "$2" in
      night)
        if [ "$(ey_mode)" = "on" ]; then
          ey_off
          echo "护眼已关,亮度还原了"
        else
          ey_on
          echo "护眼已开:亮度压到 $EY_BRIGHT,深色主题已尝试打开"
          echo "点「开/关护眼」可以随时还原。"
        fi
        ;;
      auto)
        eya=$(ey_auto_conf)
        if [ "$(echo "$eya" | cut -d' ' -f1)" = "1" ]; then
          ey_auto_set 0 22:00 07:00
          echo "定时护眼:已关闭"
        else
          ey_auto_set 1 22:00 07:00
          echo "定时护眼:已开启"
          echo "每晚 22:00 自动开护眼,早上 07:00 自动还原。"
        fi
        ;;
      dimmer)
        eyc_b=$(ey_brightness)
        if [ "$eyc_b" -lt 0 ]; then echo "读不到当前亮度" >&2; exit 1; fi
        eyc_n=$((eyc_b - 20))
        [ "$eyc_n" -lt 5 ] && eyc_n=5
        ey_put system screen_brightness "$eyc_n"
        echo "亮度:$eyc_b -> $eyc_n"
        ;;
      brighter)
        eyc_b=$(ey_brightness)
        if [ "$eyc_b" -lt 0 ]; then echo "读不到当前亮度" >&2; exit 1; fi
        eyc_n=$((eyc_b + 20))
        [ "$eyc_n" -gt 255 ] && eyc_n=255
        ey_put system screen_brightness "$eyc_n"
        echo "亮度:$eyc_b -> $eyc_n"
        ;;
      *)
        echo "未知动作:$2" >&2
        exit 2
        ;;
    esac
    ;;
  tick)
    eya=$(ey_auto_conf)
    if [ "$(echo "$eya" | cut -d' ' -f1)" = "1" ]; then
      eya_s=$(echo "$eya" | cut -d' ' -f2)
      eya_e=$(echo "$eya" | cut -d' ' -f3)
      if ey_in_window "$eya_s" "$eya_e"; then
        if [ "$(ey_mode)" != "on" ]; then
          ey_on
          ey_log "定时:进入 $eya_s-$eya_e,自动开护眼"
        fi
      else
        if [ "$(ey_mode)" = "on" ]; then
          ey_off
          ey_log "定时:离开 $eya_s-$eya_e,自动关护眼"
        fi
      fi
    fi
    ;;
  daemon)
    ey_log "星眼 daemon 启动 (pid=$$)"
    while true; do
      "$0" tick >/dev/null 2>&1
      sleep 60
    done
    ;;
  *)
    echo "用法:$0 {meta|status|act <动作>|tick|daemon}" >&2
    exit 2
    ;;
esac
