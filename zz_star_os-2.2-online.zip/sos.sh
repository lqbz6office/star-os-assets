#!/system/bin/sh
##########################################################################
# sos.sh —— Star OS 插件 API(包装命令的实现)
#
# 插件【不应该】直接调底层系统命令,而是调这里注入的 sos-* 包装命令:
#     sos-fs-read   <路径> [输出文件]     需要 storage.read
#     sos-fs-write  <路径>                需要 storage.write(从 stdin 读内容)
#     sos-fs-list   <目录>                需要 storage.read
#     sos-http      <url> [输出文件]      需要 network
#     sos-notify    <标题> <内容>         需要 notify
#     sos-settings-get <命名空间> <键>    需要 settings.read
#     sos-settings-put <命名空间> <键> <值> 需要 settings.write
#     sos-getprop   <属性名>              需要 settings.read
#     sos-setprop   <属性名> <值>         需要 system.prop
#     sos-install-apk <apk路径>           需要 app.install
#     sos-log       <内容>                总是可用(写进插件自己的日志)
#     sos-perms                           总是可用(打印自己拿到的权限)
#     sos-id / sos-dir                    总是可用(插件自己的 id / 目录)
#     sos-pro                             总是可用(查询 Pro 授权:pro=1 tier=N)
#
# 权限从环境变量 $SOS_PERMS 读(由 plugin_exec.sh 在执行前注入)。
# 权限不足时:退出码 3 + stderr 一行说明,绝不放行。
#
# ⚠ 诚实声明(文档里也会写):
#   这一层是「契约式」约束 —— 插件拿了 shell 权限(真 root)之后,
#   理论上可以绕过 sos-* 直接调底层命令。真正拦住它的是三件事:
#     1. 上架审核(Windows 工具的静态扫描 + 人工看源码,源码全程公开);
#     2. 安装授权时把 shell 明确标成「完全控制」,默认不勾;
#     3. 本层的权限检查(对没授权 shell 的插件是硬的)。
#   在 root 模块里做不到内核级沙箱,我们不假装能。
##########################################################################

SOS_API_VER=1

c_err() { echo "sos: $*" >&2; }

# 权限检查:$1=需要的权限
c_need() {
  case ",$SOS_PERMS," in
    *",$1,"*) return 0 ;;
    *) c_err "缺少权限 $1 —— 插件清单里声明它,并在 Star OS 应用里授权后才能用" ; return 3 ;;
  esac
}

# 路径必须落在内部存储里(防止插件到处乱读)
c_sdcard_path() {
  case "$1" in
    /data/media/0/*|/sdcard/*|/storage/emulated/0/*) return 0 ;;
    *) c_err "只允许操作内部存储(/sdcard): $1" ; return 4 ;;
  esac
}

c_cmd=$1
shift 2>/dev/null

case "$c_cmd" in

  # ---------------- 元信息(无需权限) ----------------
  perms)
    echo "${SOS_PERMS:-}"
    ;;
  id)
    echo "${SOS_ID:-}"
    ;;
  dir)
    echo "${SOS_DIR:-}"
    ;;
  api)
    echo "$SOS_API_VER"
    ;;

  pro)
    # Pro 授权状态。故意不设权限门槛:这只是一个等级数字,
    # 插件在「还没被授权任何东西」时也需要能判断要不要展示 Pro 功能。
    # 配置文件由手表端应用在激活时写入(见 License/PluginActivity)。
    # ⚠ 优先用执行器注入的变量:降权插件(uid 2000)穿得进目录也读不了
    #   pro.conf(root 600),老实现会误报 pro=0;文件直读仅 root 兜底。
    if [ -n "${SOS_PRO:-}" ]; then
      echo "pro=$SOS_PRO tier=${SOS_TIER:-0} device=${SOS_DEVICE:-}"
    elif [ -f /data/adb/star_os/pro.conf ]; then
      p_tier=$(sed -n 's/^tier=//p' /data/adb/star_os/pro.conf 2>/dev/null | head -n 1)
      p_dev=$(sed -n 's/^device=//p' /data/adb/star_os/pro.conf 2>/dev/null | head -n 1)
      p_exp=$(sed -n 's/^expiry=//p' /data/adb/star_os/pro.conf 2>/dev/null | head -n 1 | tr -d '-')
      if [ -n "$p_exp" ]; then
        p_today=$(date +%Y%m%d 2>/dev/null)
        case "$p_today" in *[!0-9]*|"") p_today="" ;; esac
        if [ -n "$p_today" ] && [ "$p_today" -gt "$p_exp" ]; then
          echo "pro=0 tier=0 device=${p_dev:-} expired=$p_exp"
          exit 0
        fi
      fi
      case "${p_tier:-0}" in *[!0-9]*|"") p_tier=0 ;; esac
      [ "$p_tier" -ge 1 ] && p_pro=1 || p_pro=0
      echo "pro=$p_pro tier=${p_tier:-0} device=${p_dev:-}"
    else
      echo "pro=0 tier=0"
    fi
    ;;

  proexpire)
    # 到期自动取消授权:pro.conf 里 expiry=YYYY-MM-DD 过了就把 tier 归零。
    # 由 service.sh 每天跑一次;读取方(sos.sh pro / plugin_exec 注入)也会
    # 即时判定,这里只是把文件本身改掉,让所有直读 pro.conf 的脚本一致。
    p_f=/data/adb/star_os/pro.conf
    [ -f "$p_f" ] || exit 0
    p_exp=$(sed -n 's/^expiry=//p' "$p_f" 2>/dev/null | head -n 1 | tr -d '-')
    [ -n "$p_exp" ] || exit 0
    p_today=$(date +%Y%m%d 2>/dev/null)
    case "$p_today" in *[!0-9]*|"") exit 0 ;; esac
    if [ "$p_today" -gt "$p_exp" ]; then
      sed -i 's/^tier=.*/tier=0/' "$p_f" 2>/dev/null
      echo "expired=$p_exp"
    fi
    ;;

  log)
    # 写进插件自己的日志(plugin_exec.sh 已经把 stdout 重定向过去了)
    echo "[sos] $*"
    ;;

  # ---------------- 文件 ----------------
  fs-read)
    c_need storage.read || exit $?
    c_sdcard_path "$1" || exit $?
    [ -f "$1" ] || { c_err "文件不存在: $1"; exit 5; }
    if [ -n "$2" ]; then cat "$1" > "$2"; echo "OK $1 -> $2"; else cat "$1"; fi
    ;;

  fs-list)
    c_need storage.read || exit $?
    c_sdcard_path "$1" || exit $?
    [ -d "$1" ] || { c_err "目录不存在: $1"; exit 5; }
    ls -la "$1"
    ;;

  fs-write)
    c_need storage.write || exit $?
    c_sdcard_path "$1" || exit $?
    mkdir -p "$(dirname "$1")" 2>/dev/null
    cat > "$1" || { c_err "写入失败: $1"; exit 5; }
    echo "OK 已写入 $1"
    ;;

  # ---------------- 网络 ----------------
  http)
    c_need network || exit $?
    case "$1" in http://*|https://*) ;; *) c_err "只支持 http/https"; exit 4 ;; esac
    if command -v curl >/dev/null 2>&1; then
      if [ -n "$2" ]; then curl -sSL -o "$2" "$1"; else curl -sSL "$1"; fi
    elif command -v wget >/dev/null 2>&1; then
      if [ -n "$2" ]; then wget -q -O "$2" "$1"; else wget -q -O - "$1"; fi
    else
      c_err "本机没有 curl/wget"; exit 5
    fi
    ;;

  # ---------------- 提示 ----------------
  notify)
    c_need notify || exit $?
    if command -v cmd >/dev/null 2>&1; then
      cmd notification post -S bigtext -t "${1:-Star OS}" staros_plugin "$2" >/dev/null 2>&1
    fi
    echo "OK"
    ;;

  # ---------------- 系统设置 ----------------
  settings-get)
    c_need settings.read || exit $?
    /system/bin/settings get "$1" "$2" 2>/dev/null
    ;;

  settings-put)
    c_need settings.write || exit $?
    /system/bin/settings put "$1" "$2" "$3" >/dev/null 2>&1
    echo "OK"
    ;;

  # ---------------- 系统属性 ----------------
  getprop)
    c_need settings.read || exit $?
    getprop "$1"
    ;;

  setprop)
    c_need system.prop || exit $?
    # 必须用 resetprop:真 build.prop 是只读分区,setprop 改了也白改
    if command -v resetprop >/dev/null 2>&1; then
      resetprop "$1" "$2" && echo "OK"
    elif [ -x "$SOS_MODDIR/system/bin/resetprop" ]; then
      "$SOS_MODDIR/system/bin/resetprop" "$1" "$2" && echo "OK"
    else
      c_err "resetprop 不可用(需要 Magisk)"
      exit 5
    fi
    ;;

  # ---------------- 装应用 ----------------
  install-apk)
    c_need app.install || exit $?
    [ -f "$1" ] || { c_err "APK 不存在: $1"; exit 5; }
    /system/bin/pm install -r -d "$1" 2>&1
    ;;

  ''|help|-h|--help)
    sed -n '2,30p' "$0"
    ;;

  *)
    c_err "未知子命令: $c_cmd"
    exit 1
    ;;
esac

exit 0
