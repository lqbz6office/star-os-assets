#!/system/bin/sh
# ============================================================================
#  Star OS · 表盘工坊 (starface.sh)   —— Pro+ / 终身版专属
#  ============================================================
#  手表上的"换装间":表盘 / 壁纸 / 图标包 三样素材,一键投放或撤下。
#
#  投放到哪儿(和主题应用 ThemePro 读的是同一处):
#      <内部存储>/Android/baiyao105/ThemePro/Themes/
#          dial/<名>.cl            表盘本体(本质是个 APK)
#          dial/res/<名>/*.png     表盘的三张预览图
#          theme_pack/<名>/        整套主题(壁纸 + 图标包 + 表盘配置)
#
#  素材库(下载/导入过来的包都堆这儿,不动系统):
#      /data/adb/star_os/face/
#          dial/<名>/<名>.cl + res/<名>/*.png
#          pack/<名>/...
#
#  ⚠ 为什么投放前要备份:这些目录里本来就有原厂/别人的素材,直接覆盖就找不
#    回来了。凡是"本来不存在"的东西撤下时直接删;凡是"本来存在"的,撤下时
#    从 .backup/ 还回去 —— 不误删、不残留。
#
#  用法:
#     starface.sh list [dial|pack]      列出素材库(id|类型|大小|是否已投放|档位)
#     starface.sh installed             列出 Themes 下当前已投放的
#     starface.sh apply dial <名>
#     starface.sh apply pack <名>
#     starface.sh remove dial <名>
#     starface.sh remove pack <名>
#     starface.sh fetch <id>            从官方源下一个表盘(连 res 三件套一起)
#     starface.sh remote                列出在线表盘源
#     starface.sh res [名]              补 dial/res/<名>/ 三件套(修"加载不出来")
#     starface.sh import <zip>          导入一个素材包到库里
#     starface.sh info <名>
#
#  ⚠ 投放后必须让主题应用重扫:ThemePro 把本地表盘列表缓存在自己数据里,
#    光把 .cl 拷进 Themes/dial/ 是看不到、也切不过去的(官方装主题时同样要
#    `pm clear com.xtc.theme`)。这里用 dialstore 的广播让它重扫,比 pm clear 温和。
# ============================================================================

SFDIR=${0%/*}
[ -d "$SFDIR" ] || SFDIR=/data/adb/modules/zz_star_os
STAR=/data/adb/star_os
LIB=$STAR/face
BAK=$LIB/.backup
LOG=$STAR/logs/starface.log

mkdir -p "$LIB/dial" "$LIB/pack" "$BAK" "$STAR/logs" 2>/dev/null

sf_log() { echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$LOG" 2>/dev/null; }

# Pro+ / 终身版门槛(本地闸门;真值在台账,由应用联网核对)
sf_tier() {
  sfg_v=0
  if [ -f "$STAR/pro.conf" ]; then
    sfg_v=$(sed -n 's/^tier=//p' "$STAR/pro.conf" 2>/dev/null | head -n 1)
  fi
  case "$sfg_v" in
    ''|*[!0-9]*) echo 0 ;;
    *) echo "$sfg_v" ;;
  esac
}

sf_gate() {
  [ "$(sf_tier)" -ge 2 ] && return 0
  echo "表盘工坊是 Pro+ / 终身版功能,当前等级不够" >&2
  return 5
}

# 在线表盘按**这个表盘自己的档位**放行:
#   免费档(0)—— 任何人都能下载和投放;
#   Pro+ 档(2)—— 才要等级 ≥2。
# 为什么要分档:不是所有表盘都该锁在 Pro+ 后面,免费的那几个是给所有
# 用户的门面。档位真值在云端(dials/index.json 与各表盘的 meta.json),
# 这里读的是随表盘一起下下来的 tier 标记。
sf_gate_dial() {
  sfgd_t=$1
  case "$sfgd_t" in
    ''|*[!0-9]*) sfgd_t=0 ;;
  esac
  [ "$sfgd_t" -lt 2 ] && return 0
  [ "$(sf_tier)" -ge 2 ] && return 0
  echo "这个表盘是 Pro+ 专属,当前等级不够(免费表盘不受影响)" >&2
  return 5
}

# 素材库里某个表盘记着的档位(fetch 时写进来的)。读不到当免费。
sf_dial_tier() {
  sfdtt_f="$LIB/dial/${1:-}/tier"
  sfdtt_v=""
  [ -f "$sfdtt_f" ] && sfdtt_v=$(head -n 1 "$sfdtt_f" 2>/dev/null)
  case "$sfdtt_v" in
    ''|*[!0-9]*) echo 0 ;;
    *) echo "$sfdtt_v" ;;
  esac
}

# ---------------------------------------------------------------------------
# 机型闸门
#
# 表盘本体(.cl)本质是给「表盘引擎」读的资源包 —— 4100 的是 320x360,引擎按
# 资源名/尺寸取值。W5 是 416x468、系统还是安卓 11,引擎不是同一套,把 4100 的
# .cl 投上去大概率是黑表盘。所以 W5 上:不提供在线源(源里全是 4100 的),
# 自己 import 的仍可投放,但会提醒一句风险。
# 壁纸/图标包(pack)只是图片,不做机型限制。
# ---------------------------------------------------------------------------
SF_MODEL=4100
[ -f "${0%/*}/model.conf" ] && . "${0%/*}/model.conf" 2>/dev/null
SF_MODEL=${MODEL:-4100}

sf_is_w5() {
  [ "$SF_MODEL" = "w5" ] && return 0
  return 1
}

sf_dial_src_reason() {
  echo "在线表盘源里全是 4100(320x360) 的表盘,和 W5(416x468) 的表盘引擎不通用。" >&2
  echo "W5 能用的表盘素材需要单独做;自己做好的 .cl 可以用 starface.sh import 导进来。" >&2
}

# ---------------------------------------------------------------------------
# 内部存储与 Themes 根
# ---------------------------------------------------------------------------
sf_sd() {
  sfs_p="${STARFACE_SD_ROOT:-}"
  if [ -z "$sfs_p" ]; then
    for sfs_c in /sdcard /storage/emulated/0 /data/media/0; do
      if [ -d "$sfs_c/Android" ]; then sfs_p="$sfs_c"; break; fi
    done
  fi
  [ -n "$sfs_p" ] || { echo ""; return 1; }
  echo "$sfs_p"
}

sf_themes() {
  sft_sd=$(sf_sd) || return 1
  echo "$sft_sd/Android/baiyao105/ThemePro/Themes"
}

sf_du() {
  # 人类可读大小(没有 du 就报文件数)
  sfd_s=$(du -sk "$1" 2>/dev/null | head -n 1 | cut -f1)
  if [ -n "$sfd_s" ]; then
    sfd_k=$((sfd_s + 0))
    if [ "$sfd_k" -ge 1024 ]; then
      echo "$((sfd_k / 1024))MB"
    else
      echo "${sfd_k}KB"
    fi
  else
    echo "?"
  fi
}

# ---------------------------------------------------------------------------
# 夺舍:我们的表盘 -> 官方表盘位(宿主)
#
# 系统/主题应用认的是官方那一套:官方 68 个表盘里 67 个都是
# 「文件名 == 内部包名末段」(greenpoint.cl -> com.xtc.greenpoint)。
# 我们换皮出来的 .cl 沿用了模板包名(star-aurora.cl -> com.xtc.sky2021),
# 文件名与包名对不上 ⇒ 系统不认 ⇒ 商店里"加载不出来"、投放也不生效。
#
# 办法:投放时**改成宿主名**(Themes/dial/sky2021.cl + res/sky2021/),
# 顶掉官方那个位子。官方原版会先被 sf_backup 备份,"撤下"即可原样还回去。
# 映射表在远端 dials/hosts.txt(由 _gen_hosts.py 生成),下到 $LIB/.hosts.txt 缓存。
# ---------------------------------------------------------------------------
sf_host_cache() {
  # 确保 $LIB/.hosts.txt 就绪(拿不到就返回 1,调用方按"不夺舍"处理)
  sfhz_f="$LIB/.hosts.txt"
  [ -s "$sfhz_f" ] && return 0
  sf_dl "dials/hosts.txt" "$sfhz_f.tmp" >/dev/null 2>&1 || return 1
  [ -s "$sfhz_f.tmp" ] || return 1
  mv -f "$sfhz_f.tmp" "$sfhz_f" 2>/dev/null
  [ -s "$sfhz_f" ] && return 0
  return 1
}

sf_host_raw() {
  # 只查映射(会触发一次 hosts.txt 下载),不落素材库 —— 展示用
  sfhr_n=$1
  [ -n "$sfhr_n" ] || return 1
  sf_host_cache || return 1
  sed -n "s/^${sfhr_n}[[:space:]][[:space:]]*\([^[:space:]]*\).*/\1/p" \
      "$LIB/.hosts.txt" 2>/dev/null | head -n 1
  return 0
}

sf_host_of() {
  # 投放用:素材库自带的 host 文件优先,其次远端映射,最后兜底=原名(不夺舍)
  sfh_n=$1
  [ -n "$sfh_n" ] || return 1
  if [ -s "$LIB/dial/$sfh_n/host" ]; then
    sfh_v=$(tr -d ' \t\r\n' < "$LIB/dial/$sfh_n/host" 2>/dev/null)
    [ -n "$sfh_v" ] && { printf '%s\n' "$sfh_v"; return 0; }
  fi
  sfh_v=$(sf_host_raw "$sfh_n")
  if [ -n "$sfh_v" ]; then
    mkdir -p "$LIB/dial/$sfh_n" 2>/dev/null
    printf '%s\n' "$sfh_v" > "$LIB/dial/$sfh_n/host" 2>/dev/null
    printf '%s\n' "$sfh_v"
    return 0
  fi
  printf '%s\n' "$sfh_n"
  return 0
}

# host -> 我们的 id(反查,让"已投放"列表能说人话)
sf_id_of() {
  sfio_h=$1
  [ -n "$sfio_h" ] || return 1
  sf_host_cache >/dev/null 2>&1 || return 1
  sed -n "s/^\([^[:space:]]*\)[[:space:]][[:space:]]*${sfio_h}\$/\1/p" \
      "$LIB/.hosts.txt" 2>/dev/null | head -n 1
  return 0
}

# 是不是已经投放了
sf_deployed() {
  # $1=类型 $2=名
  sfd_t=$(sf_themes) || { echo 0; return; }
  case "$1" in
    dial) [ -f "$sfd_t/dial/$(sf_host_of "$2").cl" ] && echo 1 || echo 0 ;;
    pack) [ -d "$sfd_t/theme_pack/$2" ] && echo 1 || echo 0 ;;
    *) echo 0 ;;
  esac
}

# ---------------------------------------------------------------------------
# 备份 / 还原
# ---------------------------------------------------------------------------
sf_backup() {
  # $1=类型 $2=名 —— 只在"原本就存在"时备份一次
  sfb_t=$(sf_themes) || return 0
  sfb_k="$1__$2"
  [ -e "$BAK/$sfb_k.flag" ] && return 0
  case "$1" in
    dial)
      if [ -f "$sfb_t/dial/$2.cl" ]; then
        mkdir -p "$BAK/dial" 2>/dev/null
        cp -f "$sfb_t/dial/$2.cl" "$BAK/dial/$2.cl" 2>/dev/null
        [ -d "$sfb_t/dial/res/$2" ] && {
          mkdir -p "$BAK/dial/res" 2>/dev/null
          cp -r "$sfb_t/dial/res/$2" "$BAK/dial/res/" 2>/dev/null
        }
        echo existed > "$BAK/$sfb_k.flag" 2>/dev/null
      else
        echo absent > "$BAK/$sfb_k.flag" 2>/dev/null
      fi
      ;;
    pack)
      if [ -d "$sfb_t/theme_pack/$2" ]; then
        mkdir -p "$BAK/pack" 2>/dev/null
        cp -r "$sfb_t/theme_pack/$2" "$BAK/pack/" 2>/dev/null
        echo existed > "$BAK/$sfb_k.flag" 2>/dev/null
      else
        echo absent > "$BAK/$sfb_k.flag" 2>/dev/null
      fi
      ;;
  esac
  return 0
}

sf_restore_one() {
  # $1=类型 $2=名
  sfr_t=$(sf_themes) || return 1
  sfr_k="$1__$2"
  sfr_st=$(cat "$BAK/$sfr_k.flag" 2>/dev/null)
  case "$sfr_st" in
    existed)
      case "$1" in
        dial)
          cp -f "$BAK/dial/$2.cl" "$sfr_t/dial/$2.cl" 2>/dev/null
          [ -d "$BAK/dial/res/$2" ] && cp -rf "$BAK/dial/res/$2" "$sfr_t/dial/res/" 2>/dev/null
          ;;
        pack)
          mkdir -p "$sfr_t/theme_pack" 2>/dev/null
          cp -rf "$BAK/pack/$2" "$sfr_t/theme_pack/" 2>/dev/null
          ;;
      esac
      sf_log "restore $1/$2 (还原原有素材)"
      ;;
    *)
      # 本来就是没有的 → 撤下 = 删掉自己投放的那份
      case "$1" in
        dial) rm -f "$sfr_t/dial/$2.cl" 2>/dev/null
              rm -rf "$sfr_t/dial/res/$2" 2>/dev/null ;;
        pack) rm -rf "$sfr_t/theme_pack/$2" 2>/dev/null ;;
      esac
      sf_log "restore $1/$2 (本来不存在,已清除)"
      ;;
  esac
  rm -f "$BAK/$sfr_k.flag" 2>/dev/null
  return 0
}

# ---------------------------------------------------------------------------
# 投放
# ---------------------------------------------------------------------------
sf_apply_dial() {
  sfa_n=$1
  sf_is_w5 && echo "⚠ 本机是 W5(416x468):如果这个表盘是 4100(320x360) 的,可能显示异常" >&2
  sfa_src="$LIB/dial/$sfa_n"
  [ -f "$sfa_src/$sfa_n.cl" ] || { echo "库里没有这个表盘: $sfa_n" >&2; return 3; }
  sfa_t=$(sf_themes) || { echo "找不到内部存储" >&2; return 4; }

  # 老版本的库里没有 res/<名>/ 三件套(表盘商店会"加载不出来"),投放时顺手补齐
  sf_res_ensure "$sfa_n"

  # 夺舍:投放成宿主名(官方表盘位)—— 文件名与内部包名末段一致,系统才认
  sfa_h=$(sf_host_of "$sfa_n")
  [ -n "$sfa_h" ] || sfa_h="$sfa_n"

  sf_backup dial "$sfa_h"
  mkdir -p "$sfa_t/dial/res/$sfa_h" 2>/dev/null
  cp -f "$sfa_src/$sfa_n.cl" "$sfa_t/dial/$sfa_h.cl" 2>/dev/null || {
    echo "复制表盘失败" >&2; return 5; }
  sfa_res=0
  for sfa_f in all_background.png preview_launcher.png preview_main.png; do
    if [ -s "$sfa_src/res/$sfa_n/$sfa_f" ]; then
      cp -f "$sfa_src/res/$sfa_n/$sfa_f" "$sfa_t/dial/res/$sfa_h/$sfa_f" 2>/dev/null && \
        sfa_res=$((sfa_res + 1))
    fi
  done
  # 清掉旧版残留(以前按 id 投放的那份;夺舍后名不同,不清会在商店里多出一张坏卡片)
  if [ "$sfa_h" != "$sfa_n" ]; then
    rm -f "$sfa_t/dial/$sfa_n.cl" 2>/dev/null
    rm -rf "$sfa_t/dial/res/$sfa_n" 2>/dev/null
  fi
  sf_log "apply dial $sfa_n -> $sfa_t/dial/$sfa_h.cl (host=$sfa_h res=$sfa_res)"
  # 拷完要让主题应用重扫,否则商店里看不到、表盘也不会真的切过去
  sf_refresh_themes
  sf_switch_now "$sfa_h"
  echo "ok dial $sfa_n host=$sfa_h"
  if [ "$sfa_h" != "$sfa_n" ]; then
    echo "(已占用官方表盘位:$sfa_h —— 原来那个被顶掉,点「撤下」可原样还原)"
  fi
  return 0
}

sf_apply_pack() {
  sfa_n=$1
  sfa_src="$LIB/pack/$sfa_n"
  [ -d "$sfa_src" ] || { echo "库里没有这个主题包: $sfa_n" >&2; return 3; }
  sfa_t=$(sf_themes) || { echo "找不到内部存储" >&2; return 4; }

  sf_backup pack "$sfa_n"
  mkdir -p "$sfa_t/theme_pack" 2>/dev/null
  cp -rf "$sfa_src" "$sfa_t/theme_pack/" 2>/dev/null || {
    echo "复制主题包失败" >&2; return 5; }
  sf_log "apply pack $sfa_n -> $sfa_t/theme_pack"
  echo "ok pack $sfa_n"
  return 0
}

# ---------------------------------------------------------------------------
# 导入素材包(zip;插件下载完调这个)
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# 在线表盘源(Star OS 官方)
# ---------------------------------------------------------------------------
SF_REPO=lqbz6office/star-os-assets

# 下载:优先 curl,退回 wget;相对路径 jsDelivr 优先(国内可达),raw 兜底
#
# ⚠ Android 8.1 的系统里既没有 curl,toybox 也没有 wget(那是 10+ 才有)——
#   只试这两个等于"永远下不动"。必须退回 Magisk 自带的 busybox(编了 wget + TLS)。
sf_dl() {
  sfd_rel=$1
  sfd_out=$2
  sfd_curl() {
    command -v curl >/dev/null 2>&1 || return 1
    curl -f -L -sS --max-time 900 -o "$sfd_out" "$1" >/dev/null 2>&1
  }
  sfd_wget() {
    command -v wget >/dev/null 2>&1 || return 1
    wget -q -O "$sfd_out" "$1" >/dev/null 2>&1
  }
  sfd_bb() {
    sfd_b=""
    for sfd_cand in /data/adb/magisk/busybox /sbin/.magisk/busybox \
                    /data/adb/ksu/bin/busybox /system/xbin/busybox; do
      [ -x "$sfd_cand" ] && { sfd_b="$sfd_cand"; break; }
    done
    [ -n "$sfd_b" ] || return 1
    "$sfd_b" wget -q -O "$sfd_out" "$1" >/dev/null 2>&1
  }
  sfd_try() {
    sfd_curl "$1" && return 0
    sfd_wget "$1" && return 0
    sfd_bb "$1" && return 0
    return 1
  }
  case "$sfd_rel" in
    http*)
      sfd_try "$sfd_rel" && return 0
      return 1 ;;
    *)
      sfd_try "https://cdn.jsdelivr.net/gh/$SF_REPO@main/$sfd_rel" && return 0
      sfd_try "https://raw.githubusercontent.com/$SF_REPO/main/$sfd_rel" && return 0
      return 1 ;;
  esac
}

# ---------------------------------------------------------------------------
# 表盘的 res/<名>/ 三件套
#
# ThemePro 的表盘列表读的是 dial/res/<名>/ 下的三张图:
#     all_background.png   320x360  全屏背景
#     preview_main.png     320x360  预览(带时间的那张)
#     preview_launcher.png 200x225  桌面预览
# 官方 9 个表盘这三张都齐;**少了它们,主题/表盘商店里的卡片就是"加载不出来"的
# 样子**,点进去也加载不了 —— 踩过,别省。
# ---------------------------------------------------------------------------
sf_res_ensure() {
  sfra_n=$1
  sfra_d="$LIB/dial/$sfra_n/res/$sfra_n"
  sfra_need=0
  for sfra_f in all_background.png preview_launcher.png preview_main.png; do
    [ -s "$sfra_d/$sfra_f" ] || sfra_need=1
  done
  [ "$sfra_need" = "0" ] && return 0
  mkdir -p "$sfra_d" 2>/dev/null
  for sfra_f in all_background.png preview_launcher.png preview_main.png; do
    [ -s "$sfra_d/$sfra_f" ] && continue
    sf_dl "dials/$sfra_n/res/$sfra_n/$sfra_f" "$sfra_d/$sfra_f" || \
      rm -f "$sfra_d/$sfra_f" 2>/dev/null
  done
  return 0
}

# 让主题应用重新扫主题库。
# ⚠ 为什么非刷不可:ThemePro 自己装主题时都要 `pm clear com.xtc.theme`,说明它把
#   本地表盘列表缓存在自己的数据里 —— 光把 .cl 拷进 Themes/dial/,商店里看不到、
#   或者卡片是坏的。这里用广播让它重扫(比 pm clear 温和,不会清掉用户已有主题)。
sf_refresh_themes() {
  command -v am >/dev/null 2>&1 || return 0
  for sfrf_a in com.xtc.dialstore.action.update_local_dial \
                com.xtc.dialstore.action.REMOVE_DIAL_CACHE; do
    am broadcast -a "$sfrf_a" >/dev/null 2>&1
  done
  sf_log "refresh themes"
  return 0
}

# 尽力让系统立刻切到刚投放的表盘(主题应用内部用的就是这个广播)。
# 失败/没反应都无所谓 —— 去表盘商店里点一下也一样,所以永远返回 0。
sf_switch_now() {
  sfsn_n=$1
  sfsn_t=$(sf_themes) || return 0
  command -v am >/dev/null 2>&1 || return 0
  am broadcast -a com.xtc.dialstore.action.CLOCK_CHANGE \
    --es dial_name "$sfsn_n" --es dialName "$sfsn_n" \
    --es dialId "$sfsn_n" --es dial_path "$sfsn_t/dial/$sfsn_n.cl" \
    >/dev/null 2>&1
  sf_log "clock_change $sfsn_n"
  return 0
}

# 从在线表盘源拉一个表盘进素材库(装完就能 apply)
sf_fetch() {
  sff_id=$1
  [ -n "$sff_id" ] || { echo "用法: starface.sh fetch <表盘id|完整URL>" >&2; exit 2; }
  if sf_is_w5; then
    sf_dial_src_reason
    exit 6
  fi
  sff_t=0
  case "$sff_id" in
    http*)
      # 自己给 URL = 自制表盘,仍按 Pro+ 算(来源不明,不享受免费档)
      sf_gate || exit 5
      sff_url="$sff_id" ;;
    *[!a-z0-9-]*)
      echo "表盘 id 只能是小写字母、数字与横线: $sff_id" >&2
      exit 2 ;;
    *)
      sff_url="dials/$sff_id/$sff_id.cl"
      # 按**这个表盘自己的档位**放行:先花几百字节读它的 meta.json。
      # 读不到就当免费(宁松不严)—— 免费表盘是给所有人的,别因为一次网络
      # 抖动就把用户挡在外面;真正的商业闸门在云端索引侧。
      sff_meta="/data/local/tmp/.sos_dial_meta_$$"
      if sf_dl "dials/$sff_id/meta.json" "$sff_meta"; then
        sff_tv=$(sed -n 's/.*"tier"[[:space:]]*:[[:space:]]*\([0-9][0-9]*\).*/\1/p' \
                 "$sff_meta" 2>/dev/null | head -n 1)
        [ -n "$sff_tv" ] && sff_t="$sff_tv"
      fi
      rm -f "$sff_meta" 2>/dev/null
      sf_gate_dial "$sff_t" || exit 5 ;;
  esac
  mkdir -p "$LIB/dial/$sff_id" 2>/dev/null
  sff_out="$LIB/dial/$sff_id/$sff_id.cl"
  echo "正在下载表盘:$sff_id"
  if ! sf_dl "$sff_url" "$sff_out"; then
    echo "下载失败 —— 检查网络,或先用浏览器下好再 import" >&2
    sf_log "fetch $sff_id 失败"
    exit 4
  fi
  sff_sz=$(wc -c < "$sff_out" 2>/dev/null | tr -d ' ')
  if [ -z "$sff_sz" ] || [ "$sff_sz" -lt 1024 ]; then
    echo "下下来的文件不对(${sff_sz:-0} 字节),已丢弃" >&2
    rm -f "$sff_out" 2>/dev/null
    exit 4
  fi
  # 预览图有就顺带拉,没有不影响
  sf_dl "dials/$sff_id/preview.png" "$LIB/dial/$sff_id/preview.png" || true
  # ThemePro 规范要的三件套:少了它,表盘商店里这个盘就是"加载不出来"
  sf_res_ensure "$sff_id"
  # 记下档位:之后 apply / remove 凭它放行(免费表盘不查等级)
  printf '%s\n' "$sff_t" > "$LIB/dial/$sff_id/tier" 2>/dev/null
  # 记下夺舍宿主:投放时会用它当文件名,才能和内部包名末段一致被系统认下
  sff_h=$(sf_host_raw "$sff_id")
  [ -n "$sff_h" ] && printf '%s\n' "$sff_h" > "$LIB/dial/$sff_id/host" 2>/dev/null
  echo "已导入表盘:$sff_id ($sff_sz 字节)"
  [ "$sff_t" -lt 2 ] && echo "(免费表盘)" || echo "(Pro+ 表盘)"
  [ -n "$sff_h" ] && [ "$sff_h" != "$sff_id" ] && \
    echo "(投放时会占用官方表盘位:$sff_h)"
  echo "接着可以:starface.sh apply dial $sff_id"
  sf_log "fetch $sff_id $sff_sz"
  return 0
}

# 列出在线表盘源里有哪些(读发布时生成的扁平列表 list.txt,8.1 上没法解析 JSON)
sf_remote() {
  if sf_is_w5; then
    sf_dial_src_reason
    exit 6
  fi
  sfr_tmp="/data/local/tmp/.sos_dial_list_$$"
  if ! sf_dl "dials/list.txt" "$sfr_tmp"; then
    echo "读不到在线表盘源(网络问题)" >&2
    exit 4
  fi
  echo "在线表盘源:"
  sf_host_cache >/dev/null 2>&1
  sfr_n=0
  while IFS= read -r sfr_l; do
    [ -n "$sfr_l" ] || continue
    sfr_n=$((sfr_n + 1))
    sfr_id=${sfr_l%%|*}
    sfr_h=$(sed -n "s/^${sfr_id}[[:space:]][[:space:]]*\([^[:space:]]*\).*/\1/p" \
            "$LIB/.hosts.txt" 2>/dev/null | head -n 1)
    echo "$sfr_l|$sfr_h"
  done < "$sfr_tmp"
  echo "共 $sfr_n 个 —— 每行是 id|名称|说明|大小|档位(0=免费 2=Pro+)|官方宿主"
  echo "免费的谁都能装;Pro+ 的要等级够。fetch <id> 下载"
  echo "「官方宿主」= 投放时会占用(顶掉)的那个官方表盘位,撤下即可还原"
  rm -f "$sfr_tmp" 2>/dev/null
}

sf_import() {
  sfi_z=$1
  [ -f "$sfi_z" ] || { echo "没有这个文件: $sfi_z" >&2; return 3; }

  sfi_un=""
  if command -v unzip >/dev/null 2>&1; then
    sfi_un=unzip
  else
    for sfi_b in /data/adb/magisk/busybox /sbin/.magisk/busybox \
                 /data/adb/ksu/bin/busybox /system/xbin/busybox; do
      [ -x "$sfi_b" ] && { sfi_un="$sfi_b unzip"; break; }
    done
  fi
  [ -n "$sfi_un" ] || { echo "没有解压工具(8.1 不自带 unzip,也没找到 busybox)" >&2; return 4; }

  sfi_tmp="$STAR/tmp_face"
  rm -rf "$sfi_tmp" 2>/dev/null
  mkdir -p "$sfi_tmp" 2>/dev/null
  # shellcheck disable=SC2086
  $sfi_un -o "$sfi_z" -d "$sfi_tmp" >> "$LOG" 2>&1 || {
    echo "解压失败" >&2; return 5; }

  sfi_n=0
  # dial/<名>/... 或 pack/<名>/...
  for sfi_c in dial pack; do
    [ -d "$sfi_tmp/$sfi_c" ] || continue
    for sfi_d in "$sfi_tmp/$sfi_c"/*; do
      [ -d "$sfi_d" ] || continue
      sfi_name=$(basename "$sfi_d")
      mkdir -p "$LIB/$sfi_c" 2>/dev/null
      cp -rf "$sfi_d" "$LIB/$sfi_c/" 2>/dev/null && sfi_n=$((sfi_n + 1))
    done
  done
  rm -rf "$sfi_tmp" 2>/dev/null
  sf_log "import $sfi_z -> $sfi_n 项"
  echo "imported=$sfi_n"
  [ "$sfi_n" -gt 0 ] || { echo "包里没有 dial/ 或 pack/ 目录" >&2; return 6; }
  return 0
}

# ---------------------------------------------------------------------------
# 命令行
# ---------------------------------------------------------------------------
case "$1" in
  list)
    sfl_f=${2:-}
    for sfl_c in dial pack; do
      [ -z "$sfl_f" ] || [ "$sfl_f" = "$sfl_c" ] || continue
      for sfl_d in "$LIB/$sfl_c"/*; do
        [ -d "$sfl_d" ] || continue
        sfl_n=$(basename "$sfl_d")
        # 第 5 列 = 档位(应用里据此标「免费 / Pro+」;主题包按 Pro+ 算)
        # 第 6 列 = 夺舍的官方宿主名(投放时会占用它;应用据此显示"换成哪个")
        if [ "$sfl_c" = "dial" ]; then
          sfl_t=$(sf_dial_tier "$sfl_n")
          sfl_h=$(sf_host_of "$sfl_n")
        else
          sfl_t=2
          sfl_h=
        fi
        echo "$sfl_n|$sfl_c|$(sf_du "$sfl_d")|$(sf_deployed "$sfl_c" "$sfl_n")|$sfl_t|$sfl_h"
      done
    done
    ;;
  installed)
    sfi_t=$(sf_themes)
    if [ -z "$sfi_t" ] || [ ! -d "$sfi_t" ]; then
      echo "(找不到主题目录: $sfi_t)"
      exit 0
    fi
    for sfi_f in "$sfi_t/dial"/*.cl; do
      [ -f "$sfi_f" ] || continue
      basename "$sfi_f" .cl
    done | while read -r sfi_l; do echo "dial|$sfi_l"; done
    for sfi_p in "$sfi_t/theme_pack"/*; do
      [ -d "$sfi_p" ] || continue
      echo "pack|$(basename "$sfi_p")"
    done
    ;;
  apply)
    case "$2" in
      dial)
        # 按素材里记的档位放行:免费表盘人人可投,Pro+ 表盘才查等级
        sf_gate_dial "$(sf_dial_tier "$3")" || exit $?
        sf_apply_dial "$3" ;;
      pack)
        sf_gate || exit $?
        sf_apply_pack "$3" ;;
      *) echo "用法: starface.sh apply {dial|pack} <名>" >&2; exit 2 ;;
    esac
    ;;
  remove)
    case "$2" in
      dial)
        sf_gate_dial "$(sf_dial_tier "$3")" || exit $?
        sfr_h=$(sf_host_of "$3")
        [ -n "$sfr_h" ] || sfr_h="$3"
        sf_restore_one dial "$sfr_h" && echo "ok remove dial $3"
        # 顺手把旧版按 id 投的那份也清掉
        if [ "$sfr_h" != "$3" ]; then
          sfr_t=$(sf_themes)
          [ -n "$sfr_t" ] && rm -f "$sfr_t/dial/$3.cl" 2>/dev/null
          [ -n "$sfr_t" ] && rm -rf "$sfr_t/dial/res/$3" 2>/dev/null
        fi
        sf_refresh_themes ;;
      pack)
        sf_gate || exit $?
        sf_restore_one pack "$3" && echo "ok remove pack $3"
        sf_refresh_themes ;;
      *) echo "用法: starface.sh remove {dial|pack} <名>" >&2; exit 2 ;;
    esac
    ;;
  res)
    # 只补 ThemePro 规范要的 res/<名>/ 三件套(修老库里"加载不出来"的盘):
    #   res        全部素材库表盘
    #   res <名>   某一个
    if [ -n "$2" ]; then
      sf_res_ensure "$2" >/dev/null 2>&1
      echo "ok res $2 ($(ls "$LIB/dial/$2/res/$2" 2>/dev/null | wc -l | tr -d ' ')/3)"
    else
      for sfrr_d in "$LIB/dial"/*; do
        [ -d "$sfrr_d" ] || continue
        sfrr_n=$(basename "$sfrr_d")
        sf_res_ensure "$sfrr_n" >/dev/null 2>&1
        echo "$sfrr_n|$(ls "$LIB/dial/$sfrr_n/res/$sfrr_n" 2>/dev/null | wc -l | tr -d ' ')/3"
      done
    fi
    ;;
  fetch)
    sf_fetch "$2"
    ;;
  remote)
    sf_remote
    ;;
  import)
    sf_gate || exit $?
    sf_import "$2"
    ;;
  info)
    sfi_n2=$2
    if [ -d "$LIB/dial/$sfi_n2" ]; then
      echo "类型: 表盘"
      echo "大小: $(sf_du "$LIB/dial/$sfi_n2")"
      echo "官方宿主位: $(sf_host_of "$sfi_n2") (投放为 $(sf_host_of "$sfi_n2").cl)"
      echo "已投放: $(sf_deployed dial "$sfi_n2")"
      ls -la "$LIB/dial/$sfi_n2" 2>/dev/null | tail -n +2
    elif [ -d "$LIB/pack/$sfi_n2" ]; then
      echo "类型: 主题包"
      echo "大小: $(sf_du "$LIB/pack/$sfi_n2")"
      echo "已投放: $(sf_deployed pack "$sfi_n2")"
    else
      echo "库里没有: $sfi_n2" >&2
      exit 3
    fi
    ;;
  where)
    sf_themes
    ;;
  *)
    echo "用法: starface.sh {list|installed|apply|remove|fetch|remote|res|import|info|where} ..."
    exit 2
    ;;
esac
