#!/system/bin/sh
##########################################################################
# tweak_main.sh —— 桌面流畅度强化(WearSoC Tweak v2.9 抗卡顿强化版)
#
# 整合自独立模块「WearSoC Tweak v2.9【桌面视图切换抗卡顿强化版】」,
# 内容与原版逻辑一致,只改了两处与本模块环境相关的地方:
#   1. 日志路径  /cache/wearsoc_tweak/tweak.log -> /data/adb/star_os/tweak.log
#      (原路径依赖 /cache 分区且需要模块自己 mkdir,统一到 Star OS 状态目录便于查)
#   2. 启动加锁,防止重复拉起两个守护循环
#
# 它做的事:
#   * 内存/VM 参数(低内存杀手阈值、swappiness、脏页比例)、ZRAM 压缩算法
#   * CPU 调频(按 SoC 分支:2100 / 4100 / 5100)、GPU 限频、温控、调度 rate_limit
#   * UI 动画缩放 0.75,让桌面切换显得更跟手
#   * 每 4 秒扫一遍桌面进程,把它从后台击杀名单里捞出来(oom_score_adj -10、
#     放进 freezer/uiapp 组),多桌面包名自动识别
# 所有写节点都走 safe_write,节点不存在就跳过 —— 换机型不会因为找不到节点报错。
##########################################################################

STATE="/data/adb/star_os"
MODLOG="$STATE/tweak.log"
LOCK="$STATE/tweak_loop.pid"
mkdir -p "$STATE" 2>/dev/null

# 已经有实例在跑就直接退出(service.sh 每次开机拉起一次,这里再兜一层)
if [ -f "$LOCK" ]; then
    OLD=$(cat "$LOCK" 2>/dev/null)
    case "$OLD" in ''|*[!0-9]*) ;; *)
        if [ -d "/proc/$OLD" ]; then
            exit 0
        fi
        ;;
    esac
fi
echo $$ > "$LOCK" 2>/dev/null

log_print(){
    # 日志超过 64KB 就重开,避免无限增长
    if [ -f "$MODLOG" ]; then
        _s=$(wc -c < "$MODLOG" 2>/dev/null | tr -d ' ')
        case "$_s" in ''|*[!0-9]*) _s=0 ;; esac
        [ "$_s" -gt 65536 ] && rm -f "$MODLOG"
    fi
    echo "[$(date +%Y-%m-%d\ %H:%M:%S)] $1" >> $MODLOG
}

safe_write(){
    local file="$1"
    local val="$2"
    if [ -w "$file" ];then
        echo "$val" > "$file"
    fi
}

apply_all_tweaks(){
SOC=""
[ -f /sys/devices/soc0/soc_id ] && SOC=$(cat /sys/devices/soc0/soc_id)
[ -z "$SOC" ] && [ -f /proc/socinfo ] && SOC=$(grep -i "soc id" /proc/socinfo | awk '{print $NF}')
[ -z "$SOC" ] && [ -f /sys/qcom,soc-id ] && SOC=$(cat /sys/qcom,soc-id)

# =========内存VM优化，缓解视图切换内存抖动卡顿=========
safe_write /sys/module/lowmemorykiller/parameters/minfree "18432,23040,27648,32256,46080,61440"
safe_write /proc/sys/vm/swappiness 10
safe_write /proc/sys/vm/vfs_cache_pressure 40
safe_write /proc/sys/vm/dirty_background_ratio 2
safe_write /proc/sys/vm/dirty_ratio 6

#ZRAM压缩
if [ -b /dev/block/zram0 ];then
    safe_write /sys/block/zram0/comp_algorithm "lz4"
fi

#系统日志节流，减少IO抢占造成滑动卡顿
setprop persist.logd.no-radio 1
setprop logd.max_size 524288

# =========CPU调频（节点容错）=========
if [[ "$SOC" == *"2100"* ]];then
    for c in 0 1 2 3;do
        safe_write /sys/devices/system/cpu/cpu${c}/cpufreq/scaling_governor "schedutil"
        safe_write /sys/devices/system/cpu/cpu${c}/cpufreq/scaling_min_freq 300000
        safe_write /sys/devices/system/cpu/cpu${c}/cpufreq/scaling_max_freq 1190400
    done
    for c in 4 5 6 7;do
        safe_write /sys/devices/system/cpu/cpu${c}/cpufreq/scaling_governor "schedutil"
        safe_write /sys/devices/system/cpu/cpu${c}/cpufreq/scaling_min_freq 300000
        safe_write /sys/devices/system/cpu/cpu${c}/cpufreq/scaling_max_freq 1344000
    done
fi

if [[ "$SOC" == *"4100"* ]];then
    for c in 0 1 2 3;do
        safe_write /sys/devices/system/cpu/cpu${c}/cpufreq/scaling_governor "schedutil"
        safe_write /sys/devices/system/cpu/cpu${c}/cpufreq/scaling_min_freq 300000
        safe_write /sys/devices/system/cpu/cpu${c}/cpufreq/scaling_max_freq 1516800
    done
    for c in 4 5 6 7;do
        safe_write /sys/devices/system/cpu/cpu${c}/cpufreq/scaling_governor "schedutil"
        safe_write /sys/devices/system/cpu/cpu${c}/cpufreq/scaling_min_freq 300000
        safe_write /sys/devices/system/cpu/cpu${c}/cpufreq/scaling_max_freq 1708800
    done
fi

if [[ "$SOC" == *"5100"* ]];then
    for c in 0 1 2 3;do
        safe_write /sys/devices/system/cpu/cpu${c}/cpufreq/scaling_governor "schedutil"
        safe_write /sys/devices/system/cpu/cpu${c}/cpufreq/scaling_min_freq 300000
        safe_write /sys/devices/system/cpu/cpu${c}/cpufreq/scaling_max_freq 1804800
    done
    for c in 4 5 6 7;do
        safe_write /sys/devices/system/cpu/cpu${c}/cpufreq/scaling_governor "schedutil"
        safe_write /sys/devices/system/cpu/cpu${c}/cpufreq/scaling_min_freq 300000
        safe_write /sys/devices/system/cpu/cpu${c}/cpufreq/scaling_max_freq 2112000
    done
fi

#GPU限频
case "$SOC" in
    *2100*) safe_write /sys/class/kgsl/kgsl-3d0/max_gpuclk 180000000 ;;
    *4100*) safe_write /sys/class/kgsl/kgsl-3d0/max_gpuclk 300000000 ;;
    *5100*) safe_write /sys/class/kgsl/kgsl-3d0/max_gpuclk 380000000 ;;
esac
safe_write /sys/class/kgsl/kgsl-3d0/disable_debug 1
safe_write /sys/module/msm_perf/parameters/debug_mask 0

#温控
safe_write /sys/module/msm_core/parameters/debug_mask 0
safe_write /sys/module/qcom-spm/parameters/debug_mask 0
safe_write /sys/class/kgsl/kgsl-3d0/throttle 1

for c in 0 1 2 3 4 5 6 7;do
    safe_write /sys/devices/system/cpu/cpu${c}/cpufreq/schedutil/rate_limit_us 20000
done
safe_write /sys/devices/system/cpu/cpu_boost/boost_enabled 0
safe_write /sys/module/msm_thermal/parameters/enable_hotplug 0

#UI参数，无破坏状态栏的SF调试项
setprop window_animation_scale 0.75
setprop transition_animation_scale 0.75
setprop animator_duration_scale 0.75
safe_write /sys/devices/system/cpu/sched/sched_rt_runtime_us 950000

# =========多桌面强化抗卡顿逻辑=========
LAUNCHER_LIST=(
"com.xtc.i3launcher"
"com.xtc.launcher"
"com.tencent.watch.launcher"
"com.xtc.carelauncher"
)

for launcher_pkg in "${LAUNCHER_LIST[@]}";do
    PID=$(pidof ${launcher_pkg})
    if [ -n "$PID" ];then
        log_print "识别桌面:${launcher_pkg} PID:${PID}，执行抗卡顿加固"
        # 防后台被杀
        safe_write /proc/$PID/oom_score_adj "-10"
        # CPU调度优先
        renice -n 0 -p $PID 2>/dev/null
        # 禁止app后台冻结，切换视图不被休眠
        echo $PID > /sys/fs/cgroup/freezer/uiapp/tasks 2>/dev/null
    fi
done
}

log_print "==== WearSoC Tweak v2.9 抗卡顿强化版启动 ===="
# 4秒循环，视图频繁切换更快响应
while true
do
apply_all_tweaks
sleep 4
done