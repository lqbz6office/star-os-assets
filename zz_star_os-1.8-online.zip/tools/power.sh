#!/system/bin/sh
# ============================================================================
#  Star OS · 续航管家 (power.sh)   —— 基础功能(免费,人人可用)
#  ===========================================================
#  ★ 统一工具协议(所有 tools/*.sh 都遵守) ★
#     <脚本> meta            一行: id|标题|一句话|等级|动作列表
#                            动作 = key:按钮文字[:pri|ghost],逗号分隔
#     <脚本> status          给人看的状态文本(多行)
#                            以 "@item|显示文本|动作key|参数" 开头的行
#                            会被应用渲染成"一行文字 + 一个按钮"
#     <脚本> act <key> [参数] 执行动作,输出结果文本
#     等级: 0=基础(免费)  2=Pro+ / 终身版
#
#  它能干什么:
#    · 开省电:压低亮度 / 缩短息屏 / 关动画 / 停后台 —— 一键,而且能一键还原
#    · 自动省电:电量掉到阈值自动进,回到阈值自动出(由 daemon 判断)
#    · 电量曲线:每 5 分钟采一个点,顺便估"还能用多久"
#
#  为什么把"省电"做成免费的基础功能:
#    续航是每个人的刚需,不该拿来卖。真正花钱买的是"可编程/自动化"那类能力。
# ============================================================================

PWDIR=${0%/*}
[ -d "$PWDIR" ] || PWDIR=/data/adb/modules/zz_star_os
STAR=${STAR_DIR:-/data/adb/star_os}
PD=$STAR/power
SNAP=$PD/snap.conf
MODE=$PD/mode
HIST=$PD/history.tsv
AUTO=$PD/auto.conf
LOG=$STAR/logs/power.log

mkdir -p "$PD" "$STAR/logs" 2>/dev/null

pw_log() { echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$LOG" 2>/dev/null; }

# 电池节点目录(留环境变量口子,是为了能在电脑上跑测试 —— 真机上就是默认值)
PW_SYS=${POWER_SYS_DIR:-/sys/class/power_supply/battery}

# 当前电量(读不到就给 -1)
pw_level() {
  pwl_l=$(cat "$PW_SYS/capacity" 2>/dev/null)
  case "$pwl_l" in
    ''|*[!0-9]*) echo -1 ;;
    *) echo "$pwl_l" ;;
  esac
}

# 1=正在充电
pw_charging() {
  pwc_s=$(cat "$PW_SYS/status" 2>/dev/null)
  case "$pwc_s" in
    Charging|Full|charging|full) echo 1 ;;
    *) echo 0 ;;
  esac
}

pw_mode() {
  pwm_m=$(cat "$MODE" 2>/dev/null)
  case "$pwm_m" in
    save) echo save ;;
    *) echo normal ;;
  esac
}

# ---------------------------------------------------------------- 快照
# 进省电前先把原值记下来,退出时一模一样还回去。
# (不记的话,用户"关了省电亮度还是暗的",这种坑最招骂)
pw_snapshot() {
  [ -f "$SNAP" ] && return 0
  true > "$SNAP"
  echo "brightness=$(settings get system screen_brightness 2>/dev/null)" >> "$SNAP"
  echo "timeout=$(settings get system screen_off_timeout 2>/dev/null)" >> "$SNAP"
  echo "win_anim=$(settings get global window_animation_scale 2>/dev/null)" >> "$SNAP"
  echo "trans_anim=$(settings get global transition_animation_scale 2>/dev/null)" >> "$SNAP"
  echo "anim_dur=$(settings get global animator_duration_scale 2>/dev/null)" >> "$SNAP"
  pw_log "snapshot: $(tr '\n' ' ' < "$SNAP")"
}

pw_snap_get() {
  sed -n "s/^$1=//p" "$SNAP" 2>/dev/null | head -n 1
}

# 把某个 settings 值恢复(值为空或 null 就不动,别写坏系统)
# 用法: pw_restore_one <namespace> <快照键> <settings 键>
pw_restore_one() {
  pwr_v=$(pw_snap_get "$2")
  case "$pwr_v" in
    ''|null|*[!0-9\-]*) return 0 ;;
  esac
  settings put "$1" "$3" "$pwr_v" >/dev/null 2>&1
}

# ---------------------------------------------------------------- 动作
pw_apply_save() {
  pw_snapshot
  # 亮度压到 1/3 左右(255 制),别压太狠——手表屏幕小,太暗没法看
  settings put system screen_brightness 60 >/dev/null 2>&1
  settings put system screen_off_timeout 15000 >/dev/null 2>&1
  # 关动画:省电也顺便跟手一点
  settings put global window_animation_scale 0 >/dev/null 2>&1
  settings put global transition_animation_scale 0 >/dev/null 2>&1
  settings put global animator_duration_scale 0.5 >/dev/null 2>&1
  # 停后台(别用 kill-all 之外的激进手段,免得把正在用的应用也干掉)
  am kill-all >/dev/null 2>&1
  echo save > "$MODE"
  date '+%s' > "$PD/since"
  pw_log "进入省电模式"
}

pw_apply_normal() {
  # ⚠ 这里必须用 pw_restore_one 逐个还原:函数里的 $1/$2 是**函数自己的**参数,
  #   直接写 "$(pw_snap_get timeout)" 之外的花样很容易拿错值(踩过)。
  pw_restore_one system brightness screen_brightness
  pw_restore_one system timeout screen_off_timeout
  pw_restore_one global win_anim window_animation_scale
  pw_restore_one global trans_anim transition_animation_scale
  pw_restore_one global anim_dur animator_duration_scale
  echo normal > "$MODE"
  pw_log "退出省电模式"
}

pw_auto_conf() {
  pwac_th=$(sed -n 's/^low=//p' "$AUTO" 2>/dev/null | head -n 1)
  pwac_hi=$(sed -n 's/^high=//p' "$AUTO" 2>/dev/null | head -n 1)
  pwac_on=$(sed -n 's/^on=//p' "$AUTO" 2>/dev/null | head -n 1)
  case "$pwac_th" in ''|*[!0-9]*) pwac_th=20 ;; esac
  case "$pwac_hi" in ''|*[!0-9]*) pwac_hi=35 ;; esac
  case "$pwac_on" in 1) ;; *) pwac_on=0 ;; esac
  echo "$pwac_on $pwac_th $pwac_hi"
}

pw_auto_set() {
  echo "on=$1" > "$AUTO"
  echo "low=$2" >> "$AUTO"
  echo "high=$3" >> "$AUTO"
}

# ---------------------------------------------------------------- 采样
# 每 5 分钟一个点,最多留 288 个(24 小时)—— 手表存储小,别无限长。
pw_sample() {
  pws_t=$(date '+%s')
  pws_l=$(pw_level)
  if [ "$pws_l" -lt 0 ]; then
    return 0
  fi
  echo "$pws_t	$pws_l	$(pw_charging)" >> "$HIST"
  pws_n=$(wc -l < "$HIST" 2>/dev/null)
  case "$pws_n" in ''|*[!0-9]*) pws_n=0 ;; esac
  if [ "$pws_n" -gt 288 ]; then
    sed -n "$((pws_n - 287)),\$p" "$HIST" > "$HIST.tmp" 2>/dev/null \
      && mv "$HIST.tmp" "$HIST"
  fi
}

# 估算剩余可用时间 —— 只用"最近未充电"的一段算放电速率。
# 输出形如 "1 天 3 小时" / "约 40 分钟" / 未知原因。
pw_eta() {
  pwe_l=$(pw_level)
  if [ "$pwe_l" -lt 0 ]; then
    echo "读不到电量"
    return 0
  fi
  if [ "$(pw_charging)" = "1" ]; then
    echo "充电中"
    return 0
  fi
  pwe_line=$(grep '	0$' "$HIST" 2>/dev/null | tail -n 24)
  pwe_n=$(echo "$pwe_line" | grep -c . 2>/dev/null)
  case "$pwe_n" in ''|*[!0-9]*) pwe_n=0 ;; esac
  if [ "$pwe_n" -lt 3 ]; then
    echo "数据不足(再攒一会儿)"
    return 0
  fi
  pwe_t1=$(echo "$pwe_line" | head -n 1 | cut -f1)
  pwe_l1=$(echo "$pwe_line" | head -n 1 | cut -f2)
  pwe_t2=$(echo "$pwe_line" | tail -n 1 | cut -f1)
  pwe_l2=$(echo "$pwe_line" | tail -n 1 | cut -f2)
  pwe_dt=$((pwe_t2 - pwe_t1))
  pwe_dl=$((pwe_l1 - pwe_l2))
  if [ "$pwe_dt" -le 0 ] || [ "$pwe_dl" -le 0 ]; then
    echo "耗电很慢或电量在波动"
    return 0
  fi
  # 剩余分钟 = 当前电量 × (观测分钟 / 掉的百分点)
  pwe_min=$((pwe_l * pwe_dt / 60 / pwe_dl))
  if [ "$pwe_min" -ge 1440 ]; then
    echo "$((pwe_min / 1440)) 天 $(((pwe_min % 1440) / 60)) 小时"
  elif [ "$pwe_min" -ge 60 ]; then
    echo "约 $((pwe_min / 60)) 小时 $((pwe_min % 60)) 分钟"
  else
    echo "约 $pwe_min 分钟"
  fi
}

pw_spark() {
  # 极简电量条:用最近的采样拼一行字,手表上比看数字直观
  pwk_n=$(wc -l < "$HIST" 2>/dev/null)
  case "$pwk_n" in ''|*[!0-9]*) pwk_n=0 ;; esac
  [ "$pwk_n" -le 0 ] && return 0
  pwk_s=$(tail -n 24 "$HIST" | cut -f2)
  pw_k_out=""
  for pwk_v in $pwk_s; do
    if [ "$pwk_v" -ge 70 ]; then pw_k_out="$pw_k_out#"
    elif [ "$pwk_v" -ge 40 ]; then pw_k_out="$pw_k_out+"
    elif [ "$pwk_v" -ge 20 ]; then pw_k_out="$pw_k_out-"
    else pw_k_out="$pw_k_out."
    fi
  done
  echo "$pw_k_out"
}

# ---------------------------------------------------------------- 命令
pw_status() {
  pws_cur=$(pw_level)
  if [ "$pws_cur" -lt 0 ]; then
    echo "电量:读不到"
  elif [ "$(pw_charging)" = "1" ]; then
    echo "电量:${pws_cur}% (充电中)"
  else
    echo "电量:${pws_cur}%"
  fi
  case "$(pw_mode)" in
    save) echo "模式:省电中 (亮度/动画已压低,后台已清)" ;;
    *) echo "模式:普通" ;;
  esac
  echo "预计可用:$(pw_eta)"
  pw_ac=$(pw_auto_conf)
  pw_a1=$(echo "$pw_ac" | cut -d' ' -f1)
  pw_a2=$(echo "$pw_ac" | cut -d' ' -f2)
  pw_a3=$(echo "$pw_ac" | cut -d' ' -f3)
  if [ "$pw_a1" = "1" ]; then
    echo "自动省电:开 (低于 ${pw_a2}% 进,回到 ${pw_a3}% 出)"
  else
    echo "自动省电:关"
  fi
  pw_sp=$(pw_spark)
  [ -n "$pw_sp" ] && {
    echo ""
    echo "最近电量走势(# 高 / + 中 / - 低 / . 见底)"
    echo "$pw_sp"
  }
  echo ""
  echo "@item|清一次后台,立刻省点电|act|boostlite"
  return 0
}

case "$1" in
  meta)
    echo "power|续航管家|一键省电 + 电量曲线,还能自动进出|0|save:开启省电:pri,normal:恢复正常:ghost,auto:自动省电:ghost"
    ;;
  status)
    pw_status
    ;;
  act)
    case "$2" in
      save)
        pw_apply_save
        echo "已进入省电模式"
        echo "亮度、息屏时间、动画都压低了,后台也清了一轮。"
        echo "点「恢复正常」会按进入前的原值一模一样还原。"
        ;;
      normal)
        pw_apply_normal
        echo "已恢复正常模式,原设置已还原"
        ;;
      auto)
        pw_ac=$(pw_auto_conf)
        if [ "$(echo "$pw_ac" | cut -d' ' -f1)" = "1" ]; then
          pw_auto_set 0 20 35
          echo "自动省电:已关闭"
        else
          pw_auto_set 1 20 35
          echo "自动省电:已开启"
          echo "电量低于 20% 自动进省电,回到 35% 自动退出。"
        fi
        ;;
      boostlite)
        am kill-all >/dev/null 2>&1
        echo "已清掉后台应用"
        ;;
      *)
        echo "未知动作:$2" >&2
        exit 2
        ;;
    esac
    ;;
  tick)
    pw_sample
    pw_ac=$(pw_auto_conf)
    if [ "$(echo "$pw_ac" | cut -d' ' -f1)" = "1" ]; then
      pw_low=$(echo "$pw_ac" | cut -d' ' -f2)
      pw_high=$(echo "$pw_ac" | cut -d' ' -f3)
      pw_now=$(pw_level)
      if [ "$pw_now" -ge 0 ]; then
        if [ "$(pw_mode)" = "normal" ] && [ "$pw_now" -le "$pw_low" ] \
           && [ "$(pw_charging)" = "0" ]; then
          pw_apply_save
          pw_log "auto: 电量 ${pw_now}% <= ${pw_low}% 自动进省电"
        elif [ "$(pw_mode)" = "save" ] && [ "$pw_now" -ge "$pw_high" ]; then
          pw_apply_normal
          pw_log "auto: 电量 ${pw_now}% >= ${pw_high}% 自动退出省电"
        fi
      fi
    fi
    ;;
  daemon)
    pw_log "续航管家 daemon 启动 (pid=$$)"
    while true; do
      "$0" tick >/dev/null 2>&1
      sleep 300
    done
    ;;
  *)
    echo "用法:$0 {meta|status|act <动作>|tick|daemon}" >&2
    exit 2
    ;;
esac
