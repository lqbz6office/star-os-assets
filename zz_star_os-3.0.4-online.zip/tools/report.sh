#!/system/bin/sh
# ============================================================================
#  Star OS · 星报 (report.sh)   —— 基础功能(免费,人人可用)
#  ===========================================================
#  统一工具协议见 tools/power.sh 开头。
#
#  干的事:一句话把这块表现在的状态攒成一份 txt,存到存储卡上。
#        出了问题(装不上、变卡、某个功能不灵),把这份 txt 发出去,
#        对方不用猜、不用问,一眼就能看出哪儿不对。
#
#  为什么免费:自助排障 = 少一次"必须有人在才能解决"。这正是本模块
#        最想省掉的东西,更不该拿来卖。
#
#  报告去哪儿:内部存储/StarOS/报告/report-<日期时间>.txt
# ============================================================================

PWDIR=${0%/*}
[ -d "$PWDIR" ] || PWDIR=/data/adb/modules/zz_star_os/tools
MODD=${PWDIR%/*}
[ -d "$MODD" ] || MODD=/data/adb/modules/zz_star_os
STAR=${STAR_DIR:-/data/adb/star_os}
RP=$STAR/report
LOG=$STAR/logs/report.log
OUT=${REPORT_OUT_DIR:-/sdcard/StarOS/报告}

mkdir -p "$RP" "$STAR/logs" "$OUT" 2>/dev/null

rp_log() { echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$LOG" 2>/dev/null; }

rp_last() {
  ls -t "$OUT"/report-*.txt 2>/dev/null | head -n 1
}

rp_gen() {
  mkdir -p "$OUT" 2>/dev/null
  rpg_f="$OUT/report-$(date '+%Y%m%d-%H%M%S').txt"
  {
    echo "=============================================="
    echo " Star OS 诊断报告"
    echo " 生成时间:$(date '+%Y-%m-%d %H:%M:%S')"
    echo "=============================================="
    echo ""
    echo "--- 0. 模块 ---"
    cat "$MODD/module.prop" 2>/dev/null || echo "(module.prop 缺失)"
    echo ""
    echo "--- 1. 设备 ---"
    sh "$PWDIR/info.sh" status 2>/dev/null | grep -v '^@item'
    echo ""
    echo "--- 2. 巡检 ---"
    sh "$PWDIR/patrol.sh" check 2>/dev/null
    echo ""
    echo "--- 3. 工具状态 ---"
    for rpt in power boost eye storage charge shield focus turbo cleanup netboost guard wall backup diagnose sensor adblock drain privacy patrol report info mute schedule scene screen alert bench data; do
      [ -f "$PWDIR/$rpt.sh" ] || continue
      rpt_m=$(sh "$PWDIR/$rpt.sh" meta 2>/dev/null | cut -d'|' -f2)
      echo "  [$rpt] ${rpt_m:-?}"
    done
    echo ""
    echo "--- 4. 最近日志(各 10 行) ---"
    for rpl in "$STAR"/logs/*.log; do
      [ -f "$rpl" ] || continue
      echo "  # $(basename "$rpl")"
      tail -n 10 "$rpl" 2>/dev/null | sed 's/^/    /'
    done
    echo ""
    echo "--- 5. 结束 ---"
  } > "$rpg_f" 2>/dev/null

  if [ -s "$rpg_f" ]; then
    rp_log "gen $rpg_f"
    echo "报告已生成:"
    echo "$rpg_f"
    echo ""
    echo "($(wc -l < "$rpg_f" 2>/dev/null) 行,把这个文件发给修表的人即可)"
  else
    echo "报告生成失败:写不进 $OUT" >&2
    exit 1
  fi
}

rp_show_last() {
  rps=$(rp_last)
  if [ -z "$rps" ]; then
    echo "还没有生成过报告。点「生成报告」试试。"
    return 0
  fi
  echo "最近一份:$rps"
  echo "($(wc -l < "$rps" 2>/dev/null) 行)"
  echo ""
  echo "--- 开头 30 行 ---"
  head -n 30 "$rps" 2>/dev/null
}

# ---------------------------------------------------------------------------
# 星诊:在普通报告基础上补 logcat + 崩溃栈,合成一份可以直接发出去的文件
# 敏感串(令牌)会被过滤掉,不会打进包里
# ---------------------------------------------------------------------------
rp_diag() {
  mkdir -p "$OUT" 2>/dev/null
  rpd_f="$OUT/diag-$(date '+%Y%m%d-%H%M%S').txt"
  {
    echo "=============================================="
    echo " Star OS 诊断包(星诊)"
    echo " 生成时间:$(date '+%Y-%m-%d %H:%M:%S')"
    echo "=============================================="
    echo ""
    echo "--- 0. 模块 ---"
    cat "$MODD/module.prop" 2>/dev/null || echo "(module.prop 缺失)"
    echo ""
    echo "--- 1. 设备 ---"
    echo "型号:$(getprop ro.product.model)"
    echo "版本:$(getprop ro.build.version.release) (SDK $(getprop ro.build.version.sdk))"
    echo "内核:$(uname -r 2>/dev/null)"
    echo "开机时长:$(uptime 2>/dev/null)"
    echo ""
    echo "--- 2. 巡检 ---"
    sh "$PWDIR/patrol.sh" check 2>/dev/null
    echo ""
    echo "--- 3. 星守自检 ---"
    sh "$PWDIR/selfheal.sh" status 2>/dev/null | grep -v '^@item'
    echo ""
    echo "--- 4. 工具状态 ---"
    for rpt in power boost eye storage charge shield focus turbo cleanup netboost guard wall backup diagnose sensor adblock drain privacy patrol report info mute schedule scene screen alert bench data selfheal snapshot; do
      [ -f "$PWDIR/$rpt.sh" ] || continue
      rpt_m=$(sh "$PWDIR/$rpt.sh" meta 2>/dev/null | cut -d'|' -f2)
      echo "  [$rpt] ${rpt_m:-?}"
    done
    echo ""
    echo "--- 5. 最近日志(各 10 行) ---"
    for rpl in "$STAR"/logs/*.log; do
      [ -f "$rpl" ] || continue
      echo "  # $(basename "$rpl")"
      tail -n 10 "$rpl" 2>/dev/null | sed 's/^/    /'
    done
    echo ""
    echo "--- 6. 崩溃栈(最近 200 行) ---"
    logcat -d -b crash 2>/dev/null | tail -n 200 | grep -v "ghp_\|github_pat_"
    echo ""
    echo "--- 7. 主日志(最近 300 行) ---"
    logcat -d 2>/dev/null | tail -n 300 | grep -v "ghp_\|github_pat_"
    echo ""
    echo "--- 8. 结束 ---"
  } > "$rpd_f" 2>/dev/null

  if [ -s "$rpd_f" ]; then
    rp_log "diag $rpd_f"
    echo "诊断包已生成:"
    echo "$rpd_f"
    echo ""
    echo "($(wc -l < "$rpd_f" 2>/dev/null) 行,大小 $(du -h "$rpd_f" 2>/dev/null | cut -f1))"
    echo ""
    echo "把这个文件发出去就行,里面有系统状态、日志和崩溃栈。"
    echo "令牌类内容已过滤。"
  else
    echo "诊断包生成失败:写不进 $OUT" >&2
    exit 1
  fi
}

rp_status() {
  rps=$(rp_last)
  if [ -n "$rps" ]; then
    echo "最近报告:$(basename "$rps")"
  else
    echo "最近报告:还没有"
  fi
  echo "存放位置:$OUT"
  echo ""
  echo "换机、报故障、找人帮忙之前,先生成一份,一目了然。"
  echo ""
  echo "@item|生成报告|act|gen"
  echo "@item|看最近一份(开头)|act|last"
  echo "@item|导出诊断包(含日志)|act|diag"
  return 0
}

case "$1" in
  meta)
    echo "report|星报|一键导出诊断报告,发出去就能隔空排障|0|gen:生成报告:pri,last:看最近:ghost,diag:导出诊断包:ghost"
    ;;
  status)
    rp_status
    ;;
  act)
    case "$2" in
      gen)  rp_gen ;;
      last) rp_show_last ;;
      diag) rp_diag ;;
      *)
        echo "未知动作:$2" >&2
        exit 2
        ;;
    esac
    ;;
  *)
    echo "用法:$0 {meta|status|act <动作>}" >&2
    exit 2
    ;;
esac
