#!/system/bin/sh
# ============================================================================
#  Star OS · 星巡 (patrol.sh)   —— 基础功能(免费,人人可用)
#  ===========================================================
#  统一工具协议见 tools/power.sh 开头。
#
#  干的事:给整台表做一次"全身体检",并且可以挂着让它每天自己巡一遍。
#        · 小毛病(广告拦截掉了、守护进程死了)顺手修掉;
#        · 要人管的事(核心破解没生效、表盘被系统换回去了)记下来告诉你。
#
#  为什么免费:这是"主人半年不在家,表自己也能看家"的底线能力,不该拿来卖。
#
#  ⚠ 巡检一律只读;只有「一键修复」会动手,而且只做三件确定安全的事:
#     重启死掉的守护进程、重挂广告拦截、清掉我们自己的过期日志。
# ============================================================================

PWDIR=${0%/*}
[ -d "$PWDIR" ] || PWDIR=/data/adb/modules/zz_star_os/tools
MODD=${PWDIR%/*}
[ -d "$MODD" ] || MODD=/data/adb/modules/zz_star_os
STAR=${STAR_DIR:-/data/adb/star_os}
PT=$STAR/patrol
LOG=$STAR/logs/patrol.log
AUTO=$PT/auto
LAST=$PT/last

mkdir -p "$PT" "$STAR/logs" 2>/dev/null

pt_log() { echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$LOG" 2>/dev/null; }

# 应常驻的守护进程(和 service.sh 的名单保持一致)
PT_DAEMONS="power focus eye charge wall adblock patrol"

pt_kv_avail() {
  # $1 = 挂载点,输出可用 KB
  ptk_l=$(df -k -P "$1" 2>/dev/null | sed -n '2p')
  [ -z "$ptk_l" ] && ptk_l=$(df -k "$1" 2>/dev/null | sed -n '2p')
  echo "$ptk_l" | sed -n 's/^[^ 	][^ 	]*[ 	][ 	]*[0-9][0-9]*[ 	][ 	]*[0-9][0-9]*[ 	][ 	]*\([0-9][0-9]*\).*/\1/p'
}

pt_mem_avail() {
  sed -n 's/^MemAvailable:[ 	]*\([0-9][0-9]*\).*/\1/p' /proc/meminfo 2>/dev/null | head -n 1
}

# 在 /proc 里找还活着的守护进程,输出空格分隔的工具名
pt_daemons_alive() {
  pta_out=""
  for pta_p in /proc/[0-9]*; do
    [ -r "$pta_p/cmdline" ] || continue
    pta_c=$(tr '\0' ' ' < "$pta_p/cmdline" 2>/dev/null)
    case "$pta_c" in
      *tools/*.sh*daemon*)
        pta_n=$(echo "$pta_c" | sed -n 's#.*tools/\([a-z]*\)\.sh.*daemon.*#\1#p')
        [ -n "$pta_n" ] && pta_out="$pta_out $pta_n"
        ;;
    esac
  done
  echo "$pta_out"
}

# ---------------------------------------------------------------- 各项检查
pt_ck_module() {
  if [ -f "$MODD/module.prop" ]; then
    ptm_v=$(sed -n 's/^version=//p' "$MODD/module.prop" 2>/dev/null | head -n 1)
    echo "OK|模块在位 (${ptm_v:-?})"
  else
    echo "BAD|模块文件不见了"
  fi
}

pt_ck_corepatch() {
  if [ ! -f "$MODD/corepatch_check.sh" ]; then
    echo "WARN|核心破解检测脚本缺失"
    return 0
  fi
  . "$MODD/corepatch_check.sh"
  cp_probe >/dev/null 2>&1
  case "$CP_RC" in
    0) echo "OK|核心破解已激活${CP_FW:+ [$CP_FW]}" ;;
    1) echo "WARN|核心破解已装但未生效 —— LSPosed 里勾上「系统框架」再重启" ;;
    2) echo "BAD|核心破解未安装 —— 桌面/侧边栏会装不上" ;;
    *) echo "WARN|核心破解状态读不到(通常没事)" ;;
  esac
}

pt_ck_storage() {
  pts_kb=$(pt_kv_avail /data)
  case "$pts_kb" in ''|*[!0-9]*) echo "WARN|存储读不到" ; return 0 ;; esac
  pts_mb=$((pts_kb / 1024))
  if [ "$pts_mb" -lt 500 ]; then
    echo "BAD|内部存储只剩 ${pts_mb}MB,建议清理"
  elif [ "$pts_mb" -lt 1500 ]; then
    echo "WARN|内部存储剩 ${pts_mb}MB,略紧"
  else
    echo "OK|内部存储剩 ${pts_mb}MB"
  fi
}

pt_ck_mem() {
  ptm_kb=$(pt_mem_avail)
  case "$ptm_kb" in ''|*[!0-9]*) echo "WARN|内存读不到" ; return 0 ;; esac
  ptm_mb=$((ptm_kb / 1024))
  if [ "$ptm_mb" -lt 120 ]; then
    echo "WARN|可用内存只剩 ${ptm_mb}MB,可能会卡"
  else
    echo "OK|可用内存 ${ptm_mb}MB"
  fi
}

pt_ck_daemons() {
  ptd_alive=$(pt_daemons_alive)
  ptd_miss=""
  for ptd_d in $PT_DAEMONS; do
    case " $ptd_alive " in
      *" $ptd_d "*) ;;
      *) ptd_miss="$ptd_miss $ptd_d" ;;
    esac
  done
  if [ -z "$ptd_miss" ]; then
    echo "OK|守护进程齐全 ($(echo $PT_DAEMONS | tr ' ' '/' ))"
  else
    echo "WARN|守护进程缺:$(echo $ptd_miss) —— 点「一键修复」重启它们"
  fi
}

pt_ck_adblock() {
  if mount 2>/dev/null | grep -q "etc/hosts"; then
    echo "OK|广告拦截已挂载"
  else
    echo "WARN|广告拦截未挂载(没开过就无视这条)"
  fi
}

pt_ck_dial() {
  ptd_dir=/sdcard/Android/baiyao105/ThemePro/Themes/dial
  ptd_n=$(ls "$ptd_dir"/*.cl 2>/dev/null | grep -c .)
  if [ "$ptd_n" -gt 0 ]; then
    echo "OK|表盘投放 $ptd_n 个"
  else
    echo "OK|还没投放表盘"
  fi
}

# ---------------------------------------------------------------- 跑一轮
# check 模式:纯文本(给「星报」抓取用);显示模式:带 @item 按钮
pt_run() {
  pt_mode=$1
  pt_bad=0
  pt_warn=0
  ptd_alive=$(pt_daemons_alive)

  for pt_item in \
      "$(pt_ck_module)" \
      "$(pt_ck_corepatch)" \
      "$(pt_ck_storage)" \
      "$(pt_ck_mem)" \
      "$(pt_ck_daemons)" \
      "$(pt_ck_adblock)" \
      "$(pt_ck_dial)"
  do
    pt_lvl=$(echo "$pt_item" | cut -d'|' -f1)
    pt_txt=$(echo "$pt_item" | cut -d'|' -f2-)
    case "$pt_lvl" in
      OK)   echo "✓ $pt_txt" ;;
      WARN) echo "! $pt_txt"; pt_warn=$((pt_warn + 1)) ;;
      *)    echo "✗ $pt_txt"; pt_bad=$((pt_bad + 1)) ;;
    esac
  done

  echo ""
  if [ "$pt_bad" -gt 0 ]; then
    echo "结论:$pt_bad 项要处理,$pt_warn 项留意"
  elif [ "$pt_warn" -gt 0 ]; then
    echo "结论:整体还行,$pt_warn 项留意"
  else
    echo "结论:全部正常"
  fi

  if [ "$pt_mode" = "show" ]; then
    echo ""
    echo "@item|立刻重巡|act|scan"
    echo "@item|一键修复(重启守护+重挂拦截)|act|fix"
    echo "@item|每日自动巡检 开/关|act|auto"
  fi
  pt_log "run bad=$pt_bad warn=$pt_warn"
}

# ---------------------------------------------------------------- 修复
pt_fix() {
  ptf_did=0
  ptd_alive=$(pt_daemons_alive)
  for ptf_d in $PT_DAEMONS; do
    case " $ptd_alive " in
      *" $ptf_d "*) ;;
      *)
        [ -f "$PWDIR/$ptf_d.sh" ] || continue
        if command -v setsid >/dev/null 2>&1; then
          setsid sh "$PWDIR/$ptf_d.sh" daemon >/dev/null 2>&1 &
        else
          sh "$PWDIR/$ptf_d.sh" daemon >/dev/null 2>&1 &
        fi
        echo "已重启守护:$ptf_d"
        ptf_did=$((ptf_did + 1))
        ;;
    esac
  done

  # 广告拦截没挂就试着补挂(它自己会判断有没有开过)
  if ! mount 2>/dev/null | grep -q "etc/hosts"; then
    if [ -f "$PWDIR/adblock.sh" ]; then
      ptf_r=$(sh "$PWDIR/adblock.sh" act remount 2>&1)
      case "$ptf_r" in
        *失败*|*未启用*|*没开*) ;;   # 没开过就不管它
        *) echo "广告拦截:$ptf_r"; ptf_did=$((ptf_did + 1)) ;;
      esac
    fi
  fi

  # 日志轮转:我们自己的日志超过 512KB 就切掉旧的
  for ptf_l in "$STAR"/logs/*.log; do
    [ -f "$ptf_l" ] || continue
    ptf_sz=$(wc -c < "$ptf_l" 2>/dev/null)
    case "$ptf_sz" in ''|*[!0-9]*) continue ;; esac
    if [ "$ptf_sz" -gt 524288 ]; then
      tail -n 200 "$ptf_l" > "$ptf_l.tmp" 2>/dev/null && mv "$ptf_l.tmp" "$ptf_l" 2>/dev/null
      echo "已瘦身日志:$(basename "$ptf_l")"
      ptf_did=$((ptf_did + 1))
    fi
  done

  if [ "$ptf_did" -eq 0 ]; then
    echo "没发现能自动修的问题。核心破解/表盘那类要人管的,请按提示手动处理。"
  else
    echo "修复完成,共 $ptf_did 处。"
  fi
  pt_log "fix did=$ptf_did"
}

# ---------------------------------------------------------------- 每日自动
pt_auto_state() {
  [ -f "$AUTO" ] && echo on || echo off
}

pt_auto_toggle() {
  if [ -f "$AUTO" ]; then
    mv "$AUTO" "$AUTO.off" 2>/dev/null
    echo "每日自动巡检:已关"
  else
    true > "$AUTO"
    echo "每日自动巡检:已开 —— 每天凌晨自己巡一遍,有毛病记到日志里"
  fi
  pt_log "auto=$(pt_auto_state)"
}

pt_tick() {
  [ -f "$AUTO" ] || return 0
  ptt_today=$(date '+%Y%m%d')
  ptt_last=$(cat "$LAST" 2>/dev/null)
  [ "$ptt_last" = "$ptt_today" ] && return 0
  ptt_h=$(date '+%H')
  [ "$ptt_h" = "03" ] || return 0
  echo "$ptt_today" > "$LAST"
  pt_run check >/dev/null 2>&1
  pt_log "每日自动巡检已执行 ($ptt_today)"
}

pt_status() {
  pt_last=$(cat "$LAST" 2>/dev/null)
  if [ -n "$pt_last" ]; then
    echo "上次自动巡检:$pt_last"
  else
    echo "上次自动巡检:还没跑过"
  fi
  if [ "$(pt_auto_state)" = "on" ]; then
    echo "每日自动巡检:开(约凌晨 3 点)"
  else
    echo "每日自动巡检:关"
  fi
  echo ""
  echo "=== 当前体检 ==="
  pt_run show
}

case "$1" in
  meta)
    echo "patrol|星巡|每天自己给手表做体检,小毛病顺手修掉|0|scan:立刻巡检:pri,fix:一键修复:ghost,auto:每日自动:ghost"
    ;;
  status)
    pt_status
    ;;
  check)
    pt_run check
    ;;
  act)
    case "$2" in
      scan) pt_run show ;;
      fix)  pt_fix ;;
      auto) pt_auto_toggle ;;
      *)
        echo "未知动作:$2" >&2
        exit 2
        ;;
    esac
    ;;
  tick)
    pt_tick
    ;;
  daemon)
    pt_log "星巡 daemon 启动 (pid=$$)"
    while true; do
      "$0" tick >/dev/null 2>&1
      sleep 600
    done
    ;;
  *)
    echo "用法:$0 {meta|status|check|act <动作>|tick|daemon}" >&2
    exit 2
    ;;
esac
