#!/system/bin/sh
# ============================================================================
#  Star OS · 星际指令 (recipes.sh)   —— Pro+ / 终身版专属
#  ===========================================================
#  让手表"可编程":满足条件就自动做事情。
#
#    条件(when)  时间 / 星期 / 电量 / 充电 / Wi-Fi / 屏幕
#    动作(then)  免打扰 / 亮度 / 音量 / 关 Wi-Fi / 停应用 / 通知 / 震动
#
#  规则是纯文本,放在 /data/adb/star_os/recipes/<id>.rule,
#  应用侧只负责增删改这些文件 + 开关,真正的判断与执行全在这里 ——
#  这样即使应用被杀、手表重启,规则照样跑(由 service.sh 拉起)。
#
#  ---------------------------------------------------------------------------
#  规则文件格式(等号两边不要空格,值里可以是中文):
#
#     name=上课模式
#     enabled=1
#     # ---- 条件:全部满足才算"进入"状态,写空 = 不判断 ----
#     cond_time=08:00-17:00        # 时段(跨零点也支持,如 22:00-06:00)
#     cond_dow=1-5                 # 星期(1=周一 … 7=周日,可写 1-5,6,7)
#     cond_battery_lt=20           # 电量低于 N%
#     cond_charging=0              # 0=不在充电,1=正在充电,空=不判断
#     cond_wifi=on                 # on/off
#     cond_screen=off              # on/off
#     # ---- 进入时执行 ----
#     on_zen=1                     # 1=开免打扰
#     on_brightness=30             # 亮度(0-255)
#     on_volume=0                  # 媒体音量(0-15)
#     on_wifi=off                  # 关 Wi-Fi
#     on_kill=com.xtc.watch         # 停掉某个应用(可写多个,逗号分隔)
#     on_notify=上课模式已开启       # 发一条通知
#     on_vibrate=1                 # 震动一下
#     # ---- 退出时恢复(不写就保持原样,只把 on_ 里动过的项还原) ----
#     off_zen=0
#     off_brightness=128
#
#  用法:
#     recipes.sh list               列出所有规则(id|名称|启停|当前是否命中)
#     recipes.sh show <id>          打印一条规则原文
#     recipes.sh enable|disable <id>
#     recipes.sh test <id>          只判断条件,不执行(调试用)
#     recipes.sh run <id>           立刻强制执行一次"进入"动作
#     recipes.sh tick               评估全部规则一次(daemon 每轮调它)
#     recipes.sh daemon             常驻循环
# ============================================================================

RCDIR=${0%/*}
[ -d "$RCDIR" ] || RCDIR=/data/adb/modules/zz_star_os
STAR=/data/adb/star_os
RDIR=$STAR/recipes
SDIR=$RDIR/.state
LOG=$STAR/logs/recipes.log
LOCK=$STAR/run/recipes.lock

mkdir -p "$RDIR" "$SDIR" "$STAR/logs" "$STAR/run" 2>/dev/null

rc_log() {
  echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$LOG" 2>/dev/null
}

# ---------------------------------------------------------------------------
# Pro+ / 终身版门槛
#
# 星际指令是高级功能(只有 Pro+ 与终身版可用)。这里读的是应用激活时写下的
# pro.conf —— 属于"本地闸门";真正的真值在台账,应用每次进实验室都会联网
# 核对一次(见 License.checkIndex),被吊销的码即使本地文件还在也进不来。
# ---------------------------------------------------------------------------
rc_tier() {
  rcg_v=0
  if [ -f "$STAR/pro.conf" ]; then
    rcg_v=$(sed -n 's/^tier=//p' "$STAR/pro.conf" 2>/dev/null | head -n 1)
  fi
  case "$rcg_v" in
    ''|*[!0-9]*) echo 0 ;;
    *) echo "$rcg_v" ;;
  esac
}

rc_is_pro_plus() {
  [ "$(rc_tier)" -ge 2 ]
}

# ---------------------------------------------------------------------------
# 读规则里的一个键(没有则输出空)
# ---------------------------------------------------------------------------
rc_get() {
  # $1=文件 $2=键
  sed -n "s/^$2=//p" "$1" 2>/dev/null | head -n 1
}

# ---------------------------------------------------------------------------
# 条件判断
# ---------------------------------------------------------------------------
rc_now_hm() { date '+%H:%M'; }
rc_now_dow() { date '+%u'; }          # 1=周一 … 7=周日

rc_battery() {
  # 输出电量数字;取不到给 -1
  rcb_v=$(dumpsys battery 2>/dev/null | sed -n 's/^  level: //p' | head -n 1)
  case "$rcb_v" in
    ''|*[!0-9]*) echo -1 ;;
    *) echo "$rcb_v" ;;
  esac
}

rc_charging() {
  # 输出 1 / 0
  rcch_s=$(dumpsys battery 2>/dev/null | sed -n 's/^  status: //p' | head -n 1)
  case "$rcch_s" in
    2|5) echo 1 ;;      # 2=充电中 5=已充满
    *) echo 0 ;;
  esac
}

rc_wifi() {
  rcw_s=$(cat /sys/class/net/wlan0/operstate 2>/dev/null)
  case "$rcw_s" in
    up) echo on ;;
    *) echo off ;;
  esac
}

rc_screen() {
  rcs_w=$(dumpsys power 2>/dev/null | sed -n 's/.*mWakefulness=//p' | head -n 1 | cut -d' ' -f1)
  if [ -z "$rcs_w" ]; then
    rcs_w=$(dumpsys power 2>/dev/null | sed -n 's/.*mScreenOn=\(true\|false\).*/\1/p' | head -n 1)
    case "$rcs_w" in
      true) echo on; return ;;
      false) echo off; return ;;
    esac
    # 再退一步:读背光
    rcs_b=$(cat /sys/class/leds/lcd-backlight/brightness 2>/dev/null)
    if [ -n "$rcs_b" ] && [ "$rcs_b" -gt 0 ] 2>/dev/null; then echo on; else echo off; fi
    return
  fi
  case "$rcs_w" in
    Awake) echo on ;;
    *) echo off ;;
  esac
}

# 时段:开始-结束,支持跨零点($1=now $2=range)
rc_in_span() {
  rci_h=${1%%:*}; rci_m=${1##*:}
  rci_sh=${2%%-*}; rci_eh=${2##*-}
  rci_cur=$((10#$rci_h * 60 + 10#$rci_m))
  rci_s=$((10#${rci_sh%%:*} * 60 + 10#${rci_sh##*:}))
  rci_e=$((10#${rci_eh%%:*} * 60 + 10#${rci_eh##*:}))
  if [ "$rci_s" -le "$rci_e" ]; then
    [ "$rci_cur" -ge "$rci_s" ] && [ "$rci_cur" -lt "$rci_e" ] && return 0
  else
    # 跨零点,如 22:00-06:00
    { [ "$rci_cur" -ge "$rci_s" ] || [ "$rci_cur" -lt "$rci_e" ]; } && return 0
  fi
  return 1
}

# 星期集合:如 "1-5" / "6,7" / "1-5,7"
rc_in_dows() {
  rcd_now=$(rc_now_dow)
  for rcd_p in $(echo "$1" | tr ',' ' '); do
    case "$rcd_p" in
      *-*)
        rcd_a=${rcd_p%%-*}; rcd_b=${rcd_p##*-}
        if [ "$rcd_now" -ge "$rcd_a" ] && [ "$rcd_now" -le "$rcd_b" ]; then return 0; fi
        ;;
      *)
        [ "$rcd_now" = "$rcd_p" ] && return 0
        ;;
    esac
  done
  return 1
}

# 全部条件满足 -> 0
rc_cond_ok() {
  rcc_f=$1

  rcc_t=$(rc_get "$rcc_f" cond_time)
  if [ -n "$rcc_t" ]; then
    rc_in_span "$(rc_now_hm)" "$rcc_t" || return 1
  fi

  rcc_d=$(rc_get "$rcc_f" cond_dow)
  if [ -n "$rcc_d" ]; then
    rc_in_dows "$rcc_d" || return 1
  fi

  rcc_b=$(rc_get "$rcc_f" cond_battery_lt)
  if [ -n "$rcc_b" ]; then
    rcc_bl=$(rc_battery)
    [ "$rcc_bl" -ge 0 ] 2>/dev/null || return 1        # 读不到电量就不冒险触发
    [ "$rcc_bl" -lt "$rcc_b" ] || return 1
  fi

  rcc_c=$(rc_get "$rcc_f" cond_charging)
  if [ -n "$rcc_c" ]; then
    [ "$(rc_charging)" = "$rcc_c" ] || return 1
  fi

  rcc_w=$(rc_get "$rcc_f" cond_wifi)
  if [ -n "$rcc_w" ]; then
    [ "$(rc_wifi)" = "$rcc_w" ] || return 1
  fi

  rcc_s=$(rc_get "$rcc_f" cond_screen)
  if [ -n "$rcc_s" ]; then
    [ "$(rc_screen)" = "$rcc_s" ] || return 1
  fi

  return 0
}

# ---------------------------------------------------------------------------
# 动作
# ---------------------------------------------------------------------------
rc_set_brightness() {
  settings put system screen_brightness "$1" >/dev/null 2>&1 \
    && rc_log "    brightness=$1" || rc_log "    brightness=$1 失败"
}

rc_set_zen() {
  # 免打扰:settings 是主路径,svc 兜底
  settings put global zen_mode "$1" >/dev/null 2>&1
  rc_log "    zen_mode=$1"
}

rc_set_volume() {
  media volume --set "$1" >/dev/null 2>&1 \
    && rc_log "    volume=$1" || rc_log "    volume=$1 失败"
}

rc_set_wifi() {
  svc wifi "$1" >/dev/null 2>&1
  rc_log "    wifi=$1"
}

rc_kill_apps() {
  for rck_p in $(echo "$1" | tr ',' ' '); do
    [ -n "$rck_p" ] || continue
    am force-stop "$rck_p" >/dev/null 2>&1
    rc_log "    force-stop $rck_p"
  done
}

rc_notify() {
  # 走 shell 的 notification 通道(root 下可用);老机型没有就静默跳过
  # —— 通知只是锦上添花,不能因为它失败就把整条规则算失败。
  if command -v cmd >/dev/null 2>&1; then
    cmd notification post -S bigtext -t "星际指令" staros_recipe "$1" >/dev/null 2>&1
  fi
  rc_log "    notify: $1"
}

rc_vibrate() {
  # 找一个可用的振动节点试一遍
  for rcv_v in /sys/class/timed_output/vibrator/enable \
               /sys/class/leds/vibrator/duration /sys/devices/virtual/timed_output/vibrator/enable; do
    if [ -w "$rcv_v" ]; then
      echo 200 > "$rcv_v" 2>/dev/null && { rc_log "    vibrate ok"; return 0; }
    fi
  done
  # 退路:用 cmd(部分机型可用)
  cmd vibrator vibrate 200 >/dev/null 2>&1
  rc_log "    vibrate (尽力而为)"
}

rc_apply() {
  # $1=规则文件 $2=on|off
  rca_id=$3
  rca_f=$1
  rca_ph=$2
  rc_log "== $rca_id -> $rca_ph =="

  rca_v=$(rc_get "$rca_f" ${rca_ph}_zen)
  [ -n "$rca_v" ] && rc_set_zen "$rca_v"

  rca_v=$(rc_get "$rca_f" ${rca_ph}_brightness)
  [ -n "$rca_v" ] && rc_set_brightness "$rca_v"

  rca_v=$(rc_get "$rca_f" ${rca_ph}_volume)
  [ -n "$rca_v" ] && rc_set_volume "$rca_v"

  rca_v=$(rc_get "$rca_f" ${rca_ph}_wifi)
  [ -n "$rca_v" ] && rc_set_wifi "$rca_v"

  rca_v=$(rc_get "$rca_f" ${rca_ph}_kill)
  [ -n "$rca_v" ] && rc_kill_apps "$rca_v"

  rca_v=$(rc_get "$rca_f" ${rca_ph}_vibrate)
  [ "$rca_v" = "1" ] && rc_vibrate

  rca_v=$(rc_get "$rca_f" ${rca_ph}_notify)
  [ -n "$rca_v" ] && rc_notify "$rca_v"

  return 0
}

# ---------------------------------------------------------------------------
# 评估全部规则
# ---------------------------------------------------------------------------
rc_all_ids() {
  for rcx_f in "$RDIR"/*.rule; do
    [ -f "$rcx_f" ] || continue
    basename "$rcx_f" .rule
  done
}

rc_tick() {
  # 没到 Pro+ 就别评估 —— 规则文件可以留着(tier 升上来立刻恢复),
  # 但一个动作也不许执行。
  rc_is_pro_plus || return 0
  rc_log "-- tick $(rc_now_hm) --"
  for rct_id in $(rc_all_ids); do
    rct_f="$RDIR/$rct_id.rule"
    rct_on=$(rc_get "$rct_f" enabled)
    [ "$rct_on" = "1" ] || continue

    rct_st="$SDIR/$rct_id"
    if rc_cond_ok "$rct_f"; then
      if [ ! -f "$rct_st" ]; then
        rc_apply "$rct_f" on "$rct_id"
        echo "$(date +%s)" > "$rct_st" 2>/dev/null
        [ -x "$RCDIR/notify.sh" ] || true
      fi
    else
      if [ -f "$rct_st" ]; then
        rc_apply "$rct_f" off "$rct_id"
        rm -f "$rct_st" 2>/dev/null
      fi
    fi
  done
  return 0
}

# ---------------------------------------------------------------------------
# 命令行
# ---------------------------------------------------------------------------
case "$1" in
  list)
    for rcl_id in $(rc_all_ids); do
      rcl_f="$RDIR/$rcl_id.rule"
      rcl_n=$(rc_get "$rcl_f" name)
      rcl_e=$(rc_get "$rcl_f" enabled)
      [ -n "$rcl_n" ] || rcl_n=$rcl_id
      [ "$rcl_e" = "1" ] || rcl_e=0
      if rc_cond_ok "$rcl_f"; then rcl_hit=1; else rcl_hit=0; fi
      if [ -f "$SDIR/$rcl_id" ]; then rcl_live=1; else rcl_live=0; fi
      echo "$rcl_id|$rcl_n|$rcl_e|$rcl_hit|$rcl_live"
    done
    ;;
  show)
    [ -f "$RDIR/$2.rule" ] && cat "$RDIR/$2.rule" || { echo "没有这条规则: $2" >&2; exit 3; }
    ;;
  enable|disable)
    rce_f="$RDIR/$2.rule"
    [ -f "$rce_f" ] || { echo "没有这条规则: $2" >&2; exit 3; }
    if [ "$1" = "enable" ]; then rce_v=1; else rce_v=0; fi
    sed -i "s/^enabled=.*/enabled=$rce_v/" "$rce_f" 2>/dev/null
    grep -q '^enabled=' "$rce_f" || echo "enabled=$rce_v" >> "$rce_f"
    # 关掉时顺手清掉"进行中"状态,免得规则卡在半开状态
    [ "$rce_v" = "0" ] && rm -f "$SDIR/$2" 2>/dev/null
    echo "ok $1 $2"
    ;;
  test)
    rct2_f="$RDIR/$2.rule"
    [ -f "$rct2_f" ] || { echo "没有这条规则: $2" >&2; exit 3; }
    if rc_cond_ok "$rct2_f"; then echo "hit=1"; else echo "hit=0"; fi
    ;;
  run)
    rct3_f="$RDIR/$2.rule"
    [ -f "$rct3_f" ] || { echo "没有这条规则: $2" >&2; exit 3; }
    rc_is_pro_plus || { echo "星际指令是 Pro+ / 终身版功能,当前等级不够" >&2; exit 5; }
    rc_apply "$rct3_f" on "$2"
    echo "$(date +%s)" > "$SDIR/$2" 2>/dev/null
    echo "ok run $2"
    ;;
  tick)
    rc_tick
    ;;
  daemon)
    # 没有 Pro+ 就不必占着常驻进程;等激活后 service.sh 重启它即可。
    rc_is_pro_plus || { rc_log "daemon: 未激活 Pro+,退出"; exit 0; }
    # 单实例
    if [ -f "$LOCK" ]; then
      rcd_old=$(cat "$LOCK" 2>/dev/null)
      if [ -n "$rcd_old" ] && kill -0 "$rcd_old" 2>/dev/null; then
        echo "已在运行 (pid $rcd_old)"
        exit 0
      fi
    fi
    echo $$ > "$LOCK" 2>/dev/null
    rc_log "== daemon start pid=$$ =="
    while true; do
      rc_tick
      sleep 60
    done
    ;;
  *)
    echo "用法: recipes.sh {list|show|enable|disable|test|run|tick|daemon} [id]"
    exit 2
    ;;
esac
