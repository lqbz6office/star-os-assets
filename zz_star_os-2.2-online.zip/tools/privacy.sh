#!/system/bin/sh
# ============================================================================
#  Star OS · 星隐 (privacy.sh)   —— Pro+ / 终身版专属
#  ===========================================================
#  统一工具协议见 tools/power.sh 开头。
#
#  干的事:把手表上的"使用痕迹"擦一遍 —— 通话记录、系统日志、后台残留。
#        适合:准备把表借人/二手转出,或者就是不想留痕。
#
#  ⚠ 点下去就清了,不可恢复。所以状态页把"要清什么、清不了什么"全写清楚,
#    不做"一键清理 10GB"那种话术。
#
#  诚实清单(哪些真能清、哪些清不了,写明白):
#    · 通话记录   —— 能清(content provider)
#    · 系统日志   —— 能清(logcat -c)
#    · 后台残留   —— 能清(am kill-all)
#    · 剪贴板     —— 8.1 系统没开放接口,尽力而为,清不了会直说
#    · 应用内聊天/浏览记录 —— **不碰**。那是应用自己的数据,要清得逐个
#                  pm clear,等于把账号也登出了,不能混在"擦痕"里偷偷干。
# ============================================================================

PWDIR=${0%/*}
[ -d "$PWDIR" ] || PWDIR=/data/adb/modules/zz_star_os
STAR=${STAR_DIR:-/data/adb/star_os}
PV=$STAR/privacy
LOG=$STAR/logs/privacy.log

mkdir -p "$PV" "$STAR/logs" 2>/dev/null

pv_log() { echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$LOG" 2>/dev/null; }

pv_tier() {
  pvg_v=0
  if [ -f "$STAR/pro.conf" ]; then
    pvg_v=$(sed -n 's/^tier=//p' "$STAR/pro.conf" 2>/dev/null | head -n 1)
  fi
  case "$pvg_v" in
    ''|*[!0-9]*) echo 0 ;;
    *) echo "$pvg_v" ;;
  esac
}

pv_gate() {
  [ "$(pv_tier)" -ge 2 ] && return 0
  echo "星隐是 Pro+ / 终身版功能,当前等级不够" >&2
  return 5
}

# ---------------------------------------------------------------- 单项
pv_calls() {
  pvc_o=$(content delete --uri content://call_log/calls 2>&1)
  case "$pvc_o" in
    *Deleted*|*deleted*) echo "通话记录:$pvc_o" ;;
    *) echo "通话记录:清不了(系统没给权限,或本来就没记录)" ;;
  esac
}

pv_logs() {
  if logcat -c >/dev/null 2>&1; then
    echo "系统日志:已清空"
  else
    echo "系统日志:清不了"
  fi
}

pv_tasks() {
  if am kill-all >/dev/null 2>&1; then
    echo "后台残留:已停掉"
  else
    echo "后台残留:清不了"
  fi
}

pv_clip() {
  if command -v cmd >/dev/null 2>&1 && cmd clipboard clear >/dev/null 2>&1; then
    echo "剪贴板:已清"
  else
    echo "剪贴板:8.1 不支持命令行清,跳过(不确定录屏的剪贴板里还有没有东西)"
  fi
}

pv_clean() {
  echo "开始擦除使用痕迹…"
  echo ""
  pv_calls
  pv_logs
  pv_tasks
  pv_clip
  pv_log "clean done"
  echo ""
  echo "完成。应用内的聊天/浏览记录没动(那是应用的数据,要清得逐个登出)。"
}

pv_status() {
  echo "可以擦除的痕迹:"
  echo "  · 通话记录"
  echo "  · 系统日志"
  echo "  · 后台残留"
  echo "  · 剪贴板(尽力)"
  echo ""
  echo "不会动的:应用内聊天/浏览记录(要清得逐个登出,不在这里混着做)"
  echo ""
  echo "@item|一键擦除(不可恢复)|act|clean"
  return 0
}

case "$1" in
  meta)
    echo "privacy|星隐|擦掉通话记录/日志/后台痕迹,借人转手前用|2|clean:一键擦除:pri"
    ;;
  status)
    pv_gate || exit 5
    pv_status
    ;;
  act)
    pv_gate || exit 5
    case "$2" in
      clean) pv_clean ;;
      *)
        echo "未知动作:$2" >&2
        exit 2
        ;;
    esac
    ;;
  *)
    echo "用法:$0 {meta|status|act <动作>}" >&2
    exit 2
    ;;
esac
