#!/system/bin/sh
# ============================================================================
#  Star OS · 星净 (adblock.sh)   —— Pro+ / 终身版专属
#  ===========================================================
#  统一工具协议见 tools/power.sh 开头。
#
#  干的事:把广告和统计域名的解析全导到 127.0.0.1 —— 应用里的广告加载不出来,
#        数据上报也发不出去。应用本身照常用,只是那几个域名"打不通"。
#
#  原理(为什么要 root 才做得了):
#    改 /system/etc/hosts。8.1 的 /system 是只读分区,直接写不进去,
#    所以走 bind mount:把我们自己那份 hosts 挂到 /system/etc/hosts 上,
#    立即生效、随时可摘 —— 不动分区里任何一个字节,摘掉就完全恢复原样。
#
#  ⚠ 规矩:
#    · 摘挂(off)一定用 umount,不改原文件;
#    · 挂载点丢失(重启就丢)由 daemon 每 10 分钟检查一次并补挂;
#    · 规则是我们自己维护的一份小名单(不追全网大列表 —— 手表内存小,
#      几十条覆盖主流广告/统计就够,大了反而拖慢解析)。
# ============================================================================

PWDIR=${0%/*}
[ -d "$PWDIR" ] || PWDIR=/data/adb/modules/zz_star_os
STAR=${STAR_DIR:-/data/adb/star_os}
AD=$STAR/adblock
BLOCK=$AD/block.list
HOSTS=$AD/hosts
LOG=$STAR/logs/adblock.log
TARGET=${ADBLOCK_TARGET:-/system/etc/hosts}

mkdir -p "$AD" "$STAR/logs" 2>/dev/null

ad_log() { echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$LOG" 2>/dev/null; }

ad_tier() {
  adg_v=0
  if [ -f "$STAR/pro.conf" ]; then
    adg_v=$(sed -n 's/^tier=//p' "$STAR/pro.conf" 2>/dev/null | head -n 1)
  fi
  case "$adg_v" in
    ''|*[!0-9]*) echo 0 ;;
    *) echo "$adg_v" ;;
  esac
}

ad_gate() {
  [ "$(ad_tier)" -ge 2 ] && return 0
  echo "星净是 Pro+ / 终身版功能,当前等级不够" >&2
  return 5
}

# ---------------------------------------------------------------- 内置规则
# 首次使用时落一份默认名单(只写一次,之后用户改过就不再覆盖)
ad_seed() {
  [ -f "$BLOCK" ] && return 0
  {
    echo "# Star OS 星净 · 广告与统计域名(一行一个,# 开头是注释)"
    echo "# 想加就往下写;改完点「重建并开启」重新生效。"
    echo "googleads.g.doubleclick.net"
    echo "pagead2.googlesyndication.com"
    echo "adservice.google.com"
    echo "admob.com"
    echo "doubleclick.net"
    echo "umeng.com"
    echo "umengcloud.com"
    echo "umeng.co"
    echo "cnzz.com"
    echo "cnzz.net"
    echo "zjtcn.com"
    echo "talkingdata.com"
    echo "talkingdata.net"
    echo "gdt.qq.com"
    echo "e.qq.com"
    echo "pingjs.qq.com"
    echo "hm.baidu.com"
    echo "pos.baidu.com"
    echo "mobads.baidu.com"
    echo "tongji.baidu.com"
    echo "ad.360in.com"
    echo "admaster.com.cn"
    echo "miaozhen.com"
    echo "adcolony.com"
    echo "applovin.com"
    echo "unityads.unity3d.com"
    echo "vungle.com"
    echo "chartboost.com"
    echo "tapjoy.com"
    echo "inmobi.com"
    echo "mopub.com"
    echo "adjust.com"
    echo "appsflyer.com"
    echo "branch.io"
    echo "kochava.com"
    echo "miaozhen.com.cn"
    echo "mmstat.com"
    echo "mmstat.com.cn"
  } > "$BLOCK"
  ad_log "seed block.list"
}

ad_rule_count() {
  adr_n=$(grep -v -c "^#" "$BLOCK" 2>/dev/null)
  case "$adr_n" in ''|*[!0-9]*) adr_n=0 ;; esac
  echo "$adr_n"
}

# 生成 hosts(bind 用)
ad_build() {
  ad_seed
  true > "$HOSTS"
  echo "# STAROS-ADBLOCK (不要手改这个文件,改 block.list)" >> "$HOSTS"
  echo "127.0.0.1 localhost" >> "$HOSTS"
  echo "::1 localhost" >> "$HOSTS"
  grep -v "^#" "$BLOCK" 2>/dev/null | while read -r adb_d; do
    [ -z "$adb_d" ] && continue
    echo "127.0.0.1 $adb_d" >> "$HOSTS"
  done
  ad_log "build hosts ($(ad_rule_count) 条)"
}

# 当前有没有挂上(认我们文件头那句标记)
ad_active() {
  grep -q "STAROS-ADBLOCK" "$TARGET" 2>/dev/null && echo 1 || echo 0
}

ad_on() {
  ad_build
  # 先摘掉旧的(可能上次没摘干净),再挂
  umount "$TARGET" >/dev/null 2>&1
  if mount -o bind "$HOSTS" "$TARGET" >/dev/null 2>&1; then
    if [ "$(ad_active)" = "1" ]; then
      echo "on" > "$AD/state"
      echo "广告拦截已开启,当前 $(ad_rule_count) 条域名指向 127.0.0.1。"
      ad_log "on"
      return 0
    fi
  fi
  echo "开启失败(这台机器可能不允许挂载)。原文件没动过,系统不受影响。" >&2
  ad_log "on failed"
  return 1
}

ad_off() {
  umount "$TARGET" >/dev/null 2>&1
  echo "off" > "$AD/state"
  if [ "$(ad_active)" = "1" ]; then
    echo "没能摘下来(可能被占用),重启后一定恢复。"
    ad_log "off failed"
    return 1
  fi
  echo "广告拦截已关闭,hosts 完全恢复原样。"
  ad_log "off"
  return 0
}

ad_status() {
  adr=$(ad_rule_count)
  if [ "$(ad_active)" = "1" ]; then
    echo "拦截状态:已开启 ($adr 条规则)"
  else
    echo "拦截状态:关"
  fi
  echo "规则文件:$BLOCK"
  echo ""
  if [ "$(ad_active)" = "1" ]; then
    echo "@item|关闭广告拦截(恢复原 hosts)|act|off"
    echo "@item|改完规则了,重建并重挂|act|rebuild"
  else
    echo "@item|开启广告拦截($adr 条规则)|act|on"
  fi
  return 0
}

case "$1" in
  meta)
    echo "adblock|星净|用 hosts 拦掉广告和统计域名,应用照常用|2|toggle:开关广告拦截:pri,rebuild:重建规则:ghost"
    ;;
  status)
    ad_gate || exit 5
    ad_status
    ;;
  act)
    ad_gate || exit 5
    case "$2" in
      on) ad_on ;;
      off) ad_off ;;
      toggle)
        if [ "$(ad_active)" = "1" ]; then ad_off; else ad_on; fi
        ;;
      rebuild)
        if [ "$(ad_active)" = "1" ]; then
          ad_on
        else
          ad_build
          echo "规则已重建($(ad_rule_count) 条)。开启时生效。"
        fi
        ;;
      apply)
        # 供 daemon / 开机恢复:名单非空但没挂上就补挂
        if [ "$(ad_rule_count)" -gt 0 ] && [ "$(ad_active)" != "1" ]; then
          ad_on >/dev/null 2>&1
          echo "已补挂 hosts"
        fi
        ;;
      *)
        echo "未知动作:$2" >&2
        exit 2
        ;;
    esac
    ;;
  daemon)
    ad_log "星净 daemon 启动 (pid=$$)"
    while true; do
      if [ "$(sed -n '1p' "$AD/state" 2>/dev/null)" = "on" ]; then
        [ "$(ad_active)" != "1" ] && ad_on >/dev/null 2>&1
      fi
      sleep 600
    done
    ;;
  *)
    echo "用法:$0 {meta|status|act <动作>|daemon}" >&2
    exit 2
    ;;
esac
