#!/system/bin/sh
# ============================================================================
#  Star OS · 星守 (selfheal.sh)   —— 基础功能(免费)
#  ===========================================================
#  统一工具协议见 tools/power.sh 开头。
#
#  干的事:开机后默默看一眼关键组件还在不在;某一项反复崩溃时,
#        把"我们自己塞进去的那份"临时撤掉,让系统回到原版继续开机。
#        这样最坏情况是"功能没了",而不是"开不了机只能线刷"。
#
#  什么时候动手:
#    - 只在确认是【崩溃循环】时才撤,阈值 5 次,单次崩溃不碰
#    - 撤掉的是模块自己的 overlay(比如 XTCSystemUI),原版随之生效
#    - 每次动作都写进 selfheal.log,工具箱里能看
#
#  数据:内部存储/StarOS/selfheal/  (自检结果 + 已降级清单)
# ============================================================================

PWDIR=${0%/*}
[ -d "$PWDIR" ] || PWDIR=/data/adb/modules/zz_star_os/tools
MODD=${PWDIR%/*}
[ -d "$MODD" ] || MODD=/data/adb/modules/zz_star_os
STAR=${STAR_DIR:-/data/adb/star_os}
SL=$STAR/selfheal
LOG=$STAR/logs/selfheal.log
ITEMS=$SL/items.txt
DOWN=$SL/downgraded.txt
mkdir -p "$SL" "$STAR/logs" 2>/dev/null

THRESH=5

sh_log() { echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$LOG" 2>/dev/null; }

# 崩溃缓冲区里与该进程相关的条数(8.1 没有 awk,只数行)
sh_crash() {
  sh_c_n=$(logcat -d -b crash 2>/dev/null | grep -c "$1" 2>/dev/null)
  [ -z "$sh_c_n" ] && sh_c_n=0
  echo "$sh_c_n"
}

sh_alive() {
  # pidof 在 8.1 上可用;找不到就退回 ps
  if command -v pidof >/dev/null 2>&1; then
    pidof "$1" >/dev/null 2>&1 && return 0
  fi
  ps 2>/dev/null | grep "$1" | grep -v grep >/dev/null 2>&1
}

# 模块是否在用 overlay 顶替某个系统应用
sh_overlay_on() {
  [ -d "$MODD/system/priv-app/$1" ] && [ ! -d "$MODD/system/priv-app/$1.disabled" ]
}

# ---------------------------------------------------------------------------
# 自检:结果写成 key|状态|说明(状态 1=正常 0=异常)
# ---------------------------------------------------------------------------
sh_check() {
  true > "$ITEMS"
  sh_bad=0

  # 1. 模块本体装没装
  if pm path com.staros.app >/dev/null 2>&1; then
    echo "app|1|StarOS 已安装" >> "$ITEMS"
  else
    echo "app|0|StarOS 未安装或包名失效" >> "$ITEMS"
    sh_bad=$((sh_bad+1))
  fi

  # 2. 关键 overlay 是否真的挂上了
  if mount 2>/dev/null | grep -q "zz_star_os"; then
    echo "mount|1|模块已挂载" >> "$ITEMS"
  else
    echo "mount|0|模块未挂载(Magisk 里是否启用?)" >> "$ITEMS"
    sh_bad=$((sh_bad+1))
  fi

  # 3. SystemUI 活着吗
  if sh_alive "com.xtc.systemui"; then
    echo "sysui|1|SystemUI 运行中" >> "$ITEMS"
  else
    sh_c_crash=$(sh_crash "com.xtc.systemui")
    if [ "$sh_c_crash" -ge "$THRESH" ]; then
      echo "sysui|0|SystemUI 未运行且崩溃 $sh_c_crash 次" >> "$ITEMS"
      sh_bad=$((sh_bad+1))
    else
      echo "sysui|0|SystemUI 未运行(可能刚重启)" >> "$ITEMS"
      sh_bad=$((sh_bad+1))
    fi
  fi

  # 4. 桌面活着吗
  if sh_alive "xtclauncher" || sh_alive "com.xtc.launcher"; then
    echo "home|1|桌面运行中" >> "$ITEMS"
  else
    echo "home|0|桌面未运行" >> "$ITEMS"
    sh_bad=$((sh_bad+1))
  fi

  # 5. 存储余量(低于 300MB 会影响升级/截图)
  sh_av=$(df /data 2>/dev/null | tail -n 1 | sed 's/  */ /g' | cut -d' ' -f4)
  [ -z "$sh_av" ] && sh_av=0
  sh_mb=$((sh_av/1024))
  if [ "$sh_mb" -ge 300 ]; then
    echo "disk|1|可用 ${sh_mb}MB" >> "$ITEMS"
  else
    echo "disk|0|存储仅剩 ${sh_mb}MB" >> "$ITEMS"
    sh_bad=$((sh_bad+1))
  fi

  # 6. 已降级清单
  if [ -s "$DOWN" ]; then
    echo "down|0|有 $(grep -c . "$DOWN") 项已被降级(见下)" >> "$ITEMS"
  else
    echo "down|1|没有降级项" >> "$ITEMS"
  fi

  echo "$sh_bad" > "$SL/last_bad"
  date '+%Y-%m-%d %H:%M:%S' > "$SL/last_time"
  echo "$sh_bad"
}

# ---------------------------------------------------------------------------
# 自愈:只处理崩溃循环,而且是模块自己塞进去的那份
# ---------------------------------------------------------------------------
sh_heal() {
  sh_did=0

  # SystemUI 崩溃循环 -> 撤掉模块的 XTCSystemUI overlay
  if sh_overlay_on "XTCSystemUI" && ! sh_alive "com.xtc.systemui"; then
    sh_c=$(sh_crash "com.xtc.systemui")
    if [ "$sh_c" -ge "$THRESH" ]; then
      mv "$MODD/system/priv-app/XTCSystemUI" "$MODD/system/priv-app/XTCSystemUI.disabled" 2>/dev/null
      if [ -d "$MODD/system/priv-app/XTCSystemUI.disabled" ]; then
        echo "$(date '+%Y-%m-%d %H:%M')|XTCSystemUI|SystemUI 崩溃 $sh_c 次,已撤掉模块版本" >> "$DOWN"
        sh_log "heal: 撤掉 XTCSystemUI(崩溃 $sh_c 次)"
        sh_did=$((sh_did+1))
        # 让 zygote 重新拉起 SystemUI
        am force-stop com.xtc.systemui >/dev/null 2>&1
      fi
    fi
  fi

  # 崩溃缓冲区留太大反而会滚丢证据,顺手清一次
  logcat -b crash -c >/dev/null 2>&1

  echo "$sh_did"
}

# ---------------------------------------------------------------------------
sh_status() {
  if [ -f "$ITEMS" ]; then
    sh_t=$(cat "$SL/last_time" 2>/dev/null)
    sh_b=$(cat "$SL/last_bad" 2>/dev/null)
    echo "上次自检:${sh_t:-还没跑过}"
    if [ "${sh_b:-0}" = "0" ]; then
      echo "结果:全部正常"
    else
      echo "结果:$sh_b 项异常"
    fi
    echo ""
    while IFS='|' read -r k st msg; do
      [ -z "$k" ] && continue
      if [ "$st" = "1" ]; then echo "  ✓ $msg"; else echo "  ! $msg"; fi
    done < "$ITEMS"
  else
    echo "还没跑过自检。"
  fi

  if [ -s "$DOWN" ]; then
    echo ""
    echo "已降级:"
    sed 's/^/  /' "$DOWN" 2>/dev/null | tail -n 5
  fi

  echo ""
  echo "崩溃阈值:$THRESH 次;过了才会撤模块版本,不是每次崩都动。"
  echo ""
  echo "@item|立即自检|act|check"
  echo "@item|试一次自愈|act|heal"
  return 0
}

case "$1" in
  meta)
    echo "selfheal|星守|开机自检,某项反复崩溃就撤掉模块版本,避免开不了机|0|check:立即自检:pri,heal:试一次自愈:ghost"
    ;;
  status)
    sh_status
    ;;
  act)
    case "$2" in
      check)
        sh_check >/dev/null
        sh_status
        ;;
      heal)
        sh_n=$(sh_heal)
        if [ "$sh_n" = "0" ]; then
          echo "没有需要自愈的项目。"
        else
          echo "已处理 $sh_n 项,重启后生效。"
        fi
        ;;
      daemon)
        # 开机后先等系统稳定,再做一次自检 + 自愈
        sleep 90
        sh_check >/dev/null
        sh_heal >/dev/null
        sh_log "daemon: 开机自检完成"
        ;;
      *)
        echo "未知动作:$2" >&2
        exit 2
        ;;
    esac
    ;;
  *)
    echo "用法:$0 {meta|status|act <动作>}" >&2
    exit 2
    ;;
esac
