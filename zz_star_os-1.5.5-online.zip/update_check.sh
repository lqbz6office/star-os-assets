#!/system/bin/sh
##########################################################################
#  update_check.sh —— Star OS:「检查更新」(刷入时顺手看一眼)
#
#  只定义函数,自身不执行任何动作。customize.sh 在资源包处理完之后调用一次:
#        . "$MODPATH/update_check.sh"
#        auc_check "$MODPATH"
#
#  ── 和 Magisk 内置更新的分工(两件事,别混)────────────────────────
#  * Magisk 模块页那个「更新」按钮 —— 由 module.prop 里的
#        updateJson=https://cdn.jsdelivr.net/gh/lqbz6office/star-os-assets@main/update.json
#    驱动。Magisk 自己去拉这个 JSON、自己比对 versionCode、自己下载安装,
#    **不需要本文件参与一个字**。这是"手动检测"。
#  * 本文件负责"安装时检测":刷入的这一刻顺手看一眼远端有没有更新的版本,
#    有就当场告诉用户 —— 免得他刚装完一个旧包又要再折腾一次。这是"安装时检测"。
#
#  ── 三条硬约束 ───────────────────────────────────────────────────
#  1) 绝不影响安装:任何失败只打印一行说明并返回非 0,永不 abort。
#  2) 绝不拖时间:每个地址最多 AUC_WAIT 秒,总共最多试 AUC_TRIES 个地址。
#     默认 6s × 2 = 最坏 12s;若已知没网(customize.sh 会调低到 1 × 4s)。
#  3) 不引入依赖:JSON 是我们自己写的,用 sed 取字段就够,不需要 jq。
#
#  ── ⚠ 变量命名铁律(和 assets_fetch.sh 同源)──────────────────────
#  ash / sh **没有 local**,函数内变量全是全局的。曾经因为 af_progress 用了
#  af_dl 的变量名,把"下载目标路径"覆盖成 "3",导致 `: > 3/dl_err.log` 让
#  整个刷入脚本被终止(2026-10-01 手表实测)。所以这里照旧:
#     每个函数独占前缀 —— _aucg_ 下载 / _aucj_ 解析 / _aucc_ 主流程
#     AUC_ 全大写 = 配置(可跨函数读)
#  改完记得跑工作区根的 check_vars.py 静态检查。
##########################################################################

# 输出出口:默认 stdout;customize.sh 会把它接成 ui_print 进刷入日志
if ! command -v af_out >/dev/null 2>&1; then
  af_out() { echo "$*"; }
fi

# ---------------------------------------------------------------------------
# update.json 的位置(按优先级)
#
#  ⚠ 为什么 jsDelivr 排第一:
#    国内直连 raw.githubusercontent.com 常年不通(本机实测 HTTP 000,15s 超时)。
#    cdn.jsdelivr.net 是纯 CDN,实测 1.5s 可达,且不经过被墙的域名。
#    gh-proxy.com / ghfast.top 是 GitHub 反代,作为第二、第三梯队。
#    最后才轮到 raw 原始地址(给网络没被限制的环境用)。
#
#  注:jsDelivr 对分支引用(@main)有最长约 12 小时的缓存。
#     对"安装时检测"没有影响 —— 用户装的如果是当次刚发的包,远端本来就不更新;
#     装的如果是旧包,那时距发布早就超过 12 小时了。
# ---------------------------------------------------------------------------
AUC_URLS="
https://cdn.jsdelivr.net/gh/lqbz6office/star-os-assets@main/update.json
https://gh-proxy.com/https://raw.githubusercontent.com/lqbz6office/star-os-assets/main/update.json
https://ghfast.top/https://raw.githubusercontent.com/lqbz6office/star-os-assets/main/update.json
https://raw.githubusercontent.com/lqbz6office/star-os-assets/main/update.json"

AUC_TMP="/data/local/tmp"   # 落盘目录(拿不到就退到 /tmp)
AUC_WAIT=6                  # 单个地址最多等几秒
AUC_TRIES=2                 # 最多试几个地址

# ---------------------------------------------------------------------------
# 下载一个小文件(几 KB,不需要看门狗)
#
# ⚠ 只用**一个**下载工具,不做"这个不行换下一个"的轮询:
#   每个工具都要各自等满一次 AUC_WAIT,三个都试会让最坏耗时变成三倍 ——
#   而这是个"顺手看一眼"的检查,不值得为它拖慢安装。
#   刷入时 Magisk 已经把自带 busybox 加进 PATH,所以 wget 基本总可用;
#   curl 只有少数定制 ROM 才带,但在的话它最省事。
#   toybox wget 不支持超时参数,列进来会变成"可能永远挂着"的风险,故意不列。
# ---------------------------------------------------------------------------
auc_get() {
  _aucg_u="$1"
  _aucg_o="$2"
  rm -f "$_aucg_o" 2>/dev/null

  if command -v curl >/dev/null 2>&1; then
    curl -fsSL -m "$AUC_WAIT" --connect-timeout 5 -o "$_aucg_o" "$_aucg_u" 2>/dev/null
  elif command -v wget >/dev/null 2>&1; then
    wget -q -T "$AUC_WAIT" -O "$_aucg_o" "$_aucg_u" 2>/dev/null
  elif [ -x /data/adb/magisk/busybox ]; then
    /data/adb/magisk/busybox wget -q -T "$AUC_WAIT" -O "$_aucg_o" "$_aucg_u" 2>/dev/null
  fi

  [ -s "$_aucg_o" ] && return 0
  rm -f "$_aucg_o" 2>/dev/null
  return 1
}

# ---------------------------------------------------------------------------
# 从 JSON 里取一个字段
#   auc_field <文件> <字段名> <num|str>
#   数字字段(versionCode)只认 [0-9];字符串字段取引号里的内容。
#   取不到就输出空串 —— 调用方靠"空串"判定这份清单不可信。
# ---------------------------------------------------------------------------
auc_field() {
  _aucj_f="$1"
  _aucj_k="$2"
  _aucj_t="$3"
  [ -f "$_aucj_f" ] || return 0

  if [ "$_aucj_t" = "num" ]; then
    sed -n 's/.*"'"$_aucj_k"'"[[:space:]]*:[[:space:]]*\([0-9][0-9]*\).*/\1/p' \
      "$_aucj_f" 2>/dev/null | head -n 1 | tr -d ' \t\r'
  else
    sed -n 's/.*"'"$_aucj_k"'"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' \
      "$_aucj_f" 2>/dev/null | head -n 1 | tr -d '\r'
  fi
  return 0
}

# ---------------------------------------------------------------------------
# auc_check <模块目录>
#   返回 0 = 有新版(已打印提示)
#        1 = 已是最新
#        2 = 没能确认(没网 / 地址全不通 / 清单不合法)
#   三种情况都只打印一行,绝不中止安装。
# ---------------------------------------------------------------------------
auc_check() {
  _aucc_dir="$1"
  _aucc_prop="$_aucc_dir/module.prop"
  [ -f "$_aucc_prop" ] || return 2

  # 本地版本(以 module.prop 为准,不依赖环境变量)
  _aucc_lvc=$(sed -n 's/^versionCode=\([0-9][0-9]*\).*/\1/p' "$_aucc_prop" 2>/dev/null \
             | head -n 1 | tr -d ' \t\r')
  case "$_aucc_lvc" in ''|*[!0-9]*) return 2 ;; esac
  _aucc_lver=$(sed -n 's/^version=\(.*\)$/\1/p' "$_aucc_prop" 2>/dev/null \
              | head -n 1 | tr -d ' \t\r')

  # 落盘目录:优先 /data/local/tmp,拿不到就用 /tmp
  _aucc_t="$AUC_TMP"
  mkdir -p "$_aucc_t" 2>/dev/null
  [ -d "$_aucc_t" ] || _aucc_t="/tmp"
  _aucc_json="$_aucc_t/star_os_update.json"
  rm -f "$_aucc_json" 2>/dev/null

  _aucc_n=0
  _aucc_ok=0
  _aucc_rvc=""
  _aucc_rver=""
  _aucc_url=""

  for _aucc_u in $AUC_URLS; do
    [ "$_aucc_n" -ge "$AUC_TRIES" ] && break
    _aucc_n=$((_aucc_n + 1))

    auc_get "$_aucc_u" "$_aucc_json" || continue

    # 必须真是我们的清单:versionCode 得是个数字。
    # (镜像返回的错误页 / HTML 也都是"非空文件",不校验就会被当成有效 JSON)
    _aucc_try=$(auc_field "$_aucc_json" versionCode num)
    case "$_aucc_try" in ''|*[!0-9]*) continue ;; esac

    _aucc_ok=1
    _aucc_rvc="$_aucc_try"
    _aucc_rver=$(auc_field "$_aucc_json" version str)
    _aucc_url="$_aucc_u"
    break
  done

  rm -f "$_aucc_json" 2>/dev/null

  if [ "$_aucc_ok" != "1" ]; then
    af_out "- 检查更新:这次没能联网确认(不影响安装)"
    return 2
  fi

  if [ "$_aucc_rvc" -le "$_aucc_lvc" ]; then
    af_out "- 检查更新:当前已是最新版 ${_aucc_lver:-$_aucc_lvc}"
    return 1
  fi

  # ---- 有新版 ----
  af_out ' '
  af_out '=========================================='
  af_out '  发现新版本!'
  af_out "    最新:${_aucc_rver:-?}  (versionCode ${_aucc_rvc})"
  af_out "    当前:${_aucc_lver:-?}  (versionCode ${_aucc_lvc})"
  af_out ' '
  af_out '  升级方法(二选一):'
  af_out '   1. Magisk -> 模块 -> Star OS -> 点「更新」'
  af_out '      (没看到更新按钮就下拉刷新一次)'
  af_out '   2. 直接把新版 zip 下到手表,从本地安装'
  af_out '  注:在线更新装的是"在线版"(体积小),'
  af_out '     需要离线全量版请手动下载 full 包。'
  af_out '=========================================='
  af_out ' '
  return 0
}
