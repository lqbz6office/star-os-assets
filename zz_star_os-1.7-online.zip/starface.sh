#!/system/bin/sh
# ============================================================================
#  Star OS · 表盘工坊 (starface.sh)   —— Pro+ / 终身版专属
#  ============================================================
#  手表上的"换装间":表盘 / 壁纸 / 图标包 三样素材,一键投放或撤下。
#
#  投放到哪儿(和主题应用 ThemePro 读的是同一处):
#      <内部存储>/Android/baiyao105/ThemePro/Themes/
#          dial/<名>.cl            表盘本体(本质是个 APK)
#          dial/res/<名>/*.png     表盘的三张预览图
#          theme_pack/<名>/        整套主题(壁纸 + 图标包 + 表盘配置)
#
#  素材库(下载/导入过来的包都堆这儿,不动系统):
#      /data/adb/star_os/face/
#          dial/<名>/<名>.cl + res/<名>/*.png
#          pack/<名>/...
#
#  ⚠ 为什么投放前要备份:这些目录里本来就有原厂/别人的素材,直接覆盖就找不
#    回来了。凡是"本来不存在"的东西撤下时直接删;凡是"本来存在"的,撤下时
#    从 .backup/ 还回去 —— 不误删、不残留。
#
#  用法:
#     starface.sh list [dial|pack]      列出素材库(id|类型|大小|是否已投放)
#     starface.sh installed             列出 Themes 下当前已投放的
#     starface.sh apply dial <名>
#     starface.sh apply pack <名>
#     starface.sh remove dial <名>
#     starface.sh remove pack <名>
#     starface.sh import <zip>          导入一个素材包到库里
#     starface.sh info <名>
# ============================================================================

SFDIR=${0%/*}
[ -d "$SFDIR" ] || SFDIR=/data/adb/modules/zz_star_os
STAR=/data/adb/star_os
LIB=$STAR/face
BAK=$LIB/.backup
LOG=$STAR/logs/starface.log

mkdir -p "$LIB/dial" "$LIB/pack" "$BAK" "$STAR/logs" 2>/dev/null

sf_log() { echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$LOG" 2>/dev/null; }

# Pro+ / 终身版门槛(本地闸门;真值在台账,由应用联网核对)
sf_tier() {
  sfg_v=0
  if [ -f "$STAR/pro.conf" ]; then
    sfg_v=$(sed -n 's/^tier=//p' "$STAR/pro.conf" 2>/dev/null | head -n 1)
  fi
  case "$sfg_v" in
    ''|*[!0-9]*) echo 0 ;;
    *) echo "$sfg_v" ;;
  esac
}

sf_gate() {
  [ "$(sf_tier)" -ge 2 ] && return 0
  echo "表盘工坊是 Pro+ / 终身版功能,当前等级不够" >&2
  return 5
}

# ---------------------------------------------------------------------------
# 内部存储与 Themes 根
# ---------------------------------------------------------------------------
sf_sd() {
  sfs_p="${STARFACE_SD_ROOT:-}"
  if [ -z "$sfs_p" ]; then
    for sfs_c in /sdcard /storage/emulated/0 /data/media/0; do
      if [ -d "$sfs_c/Android" ]; then sfs_p="$sfs_c"; break; fi
    done
  fi
  [ -n "$sfs_p" ] || { echo ""; return 1; }
  echo "$sfs_p"
}

sf_themes() {
  sft_sd=$(sf_sd) || return 1
  echo "$sft_sd/Android/baiyao105/ThemePro/Themes"
}

sf_du() {
  # 人类可读大小(没有 du 就报文件数)
  sfd_s=$(du -sk "$1" 2>/dev/null | head -n 1 | cut -f1)
  if [ -n "$sfd_s" ]; then
    sfd_k=$((sfd_s + 0))
    if [ "$sfd_k" -ge 1024 ]; then
      echo "$((sfd_k / 1024))MB"
    else
      echo "${sfd_k}KB"
    fi
  else
    echo "?"
  fi
}

# 是不是已经投放了
sf_deployed() {
  # $1=类型 $2=名
  sfd_t=$(sf_themes) || { echo 0; return; }
  case "$1" in
    dial) [ -f "$sfd_t/dial/$2.cl" ] && echo 1 || echo 0 ;;
    pack) [ -d "$sfd_t/theme_pack/$2" ] && echo 1 || echo 0 ;;
    *) echo 0 ;;
  esac
}

# ---------------------------------------------------------------------------
# 备份 / 还原
# ---------------------------------------------------------------------------
sf_backup() {
  # $1=类型 $2=名 —— 只在"原本就存在"时备份一次
  sfb_t=$(sf_themes) || return 0
  sfb_k="$1__$2"
  [ -e "$BAK/$sfb_k.flag" ] && return 0
  case "$1" in
    dial)
      if [ -f "$sfb_t/dial/$2.cl" ]; then
        mkdir -p "$BAK/dial" 2>/dev/null
        cp -f "$sfb_t/dial/$2.cl" "$BAK/dial/$2.cl" 2>/dev/null
        [ -d "$sfb_t/dial/res/$2" ] && {
          mkdir -p "$BAK/dial/res" 2>/dev/null
          cp -r "$sfb_t/dial/res/$2" "$BAK/dial/res/" 2>/dev/null
        }
        echo existed > "$BAK/$sfb_k.flag" 2>/dev/null
      else
        echo absent > "$BAK/$sfb_k.flag" 2>/dev/null
      fi
      ;;
    pack)
      if [ -d "$sfb_t/theme_pack/$2" ]; then
        mkdir -p "$BAK/pack" 2>/dev/null
        cp -r "$sfb_t/theme_pack/$2" "$BAK/pack/" 2>/dev/null
        echo existed > "$BAK/$sfb_k.flag" 2>/dev/null
      else
        echo absent > "$BAK/$sfb_k.flag" 2>/dev/null
      fi
      ;;
  esac
  return 0
}

sf_restore_one() {
  # $1=类型 $2=名
  sfr_t=$(sf_themes) || return 1
  sfr_k="$1__$2"
  sfr_st=$(cat "$BAK/$sfr_k.flag" 2>/dev/null)
  case "$sfr_st" in
    existed)
      case "$1" in
        dial)
          cp -f "$BAK/dial/$2.cl" "$sfr_t/dial/$2.cl" 2>/dev/null
          [ -d "$BAK/dial/res/$2" ] && cp -rf "$BAK/dial/res/$2" "$sfr_t/dial/res/" 2>/dev/null
          ;;
        pack)
          mkdir -p "$sfr_t/theme_pack" 2>/dev/null
          cp -rf "$BAK/pack/$2" "$sfr_t/theme_pack/" 2>/dev/null
          ;;
      esac
      sf_log "restore $1/$2 (还原原有素材)"
      ;;
    *)
      # 本来就是没有的 → 撤下 = 删掉自己投放的那份
      case "$1" in
        dial) rm -f "$sfr_t/dial/$2.cl" 2>/dev/null
              rm -rf "$sfr_t/dial/res/$2" 2>/dev/null ;;
        pack) rm -rf "$sfr_t/theme_pack/$2" 2>/dev/null ;;
      esac
      sf_log "restore $1/$2 (本来不存在,已清除)"
      ;;
  esac
  rm -f "$BAK/$sfr_k.flag" 2>/dev/null
  return 0
}

# ---------------------------------------------------------------------------
# 投放
# ---------------------------------------------------------------------------
sf_apply_dial() {
  sfa_n=$1
  sfa_src="$LIB/dial/$sfa_n"
  [ -f "$sfa_src/$sfa_n.cl" ] || { echo "库里没有这个表盘: $sfa_n" >&2; return 3; }
  sfa_t=$(sf_themes) || { echo "找不到内部存储" >&2; return 4; }

  sf_backup dial "$sfa_n"
  mkdir -p "$sfa_t/dial/res" 2>/dev/null
  cp -f "$sfa_src/$sfa_n.cl" "$sfa_t/dial/$sfa_n.cl" 2>/dev/null || {
    echo "复制表盘失败" >&2; return 5; }
  if [ -d "$sfa_src/res/$sfa_n" ]; then
    mkdir -p "$sfa_t/dial/res/$sfa_n" 2>/dev/null
    cp -f "$sfa_src/res/$sfa_n/."* "$sfa_t/dial/res/$sfa_n/" 2>/dev/null
  fi
  sf_log "apply dial $sfa_n -> $sfa_t/dial"
  echo "ok dial $sfa_n"
  return 0
}

sf_apply_pack() {
  sfa_n=$1
  sfa_src="$LIB/pack/$sfa_n"
  [ -d "$sfa_src" ] || { echo "库里没有这个主题包: $sfa_n" >&2; return 3; }
  sfa_t=$(sf_themes) || { echo "找不到内部存储" >&2; return 4; }

  sf_backup pack "$sfa_n"
  mkdir -p "$sfa_t/theme_pack" 2>/dev/null
  cp -rf "$sfa_src" "$sfa_t/theme_pack/" 2>/dev/null || {
    echo "复制主题包失败" >&2; return 5; }
  sf_log "apply pack $sfa_n -> $sfa_t/theme_pack"
  echo "ok pack $sfa_n"
  return 0
}

# ---------------------------------------------------------------------------
# 导入素材包(zip;插件下载完调这个)
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# 在线表盘源(Star OS 官方)
# ---------------------------------------------------------------------------
SF_REPO=lqbz6office/star-os-assets

# 下载:优先 curl,退回 wget;相对路径自动补 raw 直链
sf_dl() {
  sfd_rel=$1
  sfd_out=$2
  case "$sfd_rel" in
    http*) sfd_full="$sfd_rel" ;;
    *) sfd_full="https://raw.githubusercontent.com/$SF_REPO/main/$sfd_rel" ;;
  esac
  if command -v curl >/dev/null 2>&1; then
    curl -L -sS --max-time 900 -o "$sfd_out" "$sfd_full" >/dev/null 2>&1 && return 0
  fi
  if command -v wget >/dev/null 2>&1; then
    wget -q -O "$sfd_out" "$sfd_full" >/dev/null 2>&1 && return 0
  fi
  return 1
}

# 从在线表盘源拉一个表盘进素材库(装完就能 apply)
sf_fetch() {
  sff_id=$1
  [ -n "$sff_id" ] || { echo "用法: starface.sh fetch <表盘id|完整URL>" >&2; exit 2; }
  sf_gate || exit 5
  case "$sff_id" in
    http*) sff_url="$sff_id" ;;
    *[!a-z0-9-]*)
      echo "表盘 id 只能是小写字母、数字与横线: $sff_id" >&2
      exit 2 ;;
    *) sff_url="dials/$sff_id/$sff_id.cl" ;;
  esac
  mkdir -p "$LIB/dial/$sff_id" 2>/dev/null
  sff_out="$LIB/dial/$sff_id/$sff_id.cl"
  echo "正在下载表盘:$sff_id"
  if ! sf_dl "$sff_url" "$sff_out"; then
    echo "下载失败 —— 检查网络,或先用浏览器下好再 import" >&2
    sf_log "fetch $sff_id 失败"
    exit 4
  fi
  sff_sz=$(wc -c < "$sff_out" 2>/dev/null | tr -d ' ')
  if [ -z "$sff_sz" ] || [ "$sff_sz" -lt 1024 ]; then
    echo "下下来的文件不对(${sff_sz:-0} 字节),已丢弃" >&2
    rm -f "$sff_out" 2>/dev/null
    exit 4
  fi
  # 预览图有就顺带拉,没有不影响
  sf_dl "dials/$sff_id/preview.png" "$LIB/dial/$sff_id/preview.png" || true
  echo "已导入表盘:$sff_id ($sff_sz 字节)"
  echo "接着可以:starface.sh apply dial $sff_id"
  sf_log "fetch $sff_id $sff_sz"
  return 0
}

# 列出在线表盘源里有哪些(读 index.json,不下载)
sf_remote() {
  sf_gate || exit 5
  sfr_tmp="/data/local/tmp/.sos_dial_index_$$"
  if ! sf_dl "dials/index.json" "$sfr_tmp"; then
    echo "读不到在线表盘源(网络问题)" >&2
    exit 4
  fi
  echo "在线表盘源:"
  sed -n 's/.*"name": *"\([^"]*\)".*/  \1/p' "$sfr_tmp" 2>/dev/null | head -50
  sfr_n=$(grep -c '"sha256"' "$sfr_tmp" 2>/dev/null)
  echo "共 ${sfr_n:-0} 个"
  rm -f "$sfr_tmp" 2>/dev/null
}

sf_import() {
  sfi_z=$1
  [ -f "$sfi_z" ] || { echo "没有这个文件: $sfi_z" >&2; return 3; }

  sfi_un=""
  if command -v unzip >/dev/null 2>&1; then
    sfi_un=unzip
  else
    for sfi_b in /data/adb/magisk/busybox /sbin/.magisk/busybox \
                 /data/adb/ksu/bin/busybox /system/xbin/busybox; do
      [ -x "$sfi_b" ] && { sfi_un="$sfi_b unzip"; break; }
    done
  fi
  [ -n "$sfi_un" ] || { echo "没有解压工具(8.1 不自带 unzip,也没找到 busybox)" >&2; return 4; }

  sfi_tmp="$STAR/tmp_face"
  rm -rf "$sfi_tmp" 2>/dev/null
  mkdir -p "$sfi_tmp" 2>/dev/null
  # shellcheck disable=SC2086
  $sfi_un -o "$sfi_z" -d "$sfi_tmp" >> "$LOG" 2>&1 || {
    echo "解压失败" >&2; return 5; }

  sfi_n=0
  # dial/<名>/... 或 pack/<名>/...
  for sfi_c in dial pack; do
    [ -d "$sfi_tmp/$sfi_c" ] || continue
    for sfi_d in "$sfi_tmp/$sfi_c"/*; do
      [ -d "$sfi_d" ] || continue
      sfi_name=$(basename "$sfi_d")
      mkdir -p "$LIB/$sfi_c" 2>/dev/null
      cp -rf "$sfi_d" "$LIB/$sfi_c/" 2>/dev/null && sfi_n=$((sfi_n + 1))
    done
  done
  rm -rf "$sfi_tmp" 2>/dev/null
  sf_log "import $sfi_z -> $sfi_n 项"
  echo "imported=$sfi_n"
  [ "$sfi_n" -gt 0 ] || { echo "包里没有 dial/ 或 pack/ 目录" >&2; return 6; }
  return 0
}

# ---------------------------------------------------------------------------
# 命令行
# ---------------------------------------------------------------------------
case "$1" in
  list)
    sfl_f=${2:-}
    for sfl_c in dial pack; do
      [ -z "$sfl_f" ] || [ "$sfl_f" = "$sfl_c" ] || continue
      for sfl_d in "$LIB/$sfl_c"/*; do
        [ -d "$sfl_d" ] || continue
        sfl_n=$(basename "$sfl_d")
        echo "$sfl_n|$sfl_c|$(sf_du "$sfl_d")|$(sf_deployed "$sfl_c" "$sfl_n")"
      done
    done
    ;;
  installed)
    sfi_t=$(sf_themes)
    if [ -z "$sfi_t" ] || [ ! -d "$sfi_t" ]; then
      echo "(找不到主题目录: $sfi_t)"
      exit 0
    fi
    for sfi_f in "$sfi_t/dial"/*.cl; do
      [ -f "$sfi_f" ] || continue
      basename "$sfi_f" .cl
    done | while read -r sfi_l; do echo "dial|$sfi_l"; done
    for sfi_p in "$sfi_t/theme_pack"/*; do
      [ -d "$sfi_p" ] || continue
      echo "pack|$(basename "$sfi_p")"
    done
    ;;
  apply)
    sf_gate || exit $?
    case "$2" in
      dial) sf_apply_dial "$3" ;;
      pack) sf_apply_pack "$3" ;;
      *) echo "用法: starface.sh apply {dial|pack} <名>" >&2; exit 2 ;;
    esac
    ;;
  remove)
    sf_gate || exit $?
    case "$2" in
      dial|pack) sf_restore_one "$2" "$3" && echo "ok remove $2 $3" ;;
      *) echo "用法: starface.sh remove {dial|pack} <名>" >&2; exit 2 ;;
    esac
    ;;
  fetch)
    sf_fetch "$2"
    ;;
  remote)
    sf_remote
    ;;
  import)
    sf_gate || exit $?
    sf_import "$2"
    ;;
  info)
    sfi_n2=$2
    if [ -d "$LIB/dial/$sfi_n2" ]; then
      echo "类型: 表盘"
      echo "大小: $(sf_du "$LIB/dial/$sfi_n2")"
      echo "已投放: $(sf_deployed dial "$sfi_n2")"
      ls -la "$LIB/dial/$sfi_n2" 2>/dev/null | tail -n +2
    elif [ -d "$LIB/pack/$sfi_n2" ]; then
      echo "类型: 主题包"
      echo "大小: $(sf_du "$LIB/pack/$sfi_n2")"
      echo "已投放: $(sf_deployed pack "$sfi_n2")"
    else
      echo "库里没有: $sfi_n2" >&2
      exit 3
    fi
    ;;
  where)
    sf_themes
    ;;
  *)
    echo "用法: starface.sh {list|installed|apply|remove|import|info|where} ..."
    exit 2
    ;;
esac
