#!/system/bin/sh
# ============================================================================
#  Star OS · 星约 (schedule.sh)   —— 基础功能(免费,人人可用)
#  ===========================================================
#  统一工具协议见 tools/power.sh 开头。
#
#  干的事:替你把几件"每天/每周该做一次"的事排上号 ——
#        · 每晚到点自动安静(勿扰 + 关震动);
#        · 每天半夜自动重启一次(手表跑几天会闷,重启最养机);
#        · 每周日半夜自动清一遍该清的(缓存 / 临时文件 / 我们的旧日志)。
#
#  为什么免费:能自己跑的活,不该逼着人记。人不在,表也得照常运转。
#
#  ⚠ 定时重启默认是**关**的 —— 它会真重启,想让表自己重启再打开。
# ============================================================================

PWDIR=${0%/*}
[ -d "$PWDIR" ] || PWDIR=/data/adb/modules/zz_star_os/tools
MODD=${PWDIR%/*}
[ -d "$MODD" ] || MODD=/data/adb/modules/zz_star_os
STAR=${STAR_DIR:-/data/adb/star_os}
SCH=$STAR/schedule
LOG=$STAR/logs/schedule.log
CONF=$SCH/conf

mkdir -p "$SCH" "$STAR/logs" 2>/dev/null

sc_log() { echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$LOG" 2>/dev/null; }

# conf 里每行形如:key=on|off HH:MM [dow]
sc_conf_init() {
  [ -f "$CONF" ] && return 0
  true > "$CONF"
  echo "mute=on 22:00" >> "$CONF"
  echo "reboot=off 04:00" >> "$CONF"
  echo "tidy=on 03:30 sun" >> "$CONF"
}

# 取某项的整行
sc_line() { sed -n "s/^$1=//p" "$CONF" 2>/dev/null | head -n 1; }

sc_enabled() {  # $1=key
  scl=$(sc_line "$1")
  case "$scl" in
    on*) echo on ;;
    *) echo off ;;
  esac
}

sc_time_of() {  # $1=key
  scl=$(sc_line "$1")
  sct=$(echo "$scl" | cut -d' ' -f2)
  case "$sct" in [0-2][0-9]:[0-5][0-9]) echo "$sct" ;; *) echo "--:--" ;; esac
}

sc_dow_of() {  # $1=key, 只对每周任务有意义
  scl=$(sc_line "$1")
  scd=$(echo "$scl" | cut -d' ' -f3)
  case "$scd" in sun|mon|tue|wed|thu|fri|sat) echo "$scd" ;; *) echo "" ;; esac
}

sc_set() {  # key enable time dow...
  scs_k=$1
  scs_e=$2
  scs_t=$3
  scs_d=$4
  scs_new="$(sc_line "$scs_k")"
  # 重写整份 conf,替换掉对应行
  true > "$CONF.tmp"
  scs_hit=0
  while read -r scs_l; do
    [ -z "$scs_l" ] && continue
    case "$scs_l" in
      "$scs_k"=*)
        echo "$scs_k=$scs_e $scs_t${scs_d:+ $scs_d}" >> "$CONF.tmp"
        scs_hit=1
        ;;
      *) echo "$scs_l" >> "$CONF.tmp" ;;
    esac
  done < "$CONF"
  [ "$scs_hit" = "0" ] && echo "$scs_k=$scs_e $scs_t${scs_d:+ $scs_d}" >> "$CONF.tmp"
  mv "$CONF.tmp" "$CONF" 2>/dev/null
}

sc_toggle() {  # $1=key
  sct_k=$1
  if [ "$(sc_enabled "$sct_k")" = "on" ]; then
    sc_set "$sct_k" off "$(sc_time_of "$sct_k")" "$(sc_dow_of "$sct_k")"
    echo "已关:$sct_k"
  else
    sc_set "$sct_k" on "$(sc_time_of "$sct_k")" "$(sc_dow_of "$sct_k")"
    echo "已开:$sct_k ($(sc_time_of "$sct_k"))"
  fi
  sc_log "toggle $sct_k -> $(sc_enabled "$sct_k")"
}

# ---------------------------------------------------------------- 动作
sc_do_mute() {
  if [ -f "$PWDIR/mute.sh" ]; then
    sh "$PWDIR/mute.sh" act quiet >/dev/null 2>&1
    sc_log "定时:已安静"
  fi
}

sc_do_tidy() {
  scd_n=0
  # 1) 我们自己的旧日志(留 200 行)
  for scd_l in "$STAR"/logs/*.log; do
    [ -f "$scd_l" ] || continue
    scd_sz=$(wc -c < "$scd_l" 2>/dev/null)
    case "$scd_sz" in ''|*[!0-9]*) continue ;; esac
    if [ "$scd_sz" -gt 262144 ]; then
      tail -n 200 "$scd_l" > "$scd_l.tmp" 2>/dev/null && mv "$scd_l.tmp" "$scd_l" 2>/dev/null
      scd_n=$((scd_n + 1))
    fi
  done
  # 2) 系统临时目录里的老东西(只清 3 天前的,不碰别的)
  find /data/local/tmp -type f -mtime +3 2>/dev/null | while read -r scd_f; do
    rm -f "$scd_f" 2>/dev/null
  done
  scd_n=$((scd_n + 1))
  sc_log "定时:清理完成 ($scd_n)"
  echo "已清理 $scd_n 项"
}

sc_do_reboot() {
  sc_log "定时:准备重启"
  # 先记一笔,免得重启后又触发一轮
  echo "$(date '+%Y%m%d')" > "$SCH/last_reboot"
  sync
  reboot
}

# ---------------------------------------------------------------- 每分钟 tick
sc_tick() {
  sc_conf_init
  sct_now=$(date '+%H:%M')
  sct_today=$(date '+%Y%m%d')
  sct_dow=$(date '+%a' | tr 'A-Z' 'a-z')

  # 昨晚的静音到点该醒了(早上 8 点自动还原)
  if [ "$(sc_enabled mute)" = "on" ] && [ "$sct_now" = "08:00" ]; then
    sct_done=$(cat "$SCH/last_unmute" 2>/dev/null)
    if [ "$sct_done" != "$sct_today" ]; then
      echo "$sct_today" > "$SCH/last_unmute"
      [ -f "$PWDIR/mute.sh" ] && sh "$PWDIR/mute.sh" act quiet >/dev/null 2>&1   # 再点一次=还原
      sc_log "定时:早上恢复声音"
    fi
  fi

  # 每晚静音
  if [ "$(sc_enabled mute)" = "on" ] && [ "$sct_now" = "$(sc_time_of mute)" ]; then
    sct_done=$(cat "$SCH/last_mute" 2>/dev/null)
    if [ "$sct_done" != "$sct_today" ]; then
      echo "$sct_today" > "$SCH/last_mute"
      sc_do_mute
    fi
  fi

  # 每日重启
  if [ "$(sc_enabled reboot)" = "on" ] && [ "$sct_now" = "$(sc_time_of reboot)" ]; then
    sct_done=$(cat "$SCH/last_reboot" 2>/dev/null)
    if [ "$sct_done" != "$sct_today" ]; then
      sc_do_reboot
    fi
  fi

  # 每周清理
  if [ "$(sc_enabled tidy)" = "on" ] && [ "$sct_now" = "$(sc_time_of tidy)" ]; then
    sct_dowant=$(sc_dow_of tidy)
    if [ -z "$sct_dowant" ] || [ "$sct_dow" = "$sct_dowant" ]; then
      sct_done=$(cat "$SCH/last_tidy" 2>/dev/null)
      if [ "$sct_done" != "$sct_today" ]; then
        echo "$sct_today" > "$SCH/last_tidy"
        sc_do_tidy >/dev/null 2>&1
      fi
    fi
  fi
}

sc_status() {
  sc_conf_init
  echo "每晚安静:$(sc_enabled mute) @ $(sc_time_of mute)(早上 08:00 自动恢复)"
  echo "每日重启:$(sc_enabled reboot) @ $(sc_time_of reboot)"
  echo "每周清理:$(sc_enabled tidy) @ $(sc_time_of tidy) $(sc_dow_of tidy)"
  echo ""
  echo "现在:$(date '+%m-%d %H:%M %a')"
  echo ""
  echo "@item|每晚安静 开/关|act|mute"
  echo "@item|每日重启 开/关|act|reboot"
  echo "@item|每周清理 开/关|act|tidy"
  echo "@item|立刻按计划跑一次|act|run"
  return 0
}

case "$1" in
  meta)
    echo "schedule|星约|每晚自动安静、定时重启、每周清理,排上就不用人管|0|mute:每晚安静:pri,reboot:定时重启:ghost,tidy:每周清理:ghost,run:立即执行:ghost"
    ;;
  status)
    sc_status
    ;;
  act)
    case "$2" in
      mute)   sc_toggle mute ;;
      reboot) sc_toggle reboot ;;
      tidy)   sc_toggle tidy ;;
      run)
        echo "按当前计划立刻执行一遍:"
        [ "$(sc_enabled mute)" = "on" ] && { sc_do_mute; echo "  安静 ✓"; }
        [ "$(sc_enabled reboot)" = "on" ] && echo "  重启:已排(会真重启,这里不立刻执行)"
        echo "  清理:"
        sc_do_tidy
        ;;
      *)
        echo "未知动作:$2" >&2
        exit 2
        ;;
    esac
    ;;
  tick)
    sc_tick
    ;;
  daemon)
    sc_log "星约 daemon 启动 (pid=$$)"
    while true; do
      "$0" tick >/dev/null 2>&1
      sleep 60
    done
    ;;
  *)
    echo "用法:$0 {meta|status|act <动作>|tick|daemon}" >&2
    exit 2
    ;;
esac
