#!/system/bin/sh
# ============================================================================
#  Star OS · 星数 (data.sh)   —— Pro+ / 终身版专属
#  ===========================================================
#  统一工具协议见 tools/power.sh 开头。
#
#  干的事:算清楚这块表"上网花了多少" —— 各网卡(WiFi / 流量)从开机到现在
#        一共收了多少、发了多少,现在跑多快。数据直接从内核的
#        /proc/net/dev 读,不再多装任何东西。
#
#  能干嘛:查"这个月流量怎么没了""连着 WiFi 怎么还在偷跑流量"、
#        修完网络看看到底通不通。
# ============================================================================

PWDIR=${0%/*}
[ -d "$PWDIR" ] || PWDIR=/data/adb/modules/zz_star_os/tools
MODD=${PWDIR%/*}
[ -d "$MODD" ] || MODD=/data/adb/modules/zz_star_os
STAR=${STAR_DIR:-/data/adb/star_os}
DA=$STAR/data
LOG=$STAR/logs/data.log

mkdir -p "$DA" "$STAR/logs" 2>/dev/null

da_log() { echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$LOG" 2>/dev/null; }

da_tier() {
  dav=0
  if [ -f "$STAR/pro.conf" ]; then
    dav=$(sed -n 's/^tier=//p' "$STAR/pro.conf" 2>/dev/null | head -n 1)
  fi
  case "$dav" in
    ''|*[!0-9]*) echo 0 ;;
    *) echo "$dav" ;;
  esac
}

da_gate() {
  [ "$(da_tier)" -ge 2 ] && return 0
  echo "星数是 Pro+ / 终身版功能,当前等级不够" >&2
  return 5
}

# 列出关心的网卡(排除回环和各种虚拟口)
da_ifaces() {
  for dai in $(sed -n 's/^[ 	]*\([a-z0-9][a-z0-9_]*\):.*/\1/p' /proc/net/dev 2>/dev/null); do
    case "$dai" in
      lo|dummy0|sit0|ip6tnl0|tunl0|gre0|gretap0|ifb0|ifb1|rmnet_ipa0|p2p0) continue ;;
    esac
    echo "$dai"
  done
}

# 取某网卡的"接收字节 发送字节"
da_bytes() {
  dab_l=$(sed -n "s/^[ 	]*$1: *//p" /proc/net/dev 2>/dev/null | head -n 1)
  [ -z "$dab_l" ] && { echo "0 0"; return 0; }
  dab_c=$(echo "$dab_l" | tr -s ' ')
  dab_rx=$(echo "$dab_c" | cut -d' ' -f1)
  dab_tx=$(echo "$dab_c" | cut -d' ' -f9)
  case "$dab_rx" in ''|*[!0-9]*) dab_rx=0 ;; esac
  case "$dab_tx" in ''|*[!0-9]*) dab_tx=0 ;; esac
  echo "$dab_rx $dab_tx"
}

da_hum() {  # 字节 -> 人看的单位
  dah_b=$1
  case "$dah_b" in ''|*[!0-9]*) echo "?" ; return 0 ;; esac
  if [ "$dah_b" -ge 1073741824 ]; then
    echo "$((dah_b / 1073741824)).$(( (dah_b % 1073741824) * 10 / 1073741824 )) GB"
  elif [ "$dah_b" -ge 1048576 ]; then
    echo "$((dah_b / 1048576)).$(( (dah_b % 1048576) * 10 / 1048576 )) MB"
  elif [ "$dah_b" -ge 1024 ]; then
    echo "$((dah_b / 1024)) KB"
  else
    echo "${dah_b} B"
  fi
}

da_status() {
  echo "各网卡累计(开机至今):"
  dad_any=0
  for dac in $(da_ifaces); do
    dad_b=$(da_bytes "$dac")
    dad_rx=$(echo "$dad_b" | cut -d' ' -f1)
    dad_tx=$(echo "$dad_b" | cut -d' ' -f2)
    case "$dad_rx$dad_tx" in 00|"") continue ;; esac
    echo "  $dac:收 $(da_hum "$dad_rx") / 发 $(da_hum "$dad_tx")"
    dad_any=1
  done
  [ "$dad_any" = "0" ] && echo "  (没读到有流量的网卡)"
  echo ""
  echo "点「测实时速率」会采样 3 秒,给出当前下载/上传速度。"
  echo ""
  echo "@item|测实时速率(3秒)|act|speed"
  return 0
}

da_speed() {
  dad_if=""
  dad_max=0
  # 挑一个当前最活跃的网卡(3 秒内字节增长最多的)
  dad_before=""
  for dab in $(da_ifaces); do
    dad_before="$dad_before $dab:$(da_bytes "$dab")"
  done
  sleep 3
  for dab in $(da_ifaces); do
    dad_old=$(echo "$dad_before" | tr ' ' '\n' | sed -n "s/^$dab://p" | head -n 1)
    case "$dad_old" in ''|*[!0-9\ ]*) continue ;; esac
    dad_orx=$(echo "$dad_old" | cut -d' ' -f1)
    dad_otx=$(echo "$dad_old" | cut -d' ' -f2)
    dad_new=$(dad_bytes "$dab")
    dad_nrx=$(echo "$dad_new" | cut -d' ' -f1)
    dad_ntx=$(echo "$dad_new" | cut -d' ' -f2)
    dad_d=$(( (dad_nrx - dad_orx) + (dad_ntx - dad_otx) ))
    if [ "$dad_d" -gt "$dad_max" ]; then
      dad_max=$dad_d
      dad_if=$dab
    fi
  done
  if [ -z "$dad_if" ]; then
    echo "没抓到活动网卡 —— 是不是没联网?"
    return 0
  fi
  dad_old=$(echo "$dad_before" | tr ' ' '\n' | sed -n "s/^$dad_if://p" | head -n 1)
  dad_orx=$(echo "$dad_old" | cut -d' ' -f1)
  dad_otx=$(echo "$dad_old" | cut -d' ' -f2)
  dad_new=$(da_bytes "$dad_if")
  dad_nrx=$(echo "$dad_new" | cut -d' ' -f1)
  dad_ntx=$(echo "$dad_new" | cut -d' ' -f2)
  dad_drx=$((dad_nrx - dad_orx))
  dad_dtx=$((dad_ntx - dad_otx))
  [ "$dad_drx" -lt 0 ] && dad_drx=0
  [ "$dad_dtx" -lt 0 ] && dad_dtx=0

  echo "当前活动网卡:$dad_if"
  echo "  下载:$((dad_drx / 3 / 1024)) KB/s"
  echo "  上传:$((dad_dtx / 3 / 1024)) KB/s"
  da_log "speed $dad_if down=$((dad_drx / 3 / 1024))KB/s up=$((dad_dtx / 3 / 1024))KB/s"
}

case "$1" in
  meta)
    echo "data|星数|看清各网卡收发了多少、现在跑多快|2|speed:测实时速率:pri"
    ;;
  status)
    da_gate || exit 5
    da_status
    ;;
  act)
    da_gate || exit 5
    case "$2" in
      speed)
        da_speed
        ;;
      *)
        echo "未知动作:$2" >&2
        exit 2
        ;;
    esac
    ;;
  *)
    echo "用法:$0 {meta|status|act <动作>}" >&2
    exit 2
    ;;
esac
