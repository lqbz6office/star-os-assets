#!/system/bin/sh
##########################################################################
# perfboost.sh —— 极致性能模块的一次性强化(整合自「极致性能 v13.5」的 service.sh)
#
# 原模块的 service.sh 里除了启动 ultra_performance 守护进程之外,还做了一轮
# 一次性强化。这里把那一轮单独抽出来,方便开关和排错。
#
# 用法:  sh perfboost.sh thermal    # 含温度墙解锁
#        sh perfboost.sh            # 不含温度墙解锁
#
# 保留了什么:
#   * 把所有离线核心强制拉回在线(有些 ROM 会关核省电,关核反而导致卡顿)
#   * 抬 cpu/gpu/ddr 三类温度墙到 110°C(可选,见 tweaks.conf 的 PERF_THERMAL)
#   * 解除 cpufreq boost 开关、提升 top-app/foreground 的 uclamp 下限
#
# 故意去掉了什么(重要,不是漏写):
#   * 原版会执行 scaling_max_freq = cpuinfo_max_freq(直接把 CPU 锁最高频)。
#     Star OS 同时整合了「桌面流畅度」模块,它有个 4 秒循环会按 SoC 设定
#     合理的频率上限(4100 机型是 1516800 / 1708800)。两处一起写会互相打架,
#     每 4 秒被改回去,白白产生 sysfs 抖动。
#     所以频率统一交给那个循环管理,这里只做它不碰的东西。
#   * 原版的 MIUI 专属项(ro.miui.ui.version.code / peak_refresh_rate)在小天才
#     手表上恒为假,写了也是空跑。
##########################################################################

# 原版常量:温度墙抬到这个值(单位是千分之一摄氏度,110000 = 110°C)
SET_TRIP_POINT_TEMP_MAX=110000
LOG="/data/adb/star_os/guard.log"

log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" >> "$LOG" 2>/dev/null; }

# ---------- 1. 强制所有核心在线 ----------
enable_offline_cpus() {
    for CPU_ONLINE in /sys/devices/system/cpu/cpu*/online; do
        [ -f "$CPU_ONLINE" ] || continue
        if [ "$(cat "$CPU_ONLINE" 2>/dev/null)" = "0" ]; then
            echo 1 > "$CPU_ONLINE" 2>/dev/null
        fi
    done
}

# ---------- 2. 抬温度墙上限(默认开,可在 tweaks.conf 里关掉) ----------
raise_trip_point_temp() {
    for THERMAL_ZONE in /sys/class/thermal/thermal_zone*/type; do
        [ -f "$THERMAL_ZONE" ] || continue
        if grep -Eq "cpu|gpu|ddr" "$THERMAL_ZONE" 2>/dev/null; then
            for TRIP_POINT_TEMP in "${THERMAL_ZONE%/*}"/trip_point_*_temp; do
                [ -f "$TRIP_POINT_TEMP" ] || continue
                _cur=$(cat "$TRIP_POINT_TEMP" 2>/dev/null)
                case "$_cur" in ''|*[!0-9]*) continue ;; esac
                if [ "$_cur" -lt "$SET_TRIP_POINT_TEMP_MAX" ]; then
                    echo "$SET_TRIP_POINT_TEMP_MAX" > "$TRIP_POINT_TEMP" 2>/dev/null
                fi
            done
        fi
    done
}

# ---------- 3. uclamp 下限(内核没有这个节点就自动跳过) ----------
set_min_uclamp() {
    local uclamp_file="/dev/cpuctl/$2/cpu.uclamp.min"
    if [ -f "$uclamp_file" ]; then
        chmod a+w "$uclamp_file" 2>/dev/null
        echo "$1" > "$uclamp_file" 2>/dev/null
        chmod a-w "$uclamp_file" 2>/dev/null
    fi
}

# ---------- 4. 解除全局 boost 开关限制 ----------
if [ -e /sys/devices/system/cpu/cpufreq/boost ] && \
   [ "$(cat /sys/devices/system/cpu/cpufreq/boost 2>/dev/null)" = "0" ]; then
    echo 1 > /sys/devices/system/cpu/cpufreq/boost 2>/dev/null
fi

enable_offline_cpus

if [ "$1" = "thermal" ]; then
    raise_trip_point_temp
    log "极致性能: 温控已解锁(cpu/gpu/ddr 温度墙抬到 110C,机器会更热)"
else
    log "极致性能: 温控保持原厂(未解锁温度墙)"
fi

set_min_uclamp 80 top-app
set_min_uclamp 15 foreground

exit 0
