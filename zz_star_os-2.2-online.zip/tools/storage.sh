#!/system/bin/sh
# ============================================================================
#  Star OS · 星盘 (storage.sh)   —— 基础功能(免费,人人可用)
#  ===========================================================
#  统一工具协议见 tools/power.sh 开头。
#
#  干的事:看清存储到底被谁占了 —— 分区用量、各目录体积排行、超过 20MB 的大文件。
#
#  为什么免费:只是"看",不改任何东西,零风险,没有收费的理由。
#
#  和「深度净化(cleanup)」的分工:
#    cleanup 是"动手清"(要 root 逐目录删,所以放 Pro+);
#    storage 是"先看清"(纯只读:df / du / find),给你判断依据 ——
#    先知道谁占的,再决定清不清。
# ============================================================================

PWDIR=${0%/*}
[ -d "$PWDIR" ] || PWDIR=/data/adb/modules/zz_star_os
STAR=${STAR_DIR:-/data/adb/star_os}
SP=$STAR/storage
LOG=$STAR/logs/storage.log

mkdir -p "$SP" "$STAR/logs" 2>/dev/null

sp_log() { echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$LOG" 2>/dev/null; }

# 可覆盖,便于在电脑上跑测试(真机就是默认值)
SP_DATA=${STORAGE_DATA_DIR:-/data}
SP_MEDIA=${STORAGE_MEDIA_DIR:-/data/media/0}
# 大文件门槛(MB)
SP_BIG_MB=${STORAGE_BIG_MB:-20}

# KB -> 人看的单位
sp_h() {
  sph_k=$1
  case "$sph_k" in ''|*[!0-9]*) echo "?"; return 0 ;; esac
  if [ "$sph_k" -ge 1048576 ]; then
    echo "$((sph_k / 1048576)).$((sph_k % 1048576 * 10 / 1048576))GB"
  elif [ "$sph_k" -ge 1024 ]; then
    echo "$((sph_k / 1024))MB"
  else
    echo "${sph_k}KB"
  fi
}

# ---------------------------------------------------------------- 分区
# df -k 输出固定 6 列,没有 awk 也能取 —— 压掉多余空格后按空格切第 2/4 列
sp_part() {
  sp_p=$(df -k "$1" 2>/dev/null | tail -n 1)
  [ -z "$sp_p" ] && { echo ""; return 0; }
  sp_p2=$(echo "$sp_p" | tr -s ' ' ' ' | cut -d' ' -f2)
  sp_p4=$(echo "$sp_p" | tr -s ' ' ' ' | cut -d' ' -f4)
  case "$sp_p2" in ''|*[!0-9]*) echo ""; return 0 ;; esac
  case "$sp_p4" in ''|*[!0-9]*) sp_p4=0 ;; esac
  sp_used=$((sp_p2 - sp_p4))
  sp_pct=$((sp_used * 100 / sp_p2))
  echo "已用 $(sp_h "$sp_used") / 共 $(sp_h "$sp_p2") (${sp_pct}%),剩 $(sp_h "$sp_p4")"
}

# ---------------------------------------------------------------- 目录排行
# du -sk 每个子目录,按体积倒序 —— 只看顶层,不递归,几秒出结果
sp_dirs() {
  sp_out=$(du -sk "$SP_MEDIA"/* 2>/dev/null | sort -rn | head -n 8)
  if [ -z "$sp_out" ]; then
    echo "(读不到目录占用)"
    return 0
  fi
  echo "$sp_out" | while read -r sp_kb sp_path; do
    [ -z "$sp_path" ] && continue
    echo "$(sp_h "$sp_kb")	${sp_path##*/}"
  done
}

# ---------------------------------------------------------------- 大文件
# 只往下找 3 层,避免全盘遍历把手表卡住;门槛由 SP_BIG_MB 控制
sp_bigs() {
  sp_out=$(find "$SP_MEDIA" -maxdepth 3 -type f -size +"${SP_BIG_MB}"M 2>/dev/null | head -n 12)
  if [ -z "$sp_out" ]; then
    echo "(没有超过 ${SP_BIG_MB}MB 的大文件)"
    return 0
  fi
  sp_n=$(echo "$sp_out" | grep -c . 2>/dev/null)
  case "$sp_n" in ''|*[!0-9]*) sp_n=0 ;; esac
  echo "(共 $sp_n 个)"
  echo "$sp_out" | while read -r sp_f; do
    [ -z "$sp_f" ] && continue
    sp_kb=$(du -k "$sp_f" 2>/dev/null | cut -f1)
    echo "$(sp_h "$sp_kb")	${sp_f#$SP_MEDIA/}"
  done
}

# ---------------------------------------------------------------- 状态
sp_status() {
  echo "系统分区:/data $(sp_part "$SP_DATA")"
  sp_sd=$(sp_part "$SP_MEDIA")
  [ -n "$sp_sd" ] && echo "存储卡:$sp_sd"
  echo ""
  echo "各目录占用(前 8)"
  sp_dirs
  echo ""
  echo "大文件(> ${SP_BIG_MB}MB)"
  sp_bigs
  echo ""
  echo "@item|重新扫一遍|act|refresh"
  return 0
}

case "$1" in
  meta)
    echo "storage|星盘|看清存储被谁占了,大文件一眼揪出|0|refresh:重新扫描:pri"
    ;;
  status)
    sp_status
    ;;
  act)
    case "$2" in
      refresh)
        sp_log "手动重扫"
        sp_status
        ;;
      *)
        echo "未知动作:$2" >&2
        exit 2
        ;;
    esac
    ;;
  *)
    echo "用法:$0 {meta|status|act <动作>}" >&2
    exit 2
    ;;
esac
