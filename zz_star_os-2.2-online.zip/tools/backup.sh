#!/system/bin/sh
# ============================================================================
#  Star OS · 星备 (backup.sh)   —— Pro+ / 终身版专属
#  ===========================================================
#  统一工具协议见 tools/power.sh 开头。
#
#  干的事:把这块手表"调好之后的样子"打包存一份 —— 亮度、息屏、动画、音量、
#        屏幕方向、字号/密度,加上「星盾」冻结名单、「星控」禁自启名单。
#        换表 / 刷机 / 手滑调乱了,一键还原回去。
#
#  为什么不备份应用数据:
#    应用数据(聊天记录那些)备份要逐应用处理、还可能涉及账号安全,
#    做半吊子只会让人以为"备份了其实没备" —— 那是害人。
#    这里只备"设置状态",范围写清楚,不吹牛。
#
#  存哪:
#    · 内存里一份:$STAR/backup/<时间>.conf(还原用这个,最快)
#    · 存储卡一份:/sdcard/StarOS/备份/(刷机也不丢,应用里能导出去)
# ============================================================================

PWDIR=${0%/*}
[ -d "$PWDIR" ] || PWDIR=/data/adb/modules/zz_star_os
STAR=${STAR_DIR:-/data/adb/star_os}
BK=$STAR/backup
LOG=$STAR/logs/backup.log
# 存储卡导出目录(可覆盖,便于测试)
BK_OUT=${BACKUP_OUT_DIR:-/sdcard/StarOS/备份}

mkdir -p "$BK" "$STAR/logs" 2>/dev/null

bk_log() { echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$LOG" 2>/dev/null; }

bk_tier() {
  bkg_v=0
  if [ -f "$STAR/pro.conf" ]; then
    bkg_v=$(sed -n 's/^tier=//p' "$STAR/pro.conf" 2>/dev/null | head -n 1)
  fi
  case "$bkg_v" in
    ''|*[!0-9]*) echo 0 ;;
    *) echo "$bkg_v" ;;
  esac
}

bk_gate() {
  [ "$(bk_tier)" -ge 2 ] && return 0
  echo "星备是 Pro+ / 终身版功能,当前等级不够" >&2
  return 5
}

bk_latest() {
  ls -t "$BK"/*.conf 2>/dev/null | head -n 1
}

bk_count() {
  bkc_n=$(ls "$BK"/*.conf 2>/dev/null | grep -c . 2>/dev/null)
  case "$bkc_n" in ''|*[!0-9]*) echo 0 ;; *) echo "$bkc_n" ;; esac
}

# ---------------------------------------------------------------- 保存
bk_save() {
  bks_ts=$(date '+%Y%m%d-%H%M%S')
  bks_f="$BK/$bks_ts.conf"
  true > "$bks_f"
  echo "ver=1" >> "$bks_f"
  echo "time=$(date '+%Y-%m-%d %H:%M:%S')" >> "$bks_f"

  # 格式: s|namespace|key|value  —— 用 | 分隔,因为值里可能有空格/中文
  for bks_k in screen_brightness screen_off_timeout screen_brightness_mode \
               volume_music volume_ring volume_alarm; do
    bks_v=$(settings get system "$bks_k" 2>/dev/null)
    echo "s|system|$bks_k|$bks_v" >> "$bks_f"
  done
  for bks_k in window_animation_scale transition_animation_scale animator_duration_scale; do
    bks_v=$(settings get global "$bks_k" 2>/dev/null)
    echo "s|global|$bks_k|$bks_v" >> "$bks_f"
  done
  for bks_k in accelerometer_rotation user_rotation; do
    bks_v=$(settings get system "$bks_k" 2>/dev/null)
    echo "s|system|$bks_k|$bks_v" >> "$bks_f"
  done
  bks_fs=$(settings get system font_scale 2>/dev/null)
  echo "s|system|font_scale|$bks_fs" >> "$bks_f"

  # 星盾冻结名单(第三方的被禁用包)
  pm list packages -d -3 2>/dev/null | sed -n 's/^package://p' | while read -r bks_p; do
    [ -z "$bks_p" ] && continue
    echo "f|$bks_p" >> "$bks_f"
  done

  # 星控禁自启名单(RUN_IN_BACKGROUND=deny 的第三方应用)
  if command -v cmd >/dev/null 2>&1; then
    for bks_p in $(pm list packages -3 2>/dev/null | sed -n 's/^package://p'); do
      [ -z "$bks_p" ] && continue
      case "$(cmd appops get "$bks_p" RUN_IN_BACKGROUND 2>/dev/null)" in
        *deny*) echo "n|$bks_p" >> "$bks_f" ;;
      esac
    done
  fi

  mkdir -p "$BK_OUT" 2>/dev/null
  cp -f "$bks_f" "$BK_OUT/$bks_ts.conf" 2>/dev/null
  bk_log "save $bks_ts"

  echo "已备份:$bks_ts"
  echo "存了两份 —— 内存里一份,存储卡 $BK_OUT 一份。"
  echo "共 $(bk_count) 份备份,要还原就点「还原最近一份」。"
}

# ---------------------------------------------------------------- 还原
bk_restore() {
  bkr_f=$1
  if [ -z "$bkr_f" ] || [ ! -f "$bkr_f" ]; then
    echo "没有可还原的备份。" >&2
    exit 1
  fi
  bkr_s=0
  bkr_fz=0
  bkr_nz=0
  while IFS='|' read -r bkr_t bkr_a bkr_b bkr_c; do
    [ -z "$bkr_t" ] && continue
    case "$bkr_t" in
      s)
        # 空了或 null 就跳过,别把系统设置写成空
        case "$bkr_c" in ''|null) continue ;; esac
        settings put "$bkr_a" "$bkr_b" "$bkr_c" >/dev/null 2>&1 && bkr_s=$((bkr_s + 1))
        ;;
      f)
        [ -z "$bkr_a" ] && continue
        case "$bkr_a" in com.android.*|android|com.xtc.watch|com.staros.*) continue ;; esac
        pm disable-user --user 0 "$bkr_a" >/dev/null 2>&1 && bkr_fz=$((bkr_fz + 1))
        ;;
      n)
        [ -z "$bkr_a" ] && continue
        case "$bkr_a" in com.android.*|android|com.xtc.watch|com.staros.*) continue ;; esac
        cmd appops set "$bkr_a" RUN_IN_BACKGROUND deny >/dev/null 2>&1 && bkr_nz=$((bkr_nz + 1))
        ;;
    esac
  done < "$bkr_f"
  bk_log "restore $bkr_f s=$bkr_s frozen=$bkr_fz noauto=$bkr_nz"
  echo "已还原:设置 $bkr_s 项,冻结 $bkr_fz 个,禁自启 $bkr_nz 个。"
  echo "部分设置可能要息屏再亮才看出来。"
}

# ---------------------------------------------------------------- 状态
bk_status() {
  bkn=$(bk_count)
  if [ "$bkn" = "0" ]; then
    echo "备份:还没有"
    echo ""
    echo "点「立即备份」把手表当前设置存一份。"
  else
    bkl=$(bk_latest)
    bkt=$(sed -n 's/^time=//p' "$bkl" 2>/dev/null | head -n 1)
    echo "备份:$bkn 份,最近一次:$bkt"
    echo "存了两个位置:内置 $BK,存储卡 $BK_OUT"
  fi
  echo ""
  echo "@item|立即备份当前设置|act|save"
  if [ "$bkn" != "0" ]; then
    echo "@item|还原最近一份备份|act|restore"
  fi
  if [ -d "$BK_OUT" ] && [ -n "$(ls "$BK_OUT"/*.conf 2>/dev/null)" ]; then
    echo "@item|从存储卡导入一份(换表后用)|act|import"
  fi
  return 0
}

case "$1" in
  meta)
    echo "backup|星备|设置一键快照,换表/刷机后还原|2|save:立即备份:pri,restore:还原最近一份:ghost"
    ;;
  status)
    bk_gate || exit 5
    bk_status
    ;;
  act)
    bk_gate || exit 5
    case "$2" in
      save) bk_save ;;
      restore) bk_restore "$(bk_latest)" ;;
      import)
        bki_f=$(ls -t "$BK_OUT"/*.conf 2>/dev/null | head -n 1)
        if [ -z "$bki_f" ]; then
          echo "存储卡里没有备份文件。" >&2
          exit 1
        fi
        cp -f "$bki_f" "$BK/" 2>/dev/null
        echo "已从存储卡导入:$(basename "$bki_f")"
        echo "要应用它,再点一次「还原最近一份备份」。"
        ;;
      *)
        echo "未知动作:$2" >&2
        exit 2
        ;;
    esac
    ;;
  *)
    echo "用法:$0 {meta|status|act <动作>}" >&2
    exit 2
    ;;
esac
