#!/system/bin/sh
# ============================================================================
#  Star OS · 星泄 (drain.sh)   —— Pro+ / 终身版专属
#  ===========================================================
#  统一工具协议见 tools/power.sh 开头。
#
#  干的事:回答"电到底被谁吃了" —— 哪个应用耗电最多、谁一直抓着唤醒锁不让表睡觉。
#
#  和「续航管家(power)」的分工:
#    power 是"手脚":一键进省电、自动进出;
#    drain 是"化验单":先把耗电大户指出来,让你知道该关谁 ——
#    不然省电模式开着,电照样被某个后台应用吃光。
#
#  数据来源:dumpsys batterystats(系统自己的电量统计,只读)。
# ============================================================================

PWDIR=${0%/*}
[ -d "$PWDIR" ] || PWDIR=/data/adb/modules/zz_star_os
STAR=${STAR_DIR:-/data/adb/star_os}
DR=$STAR/drain
LOG=$STAR/logs/drain.log

mkdir -p "$DR" "$STAR/logs" 2>/dev/null

dr_log() { echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$LOG" 2>/dev/null; }

dr_tier() {
  drg_v=0
  if [ -f "$STAR/pro.conf" ]; then
    drg_v=$(sed -n 's/^tier=//p' "$STAR/pro.conf" 2>/dev/null | head -n 1)
  fi
  case "$drg_v" in
    ''|*[!0-9]*) echo 0 ;;
    *) echo "$drg_v" ;;
  esac
}

dr_gate() {
  [ "$(dr_tier)" -ge 2 ] && return 0
  echo "星泄是 Pro+ / 终身版功能,当前等级不够" >&2
  return 5
}

# u0a123 -> 10123(Android 的应用 uid 就是 10000 + appid)
dr_uid_num() {
  dru_n=${1#u0a}
  case "$dru_n" in ''|*[!0-9]*) echo "" ;; *) echo $((10000 + dru_n)) ;; esac
}

# 用 uid 反查包名(反查不到就原样给 uid,不假装认识)
dr_pkg_of_uid() {
  drp_p=$(cmd package list packages -U 2>/dev/null | grep "uid:$1$" \
            | sed -n 's/^package:\([^ ]*\).*/\1/p' | head -n 1)
  [ -z "$drp_p" ] && drp_p="$2"
  echo "$drp_p"
}

dr_friendly() {
  case "$1" in
    com.tencent.mm) echo "微信" ;;
    com.tencent.mobileqq) echo "QQ" ;;
    com.ss.android.ugc.aweme) echo "抖音" ;;
    com.xtc.watch) echo "小天才" ;;
    com.xtc.*) echo "小天才组件" ;;
    com.android.*) echo "系统组件" ;;
    android) echo "系统" ;;
    u0a*) echo "$1" ;;
    *) echo "$1" ;;
  esac
}

# ---------------------------------------------------------------- 耗电排行
# batterystats 的 "Estimated power use" 段里每行是 "Uid u0aNNN: 12.3 ( ... )"
# 没有 awk,就用 sed 把"值 名字"抽出来再 sort -rn 排倒序
dr_power() {
  drp_raw=$(dumpsys batterystats --charged 2>/dev/null \
              | sed -n '/Estimated power use/,/^$/p' \
              | sed -n 's/^ *Uid \(u[0-9a-z]*\): \([0-9.]*\).*/\2 \1/p' \
              | sort -rn | head -n 8)
  if [ -z "$drp_raw" ]; then
    echo "(暂时读不到耗电明细,可能刚开机统计还没攒够)"
    return 0
  fi
  echo "$drp_raw" | while read -r drp_v drp_u; do
    [ -z "$drp_u" ] && continue
    drp_n=$(dr_uid_num "$drp_u")
    drp_pk=$(dr_pkg_of_uid "$drp_n" "$drp_u")
    echo "  ${drp_v} mAh	$(dr_friendly "$drp_pk")"
  done
}

# ---------------------------------------------------------------- 唤醒锁
# 抓着唤醒锁不放 = 表一直不睡,是最典型的"隐形耗电"
dr_wake() {
  drw_raw=$(dumpsys batterystats --charged 2>/dev/null \
              | grep -A 8 "partial wake locks" | sed -n '2,7p')
  if [ -z "$drw_raw" ]; then
    echo "(没有明显的唤醒锁,挺好)"
    return 0
  fi
  echo "$drw_raw" | while read -r drw_l; do
    [ -z "$drw_l" ] && continue
    echo "  $drw_l"
  done
}

dr_status() {
  echo "耗电排行(本次充电周期,单位 mAh):"
  dr_power
  echo ""
  echo "唤醒锁:"
  dr_wake
  echo ""
  echo "@item|重新化验一次|act|scan"
  echo "@item|把所有后台停掉试试|act|killall"
  return 0
}

case "$1" in
  meta)
    echo "drain|星泄|查出电被哪个应用吃了,连唤醒锁一起看|2|scan:重新化验:pri,killall:停掉所有后台:ghost"
    ;;
  status)
    dr_gate || exit 5
    dr_status
    ;;
  act)
    dr_gate || exit 5
    case "$2" in
      scan)
        dr_log "手动化验"
        dr_status
        ;;
      killall)
        am kill-all >/dev/null 2>&1
        echo "已把后台应用都停了。"
        echo "注意:这只是临时手段 —— 想治本去「星控」把耗电大户禁掉自启。"
        dr_log "killall"
        ;;
      *)
        echo "未知动作:$2" >&2
        exit 2
        ;;
    esac
    ;;
  *)
    echo "用法:$0 {meta|status|act <动作>}" >&2
    exit 2
    ;;
esac
