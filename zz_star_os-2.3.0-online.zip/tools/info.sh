#!/system/bin/sh
# ============================================================================
#  Star OS · 星悟 (info.sh)   —— 基础功能(免费,人人可用)
#  ===========================================================
#  统一工具协议见 tools/power.sh 开头。
#
#  干的事:把这块表的"家底"一次性摊开 —— 型号、系统、CPU、内存、
#        存储、开机多久、模块什么版本。买二手验机、报故障、升级前
#        先来这儿看一眼,不用去翻系统设置里那几个藏得很深的页面。
#
#  纯只读:一条命令都不改系统设置。随时点开看,不会有任何副作用。
# ============================================================================

PWDIR=${0%/*}
[ -d "$PWDIR" ] || PWDIR=/data/adb/modules/zz_star_os/tools
MODD=${PWDIR%/*}
[ -d "$MODD" ] || MODD=/data/adb/modules/zz_star_os

in_get() { getprop "$1" 2>/dev/null; }

# 打印一行"标签:值";值为空或 unknown 就跳过(免得列一堆"unknown")
in_kv() {
  [ -z "$2" ] && return 0
  [ "$2" = "unknown" ] && return 0
  echo "$1:$2"
}

# 读 /proc/meminfo 某行的数值(单位 KB)
in_meminfo() {
  sed -n "s/^$1:[ 	]*\([0-9][0-9]*\).*/\1/p" /proc/meminfo 2>/dev/null | head -n 1
}

# df 的可用空间(KB):优先 POSIX 单行格式(列固定),取不到就退回普通格式
in_df_avail() {
  ind_l=$(df -k -P "$1" 2>/dev/null | sed -n '2p')
  [ -z "$ind_l" ] && ind_l=$(df -k "$1" 2>/dev/null | sed -n '2p')
  echo "$ind_l" | sed -n 's/^[^ 	][^ 	]*[ 	][ 	]*[0-9][0-9]*[ 	][ 	]*[0-9][0-9]*[ 	][ 	]*\([0-9][0-9]*\).*/\1/p'
}

# KB 转成人看的单位
in_hum() {
  inh_k=$1
  case "$inh_k" in ''|*[!0-9]*) echo "读不到"; return 0 ;; esac
  if [ "$inh_k" -ge 1048576 ]; then
    echo "$((inh_k / 1048576)).$(( (inh_k % 1048576) * 10 / 1048576 )) GB"
  elif [ "$inh_k" -ge 1024 ]; then
    echo "$((inh_k / 1024)) MB"
  else
    echo "${inh_k} KB"
  fi
}

# /proc/uptime 第一列是秒
in_uptime() {
  inu_s=$(sed -n 's/^\([0-9][0-9]*\).*/\1/p' /proc/uptime 2>/dev/null | head -n 1)
  case "$inu_s" in ''|*[!0-9]*) echo "读不到"; return 0 ;; esac
  inu_d=$((inu_s / 86400))
  inu_h=$(( (inu_s % 86400) / 3600 ))
  inu_m=$(( (inu_s % 3600) / 60 ))
  if [ "$inu_d" -gt 0 ]; then
    echo "${inu_d} 天 ${inu_h} 小时"
  else
    echo "${inu_h} 小时 ${inu_m} 分"
  fi
}

in_screen() {
  ins_w=$(wm size 2>/dev/null | sed -n 's/.*: \([0-9]*x[0-9]*\).*/\1/p' | head -n 1)
  ins_d=$(wm density 2>/dev/null | sed -n 's/.*: \([0-9]*\).*/\1/p' | head -n 1)
  [ -n "$ins_w" ] && echo "屏幕:${ins_w}${ins_d:+  (密度 $ins_d)}"
}

in_modver() {
  inm_v=$(sed -n 's/^version=//p' "$MODD/module.prop" 2>/dev/null | head -n 1)
  [ -n "$inm_v" ] && echo "Star OS:$inm_v"
}

in_status() {
  echo "=== 这块表 ==="
  in_kv "型号" "$(in_get ro.product.model)"
  in_kv "品牌" "$(in_get ro.product.brand)"
  in_kv "系统" "Android $(in_get ro.build.version.release) (SDK $(in_get ro.build.version.sdk))"
  in_kv "内核" "$(uname -r 2>/dev/null)"
  in_kv "架构" "$(in_get ro.product.cpu.abi)"
  in_screen
  echo ""
  echo "=== 资源 ==="
  in_kv "内存" "$(in_hum "$(in_meminfo MemTotal)") 总,可用 $(in_hum "$(in_meminfo MemAvailable)")"
  in_kv "内部存储剩余" "$(in_hum "$(in_df_avail /data)")"
  in_kv "存储卡剩余" "$(in_hum "$(in_df_avail /sdcard)")"
  echo ""
  echo "=== 运行 ==="
  in_kv "已开机" "$(in_uptime)"
  in_modver
  echo ""
  echo "@item|刷新|act|scan"
  return 0
}

case "$1" in
  meta)
    echo "info|星悟|这块表的型号/系统/内存/存储/开机时长一览|0|scan:刷新:pri"
    ;;
  status)
    in_status
    ;;
  act)
    case "$2" in
      scan) in_status ;;
      *)
        echo "未知动作:$2" >&2
        exit 2
        ;;
    esac
    ;;
  *)
    echo "用法:$0 {meta|status|act <动作>}" >&2
    exit 2
    ;;
esac
