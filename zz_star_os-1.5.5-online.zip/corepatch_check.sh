#!/system/bin/sh
# ==========================================================================
#  核心破解 (CorePatch) 安装 / 激活 检测
#
#  本文件不被单独执行,而是由 customize.sh(刷入时)和 service.sh(开机后)
#  共同 source,因此这里不写 set -e 之类会污染调用方状态的东西,
#  变量一律用 _cp_ / CP_ 前缀,避免和调用方的变量撞名。
#
#  ── 为什么本模块需要核心破解 ──
#  payload/ 里的 Z12 桌面、侧边栏、AI识屏 都是「Develop 开发签名」的包。
#  设备上如果已有正式签名的同名应用(包管理器只比包名,不比版本),
#  安装就会返回 INSTALL_FAILED_UPDATE_INCOMPATIBLE / "signatures do not match"。
#  核心破解是 LSPosed 模块,作用域勾「系统框架」后禁用 PMS 的签名校验,
#  才能覆盖安装签名不同的同名应用。
#
#  ── 已知包名 ──
#    com.coderstory.toolkit   原版「核心破解」(Android 4.4~12,本机 8.1 适用)
#    org.lsposed.corepatch    新版 Core Patch N(要求 Android 9+,本机装了也不生效)
#    com.tsng.hook.xp         同系列历史包名,一并兜住
#  自编译 / 改名版可能用别的包名,届时往 cp_pkgs 里加一个即可。
#
#  ── 怎么判断「已激活」──
#  不去读框架的配置文件(勾选状态查不准),而是看**实证**:
#  LSPosed 启用模块后会把它加载进作用域进程,APK/odex 路径会出现在
#  该进程的 /proc/<pid>/maps 里。核心破解必须作用到系统框架,
#  所以只要它出现在 system_server 的 maps 中,就是"装好了且真的在生效"。
#  读不到 maps 时(如 recovery 环境)退化为查框架配置,并在结论里注明是弱证据。
#
#  ── cp_probe 返回码 ──
#    0 = 已安装且已激活生效
#    1 = 已安装但未激活(含框架缺失)
#    2 = 未安装
#    3 = 无法确认
#  探测结论同时放在:CP_RC / CP_PKG / CP_FW / CP_EVIDENCE
# ==========================================================================

cp_pkgs="com.coderstory.toolkit org.lsposed.corepatch com.tsng.hook.xp"

CP_RC=3
CP_PKG=""
CP_FW=""
CP_EVIDENCE=""

# --------------------------------------------------------------------------
#  包是否已安装
#  不依赖 pm:customize.sh 在 recovery 里跑时 Android 没起来,pm 不可用。
# --------------------------------------------------------------------------
cp_pkg_installed() {
  _cp_p="$1"
  [ -z "$_cp_p" ] && return 1

  # 1) 系统起来后用 pm 最准(能认出各种安装位置)
  if [ -x "${PM:-/system/bin/pm}" ]; then
    "${PM:-/system/bin/pm}" path "$_cp_p" >/dev/null 2>&1 && return 0
  fi

  # 2) 直接看安装目录(recovery / 早期启动时的兜底)
  for _cp_d in /data/app /data/app-private /system/app /system/priv-app; do
    ls -d "$_cp_d"/*"$_cp_p"* 2>/dev/null | grep -q . && return 0
  done

  # 3) 新版本 Android 的 /data/app/~~xxx==/com.xxx-yyy==/ 两级目录结构
  find /data/app -maxdepth 2 -name "$_cp_p*" 2>/dev/null | grep -q . && return 0

  return 1
}

# --------------------------------------------------------------------------
#  框架检测:LSPosed / EdXposed 任一在位即可(hook 框架是核心破解的前提)
# --------------------------------------------------------------------------
cp_framework() {
  [ -d /data/adb/lspd ] && { echo "LSPosed"; return 0; }
  [ -d /data/adb/edxp ] && { echo "EdXposed"; return 0; }
  [ -f /data/adb/edxp/enabled_modules.list ] && { echo "EdXposed"; return 0; }
  [ -d /data/adb/riru/modules/lsposed ] && { echo "LSPosed"; return 0; }

  _cp_f=""
  for _cp_m in /data/adb/modules/*; do
    [ -e "$_cp_m" ] || continue
    case "$(basename "$_cp_m")" in
      *lsposed*|*LSPosed*|*LSPOSED*) _cp_f="LSPosed"; break ;;
      *edxposed*|*EdXposed*)          _cp_f="EdXposed"; break ;;
    esac
  done
  [ -n "$_cp_f" ] && { echo "$_cp_f"; return 0; }

  return 1
}

# --------------------------------------------------------------------------
#  是否真的激活生效
#  返回 0=已生效  1=没生效  3=无法确认
# --------------------------------------------------------------------------
cp_activated() {
  _cpa_p="$1"
  [ -z "$_cpa_p" ] && return 1
  CP_EVIDENCE=""

  # 找 system_server 的 pid(toybox 的 ps -A 没有表头,$2 就是 PID)
  _cp_pid=$(pidof system_server 2>/dev/null)
  [ -z "$_cp_pid" ] && \
    _cp_pid=$(ps -A 2>/dev/null | grep -w system_server | awk '{print $2}' | head -n 1)

  # A) 强证据:模块已被加载进系统框架进程
  if [ -n "$_cp_pid" ] && [ -r "/proc/$_cp_pid/maps" ]; then
    if grep -q "$_cpa_p" "/proc/$_cp_pid/maps" 2>/dev/null; then
      CP_EVIDENCE="system_server 已加载该模块(实证生效)"
      return 0
    fi
    CP_EVIDENCE="system_server 未加载该模块 —— 未启用,或作用域没勾「系统框架」"
    return 1
  fi

  # B) 读不到 maps(如 recovery 环境),退化为查框架配置 —— 只能算弱证据
  for _cp_db in /data/adb/lspd/config/modules_config.db /data/adb/lspd/config/modules.db; do
    if [ -f "$_cp_db" ] && grep -q "$_cpa_p" "$_cp_db" 2>/dev/null; then
      CP_EVIDENCE="框架配置里有该模块记录(配置层面确认,未能验证实际生效)"
      return 0
    fi
  done
  if [ -f /data/adb/edxp/enabled_modules.list ] && \
     grep -q "$_cpa_p" /data/adb/edxp/enabled_modules.list 2>/dev/null; then
    CP_EVIDENCE="EdXposed 启用列表里有该模块"
    return 0
  fi

  CP_EVIDENCE="读不到 system_server 进程信息,也没有框架配置记录"
  return 3
}

# --------------------------------------------------------------------------
#  总入口:探测并把结论放进 CP_* 变量,同时返回同样的状态码
# --------------------------------------------------------------------------
cp_probe() {
  CP_RC=3; CP_PKG=""; CP_FW=""; CP_EVIDENCE=""

  for _cp_c in $cp_pkgs; do
    if cp_pkg_installed "$_cp_c"; then
      CP_PKG="$_cp_c"
      break
    fi
  done
  if [ -z "$CP_PKG" ]; then
    CP_RC=2
    return 2
  fi

  CP_FW=$(cp_framework 2>/dev/null)

  cp_activated "$CP_PKG"
  _cp_r=$?
  case "$_cp_r" in
    0) CP_RC=0; return 0 ;;
    1) CP_RC=1; return 1 ;;
    *) CP_RC=3; return 3 ;;
  esac
}

# --------------------------------------------------------------------------
#  结论行(供调用方往日志 / 界面里输出)
# --------------------------------------------------------------------------
cp_status_line() {
  case "$CP_RC" in
    0) echo "核心破解: 已安装并已激活生效${CP_FW:+ [$CP_FW] }($CP_PKG)" ;;
    1) echo "核心破解: 已安装($CP_PKG)但【未生效】" ;;
    2) echo "核心破解: 未安装" ;;
    *) echo "核心破解: 状态无法确认" ;;
  esac
}

# --------------------------------------------------------------------------
#  「请激活核心破解」提示块
#  按需求:只要没激活就写出这句;并把原因、步骤、当前状态一起给出。
# --------------------------------------------------------------------------
cp_hint() {
  echo "请激活核心破解"
  echo "原因: 随模块安装的 Z12 桌面 / 侧边栏 / AI识屏 都是开发签名(Develop)的包,"
  echo "      设备上若已有正式签名的同名应用,没有核心破解会安装失败。"
  echo "步骤: 1) 确认已安装 LSPosed 框架并重启过一次"
  echo "      2) 打开 LSPosed -> 模块 -> 核心破解,打开开关"
  echo "      3) 作用域勾选「系统框架」(android) —— 这一步最关键"
  echo "      4) 重启手表,本模块下次开机时会自动复检"
  case "$CP_RC" in
    1) echo "当前: 已安装($CP_PKG)但未激活${CP_EVIDENCE:+ —— $CP_EVIDENCE}" ;;
    2) echo "当前: 未检测到核心破解${CP_FW:+ (框架 $CP_FW 在位)}" ;;
    *) echo "当前: 无法确认${CP_EVIDENCE:+ —— $CP_EVIDENCE}" ;;
  esac
}
