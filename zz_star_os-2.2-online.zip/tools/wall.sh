#!/system/bin/sh
# ============================================================================
#  Star OS · 星墙 (wall.sh)   —— Pro+ / 终身版专属
#  ===========================================================
#  统一工具协议见 tools/power.sh 开头。
#
#  干的事:把某个应用彻底断网 —— 它再也连不上服务器,但应用本身还能打开
#        (需要联网的功能会转圈失败,本地功能照常用)。
#        适合:不想让它偷偷上传数据的、看视频费流量的、只是想安静一点的。
#
#  ⚠ 这是整个工具箱里**唯一会动网络栈**的工具,所以规矩定得最死:
#    1. 只按应用 UID 丢包(iptables owner 匹配),不碰全局网络;
#    2. 系统 UID(<10000)一律拒绝,免得把电话/短信/自己的网都断了;
#    3. 规则同步存一份 /data/adb/star_os/wall/rules.txt,
#       「全部解除」按这份名单逐条删干净 —— 不留残规则;
#    4. iptables 规则重启即丢,所以 daemon 每 5 分钟核对一次名单,
#       发现规则没了就补回来,保证"说了禁就一直禁着"。
# ============================================================================

PWDIR=${0%/*}
[ -d "$PWDIR" ] || PWDIR=/data/adb/modules/zz_star_os
STAR=${STAR_DIR:-/data/adb/star_os}
WL=$STAR/wall
RULES=$WL/rules.txt
LOG=$STAR/logs/wall.log

mkdir -p "$WL" "$STAR/logs" 2>/dev/null

wl_log() { echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$LOG" 2>/dev/null; }

wl_tier() {
  wlg_v=0
  if [ -f "$STAR/pro.conf" ]; then
    wlg_v=$(sed -n 's/^tier=//p' "$STAR/pro.conf" 2>/dev/null | head -n 1)
  fi
  case "$wlg_v" in
    ''|*[!0-9]*) echo 0 ;;
    *) echo "$wlg_v" ;;
  esac
}

wl_gate() {
  [ "$(wl_tier)" -ge 2 ] && return 0
  echo "星墙是 Pro+ / 终身版功能,当前等级不够" >&2
  return 5
}

wl_friendly() {
  case "$1" in
    com.tencent.mm) echo "微信" ;;
    com.tencent.mobileqq) echo "QQ" ;;
    com.eg.android.AlipayGphone) echo "支付宝" ;;
    com.ss.android.ugc.aweme) echo "抖音" ;;
    com.xtc.watch) echo "小天才" ;;
    com.netease.*) echo "网易系" ;;
    com.tencent.tmgp.*) echo "腾讯游戏" ;;
    com.tencent.qqlive*) echo "腾讯视频" ;;
    tv.danmaku.bili) echo "哔哩哔哩" ;;
    com.kugou.android) echo "酷狗" ;;
    com.ximalaya.ting.android) echo "喜马拉雅" ;;
    *) echo "$1" ;;
  esac
}

wl_has_iptables() {
  command -v iptables >/dev/null 2>&1 && echo 1 || echo 0
}

# 取应用 UID:优先用 pm 一次列全(快),取不到再退回 dumpsys(慢但兜底)
wl_uid_of() {
  wlu_u=$(cmd package list packages -U 2>/dev/null | grep "^package:$1 " \
            | sed -n 's/.*uid:\([0-9][0-9]*\).*/\1/p' | head -n 1)
  if [ -z "$wlu_u" ]; then
    wlu_u=$(dumpsys package "$1" 2>/dev/null \
              | sed -n 's/.*userId=\([0-9][0-9]*\).*/\1/p' | head -n 1)
  fi
  echo "$wlu_u"
}

wl_thirds() {
  pm list packages -3 2>/dev/null | sed -n 's/^package://p' | sort
}

# 名单里有没有这个 uid
wl_in_list() {
  [ -f "$RULES" ] || return 1
  grep -q "^$1$" "$RULES" 2>/dev/null
}

wl_list_add() {
  wl_in_list "$1" && return 0
  echo "$1" >> "$RULES"
}

wl_list_del() {
  [ -f "$RULES" ] || return 0
  grep -v "^$1$" "$RULES" 2>/dev/null > "$RULES.tmp"
  mv -f "$RULES.tmp" "$RULES" 2>/dev/null
}

# iptables 里当前有没有这个 uid 的规则
wl_kernel_has() {
  iptables -S OUTPUT 2>/dev/null | grep -q "uid-owner $1" && return 0
  return 1
}

wl_block() {
  [ -z "$1" ] && return 1
  wlb_u=$1
  iptables -I OUTPUT -m owner --uid-owner "$wlb_u" -j DROP >/dev/null 2>&1
  iptables -I INPUT  -m owner --uid-owner "$wlb_u" -j DROP >/dev/null 2>&1
  if wl_kernel_has "$wlb_u"; then
    wl_list_add "$wlb_u"
    return 0
  fi
  return 1
}

wl_unblock() {
  [ -z "$1" ] && return 1
  wlu_i=0
  while [ "$wlu_i" -lt 20 ]; do
    iptables -D OUTPUT -m owner --uid-owner "$1" -j DROP >/dev/null 2>&1 || break
    wlu_i=$((wlu_i + 1))
  done
  wlu_i=0
  while [ "$wlu_i" -lt 20 ]; do
    iptables -D INPUT -m owner --uid-owner "$1" -j DROP >/dev/null 2>&1 || break
    wlu_i=$((wlu_i + 1))
  done
  wl_list_del "$1"
  return 0
}

# 按 UID 找包名(反向查,用来把名单显示成人看懂的)
wl_name_of_uid() {
  wln_p=$(cmd package list packages -U 2>/dev/null | grep "uid:$1$" \
            | sed -n 's/^package:\([^ ]*\).*/\1/p' | head -n 1)
  [ -z "$wln_p" ] && wln_p="$1"
  echo "$wln_p"
}

# 状态:列出当前被封的(以 iptables 为准),没网的给个入口
wl_status() {
  if [ "$(wl_has_iptables)" != "1" ]; then
    echo "这台机器没有 iptables,星墙用不了。"
    return 0
  fi
  wls_n=0
  if [ -f "$RULES" ]; then
    wls_n=$(grep -c . "$RULES" 2>/dev/null)
  fi
  case "$wls_n" in ''|*[!0-9]*) wls_n=0 ;; esac
  if [ "$wls_n" = "0" ]; then
    echo "已断网:还没有"
    echo ""
    echo "下面「挑应用断网」进去,选中的应用会连不上网。"
    echo "想恢复点一下「全部解除」,规则会逐条删干净。"
  else
    echo "已断网 ($wls_n 个):"
    while read -r wls_u; do
      [ -z "$wls_u" ] && continue
      wls_p=$(wl_name_of_uid "$wls_u")
      if wl_kernel_has "$wls_u"; then
        echo "@item|$(wl_friendly "$wls_p") · 恢复联网|act|open:$wls_u"
      else
        echo "@item|$(wl_friendly "$wls_p") · 待补规则|act|close:$wls_u"
      fi
    done < "$RULES"
  fi
  echo ""
  echo "@item|挑应用断网|act|pick"
  echo "@item|全部解除(清空所有规则)|act|clear"
  return 0
}

case "$1" in
  meta)
    echo "wall|星墙|把指定应用彻底断网,本地功能不受影响|2|pick:挑应用断网:pri,clear:全部解除:ghost"
    ;;
  status)
    wl_gate || exit 5
    wl_status
    ;;
  act)
    wl_gate || exit 5
    case "$2" in
      pick)
        if [ "$(wl_has_iptables)" != "1" ]; then
          echo "没有 iptables,用不了。" >&2
          exit 1
        fi
        echo "点一个应用让它断网(应用还能打开,只是连不上服务器)。"
        echo "已经断网的,点一下可以恢复。"
        echo ""
        wl_thirds | while read -r wlp_p; do
          [ -z "$wlp_p" ] && continue
          case "$wlp_p" in com.android.*|android|com.staros.*|com.coderstory.*) continue ;; esac
          wlp_u=$(wl_uid_of "$wlp_p")
          case "$wlp_u" in
            ''|*[!0-9]*) continue ;;
          esac
          # 系统 UID 一律跳过,不给碰
          if [ "$wlp_u" -lt 10000 ]; then continue; fi
          if wl_in_list "$wlp_u"; then
            echo "@item|[已断] $(wl_friendly "$wlp_p")|act|open:$wlp_u"
          else
            echo "@item|$(wl_friendly "$wlp_p")|act|close:$wlp_u"
          fi
        done
        ;;
      close)
        [ -z "$3" ] && { echo "缺少 UID" >&2; exit 2; }
        case "$3" in
          ''|*[!0-9]*) echo "UID 不合法" >&2; exit 2 ;;
        esac
        if [ "$3" -lt 10000 ]; then
          echo "系统 UID 不能断网(会把手表搞失联)" >&2
          exit 3
        fi
        if wl_block "$3"; then
          echo "已断网:$(wl_friendly "$(wl_name_of_uid "$3")")"
          echo "它现在连不上任何服务器了。要恢复就在列表里点它。"
          wl_log "block uid=$3"
        else
          echo "断网失败(可能没有 iptables 权限)" >&2
          exit 1
        fi
        ;;
      open)
        [ -z "$3" ] && { echo "缺少 UID" >&2; exit 2; }
        wl_unblock "$3"
        echo "已恢复联网:$(wl_friendly "$(wl_name_of_uid "$3")")"
        wl_log "unblock uid=$3"
        ;;
      clear)
        wlc_n=0
        if [ -f "$RULES" ]; then
          while read -r wlc_u; do
            [ -z "$wlc_u" ] && continue
            wl_unblock "$wlc_u"
            wlc_n=$((wlc_n + 1))
          done < "$RULES"
        fi
        true > "$RULES"
        echo "已全部解除,清掉 $wlc_n 条规则。"
        wl_log "clear-all $wlc_n"
        ;;
      apply)
        # 供 daemon / 开机恢复用:按名单把缺的规则补回来
        wla_n=0
        if [ -f "$RULES" ]; then
          while read -r wla_u; do
            [ -z "$wla_u" ] && continue
            if ! wl_kernel_has "$wla_u"; then
              iptables -I OUTPUT -m owner --uid-owner "$wla_u" -j DROP >/dev/null 2>&1
              iptables -I INPUT  -m owner --uid-owner "$wla_u" -j DROP >/dev/null 2>&1
              wla_n=$((wla_n + 1))
            fi
          done < "$RULES"
        fi
        echo "已补齐 $wla_n 条断网规则"
        ;;
      *)
        echo "未知动作:$2" >&2
        exit 2
        ;;
    esac
    ;;
  daemon)
    wl_log "星墙 daemon 启动 (pid=$$)"
    while true; do
      "$0" act apply >/dev/null 2>&1
      sleep 300
    done
    ;;
  *)
    echo "用法:$0 {meta|status|act <动作> [参数]|daemon}" >&2
    exit 2
    ;;
esac
